package com.minicloud.aspect;

import com.minicloud.annotation.OperationLog;
import com.minicloud.config.SystemLogSchemaInitializer;
import com.minicloud.entity.SystemLog;
import com.minicloud.entity.User;
import com.minicloud.security.UserPrincipal;
import com.minicloud.service.SystemLogService;
import com.minicloud.service.UserService;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.util.Arrays;

@Aspect
@Component
public class OperationLogAspect {

    private static final Logger LOGGER = LoggerFactory.getLogger(OperationLogAspect.class);

    private final SystemLogService systemLogService;
    private final UserService userService;
    private final SystemLogSchemaInitializer schemaInitializer;

    public OperationLogAspect(SystemLogService systemLogService,
                              UserService userService,
                              SystemLogSchemaInitializer schemaInitializer) {
        this.systemLogService = systemLogService;
        this.userService = userService;
        this.schemaInitializer = schemaInitializer;
    }

    @Around("@annotation(com.minicloud.annotation.OperationLog)")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        long start = System.currentTimeMillis();
        Throwable throwable = null;
        Object result = null;
        try {
            result = joinPoint.proceed();
            return result;
        } catch (Throwable ex) {
            throwable = ex;
            throw ex;
        } finally {
            recordLog(joinPoint, System.currentTimeMillis() - start, result, throwable);
        }
    }

    private void recordLog(ProceedingJoinPoint joinPoint, long duration, Object result, Throwable throwable) {
        if (schemaInitializer != null && !schemaInitializer.isSchemaReady()) {
            return;
        }
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !(authentication.getPrincipal() instanceof UserPrincipal)) {
            return;
        }
        UserPrincipal principal = (UserPrincipal) authentication.getPrincipal();

        User currentUser = userService.getById(principal.getId());
        if (currentUser == null) {
            return;
        }

        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        OperationLog annotation = method.getAnnotation(OperationLog.class);

        SystemLog logEntry = new SystemLog();
        logEntry.setUserId(principal.getId());
        logEntry.setUsername(principal.getUsername());
        logEntry.setDepartmentId(currentUser.getDepartmentId());
        logEntry.setOperation(annotation.value());
        logEntry.setMethod(method.getDeclaringClass().getSimpleName() + "#" + method.getName());
        logEntry.setParams(Arrays.toString(joinPoint.getArgs()));
        logEntry.setExecutionTime(duration);
        logEntry.setResult(result != null ? truncate(result.toString(), 1024) : null);
        logEntry.setErrorMessage(throwable != null ? truncate(throwable.getMessage(), 512) : null);
        logEntry.setCreateTime(LocalDateTime.now());

        HttpServletRequest request = currentRequest();
        if (request != null) {
            logEntry.setIpAddress(request.getRemoteAddr());
            logEntry.setUserAgent(request.getHeader("User-Agent"));
        }

        try {
            systemLogService.log(logEntry);
        } catch (Exception e) {
            LOGGER.warn("Failed to persist operation log, operation={}, user={}: {}",
                annotation.value(), principal.getUsername(), e.getMessage());
        }
    }

    private HttpServletRequest currentRequest() {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        return attributes != null ? attributes.getRequest() : null;
    }

    private String truncate(String text, int length) {
        if (text == null) {
            return null;
        }
        return text.length() <= length ? text : text.substring(0, length);
    }
}
