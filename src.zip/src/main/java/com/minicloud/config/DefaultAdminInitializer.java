package com.minicloud.config;

import com.minicloud.entity.User;
import com.minicloud.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import org.springframework.security.crypto.password.PasswordEncoder;

@Component
public class DefaultAdminInitializer implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(DefaultAdminInitializer.class);

    private final UserService userService;
    private final PasswordEncoder passwordEncoder;

    public DefaultAdminInitializer(UserService userService, PasswordEncoder passwordEncoder) {
        this.userService = userService;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(ApplicationArguments args) {
        User existing = userService.findByUsername("admin");
        if (existing != null) {
            boolean updated = false;
            if (existing.getStatus() == null || existing.getStatus() == 0) {
                existing.setStatus(1);
                updated = true;
            }
            if (existing.getRoleType() == null || existing.getRoleType() < 2) {
                existing.setRoleType(2);
                updated = true;
            }
            if (existing.getPassword() == null
                || existing.getPassword().isBlank()
                || !passwordEncoder.matches("123456", existing.getPassword())) {
                existing.setPassword(passwordEncoder.encode("123456"));
                updated = true;
            }
            if (updated) {
                userService.updateById(existing);
                log.info("Default admin account 'admin' was updated to ensure it remains active.");
            }
        } else {
            User admin = new User();
            admin.setUsername("admin");
            admin.setPassword(passwordEncoder.encode("123456"));
            admin.setRealName("System Administrator");
            admin.setRoleType(2);
            admin.setStatus(1);
            userService.save(admin);
            log.info("Created default admin account 'admin' with initial password 123456.");
        }
    }
}
