package com.minicloud.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

/**
 * Ensures the {@code system_log} table contains the columns that the
 * application expects. Some existing databases were provisioned from an early
 * schema without {@code department_id} / {@code deleted}, which caused write
 * operations to fail and transaction rollbacks across the file APIs.
 */
@Component
public class SystemLogSchemaInitializer implements InitializingBean {

    private static final Logger LOGGER = LoggerFactory.getLogger(SystemLogSchemaInitializer.class);

    private final JdbcTemplate jdbcTemplate;
    private volatile boolean schemaReady = true;

    public SystemLogSchemaInitializer(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public void afterPropertiesSet() {
        boolean ready = true;
        ready &= ensureColumn("department_id",
            "ALTER TABLE system_log ADD COLUMN department_id BIGINT NULL");
        ready &= ensureColumn("deleted",
            "ALTER TABLE system_log ADD COLUMN deleted TINYINT(1) DEFAULT 0");
        ready &= ensureIndex("idx_system_log_department",
            "CREATE INDEX idx_system_log_department ON system_log (department_id)");
        ready &= ensureIndex("idx_system_log_user",
            "CREATE INDEX idx_system_log_user ON system_log (user_id)");
        ready &= alignDeletedFlag();
        schemaReady = ready;
        if (!schemaReady) {
            LOGGER.warn("System log schema is not fully aligned; operation logs will be skipped until fixed.");
        }
    }

    public boolean isSchemaReady() {
        return schemaReady;
    }

    private boolean ensureColumn(String columnName, String ddl) {
        String sql =
            "SELECT COUNT(*) FROM information_schema.COLUMNS " +
                "WHERE TABLE_SCHEMA = DATABASE() " +
                "AND TABLE_NAME = 'system_log' " +
                "AND COLUMN_NAME = ?";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, columnName);
        if (count == null || count == 0) {
            try {
                jdbcTemplate.execute(ddl);
                LOGGER.info("Added missing column '{}' to system_log table", columnName);
            } catch (Exception ex) {
                LOGGER.warn("Failed to add column '{}' to system_log table: {}", columnName, ex.getMessage());
                return false;
            }
        }
        return true;
    }

    private boolean ensureIndex(String indexName, String ddl) {
        String sql =
            "SELECT COUNT(*) FROM information_schema.STATISTICS " +
                "WHERE TABLE_SCHEMA = DATABASE() " +
                "AND TABLE_NAME = 'system_log' " +
                "AND INDEX_NAME = ?";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, indexName);
        if (count == null || count == 0) {
            try {
                jdbcTemplate.execute(ddl);
                LOGGER.info("Created missing index '{}' on system_log table", indexName);
            } catch (Exception ex) {
                if (StringUtils.hasText(ex.getMessage()) && ex.getMessage().contains("Duplicate key name")) {
                    LOGGER.debug("Index '{}' already exists on system_log table", indexName);
                    return true;
                } else {
                    LOGGER.warn("Failed to create index '{}' on system_log table: {}", indexName, ex.getMessage());
                    return false;
                }
            }
        }
        return true;
    }

    private boolean alignDeletedFlag() {
        try {
            jdbcTemplate.execute("UPDATE system_log SET deleted = 0 WHERE deleted IS NULL");
        } catch (Exception ex) {
            LOGGER.debug("Skipped aligning deleted flag in system_log table: {}", ex.getMessage());
            return false;
        }
        return true;
    }
}
