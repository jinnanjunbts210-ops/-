package com.minicloud.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/**
 * Makes sure the {@code user_notification} table exists even when Flyway
 * migrations were not executed. Some environments deploy the database manually,
 * and missing this table causes every approval操作触发通知失败。
 */
@Component
public class UserNotificationSchemaInitializer implements InitializingBean {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserNotificationSchemaInitializer.class);

    private final JdbcTemplate jdbcTemplate;

    public UserNotificationSchemaInitializer(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public void afterPropertiesSet() {
        createTableIfNecessary();
        createIndexesIfNecessary();
    }

    private void createTableIfNecessary() {
        String sql =
            "CREATE TABLE IF NOT EXISTS user_notification (\n" +
                "  id BIGINT NOT NULL AUTO_INCREMENT,\n" +
                "  user_id BIGINT NOT NULL,\n" +
                "  title VARCHAR(120) NOT NULL,\n" +
                "  message VARCHAR(500) DEFAULT NULL,\n" +
                "  link VARCHAR(255) DEFAULT NULL,\n" +
                "  read_flag TINYINT(1) DEFAULT 0,\n" +
                "  create_time DATETIME DEFAULT CURRENT_TIMESTAMP,\n" +
                "  deleted TINYINT(1) DEFAULT 0,\n" +
                "  PRIMARY KEY (id)\n" +
                ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
        try {
            jdbcTemplate.execute(sql);
        } catch (Exception ex) {
            LOGGER.warn("Failed to ensure user_notification table exists: {}", ex.getMessage());
        }
    }

    private void createIndexesIfNecessary() {
        try {
            jdbcTemplate.execute(
                "CREATE INDEX idx_notification_user ON user_notification (user_id, read_flag)"
            );
        } catch (Exception ex) {
            if (!ex.getMessage().contains("Duplicate key name")) {
                LOGGER.warn("Failed to create idx_notification_user index: {}", ex.getMessage());
            }
        }
    }
}
