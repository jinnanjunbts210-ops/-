package com.minicloud.controller;

import com.minicloud.dto.ApiResponse;
import com.minicloud.dto.DepartmentCreateRequest;
import com.minicloud.dto.DepartmentResponse;
import com.minicloud.dto.DepartmentUpdateRequest;
import com.minicloud.entity.Department;
import com.minicloud.entity.User;
import com.minicloud.security.UserPrincipal;
import com.minicloud.service.DepartmentService;
import com.minicloud.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/admin/departments")
@CrossOrigin(origins = "*", maxAge = 3600)
public class AdminDepartmentController {

    private final DepartmentService departmentService;
    private final UserService userService;

    public AdminDepartmentController(DepartmentService departmentService,
                                     UserService userService) {
        this.departmentService = departmentService;
        this.userService = userService;
    }

    private boolean isSystemAdmin(Long userId) {
        return userService.checkUserPermission(userId, "SYSTEM_ADMIN");
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<DepartmentResponse>>> listDepartments(
        @AuthenticationPrincipal UserPrincipal principal
    ) {
        if (principal == null || !isSystemAdmin(principal.getId())) {
            return ResponseEntity.status(403).body(ApiResponse.error("无权限执行该操作", 403));
        }
        List<DepartmentResponse> responses = departmentService.list().stream()
            .map(this::toResponse)
            .collect(Collectors.toList());
        return ResponseEntity.ok(ApiResponse.success(responses, "获取部门列表成功"));
    }

    @PostMapping
    public ResponseEntity<ApiResponse<DepartmentResponse>> createDepartment(
        @Valid @RequestBody DepartmentCreateRequest request,
        @AuthenticationPrincipal UserPrincipal principal
    ) {
        if (principal == null || !isSystemAdmin(principal.getId())) {
            return ResponseEntity.status(403).body(ApiResponse.error("无权限执行该操作", 403));
        }
        try {
            if (request.getParentId() != null && departmentService.getById(request.getParentId()) == null) {
                return ResponseEntity.badRequest().body(ApiResponse.error("上级部门不存在"));
            }
            if (request.getManagerId() != null) {
                User manager = userService.getById(request.getManagerId());
                if (manager == null) {
                    return ResponseEntity.badRequest().body(ApiResponse.error("部门管理员不存在"));
                }
            }
            Department department = new Department();
            department.setName(request.getName());
            department.setParentId(request.getParentId());
            department.setManagerId(request.getManagerId());
            if (request.getDepartmentSpaceSize() != null) {
                department.setDepartmentSpaceSize(request.getDepartmentSpaceSize());
            }
            department.setDescription(request.getDescription());
            if (request.getSortOrder() != null) {
                department.setSortOrder(request.getSortOrder());
            }

            Department created = departmentService.createDepartment(department);
            return ResponseEntity.ok(ApiResponse.success(toResponse(created), "创建部门成功"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "创建部门失败"));
        }
    }

    @PutMapping("/{departmentId}")
    public ResponseEntity<ApiResponse<DepartmentResponse>> updateDepartment(
        @PathVariable Long departmentId,
        @Valid @RequestBody DepartmentUpdateRequest request,
        @AuthenticationPrincipal UserPrincipal principal
    ) {
        if (principal == null || !isSystemAdmin(principal.getId())) {
            return ResponseEntity.status(403).body(ApiResponse.error("无权限执行该操作", 403));
        }
        try {
            if (request.getParentId() != null && departmentId.equals(request.getParentId())) {
                return ResponseEntity.badRequest().body(ApiResponse.error("上级部门不能为自身"));
            }
            if (request.getParentId() != null && departmentService.getById(request.getParentId()) == null) {
                return ResponseEntity.badRequest().body(ApiResponse.error("上级部门不存在"));
            }
            if (request.getManagerId() != null) {
                User manager = userService.getById(request.getManagerId());
                if (manager == null) {
                    return ResponseEntity.badRequest().body(ApiResponse.error("部门管理员不存在"));
                }
            }
            Department update = new Department();
            update.setName(request.getName());
            update.setParentId(request.getParentId());
            update.setManagerId(request.getManagerId());
            if (request.getDepartmentSpaceSize() != null) {
                update.setDepartmentSpaceSize(request.getDepartmentSpaceSize());
            }
            update.setDescription(request.getDescription());
            update.setSortOrder(request.getSortOrder());

            Department updated = departmentService.updateDepartment(departmentId, update);
            return ResponseEntity.ok(ApiResponse.success(toResponse(updated), "部门信息更新成功"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "部门信息更新失败"));
        }
    }

    @DeleteMapping("/{departmentId}")
    public ResponseEntity<ApiResponse<String>> deleteDepartment(
        @PathVariable Long departmentId,
        @AuthenticationPrincipal UserPrincipal principal
    ) {
        if (principal == null || !isSystemAdmin(principal.getId())) {
            return ResponseEntity.status(403).body(ApiResponse.error("无权限执行该操作", 403));
        }
        try {
            boolean success = departmentService.deleteDepartment(departmentId);
            if (success) {
                return ResponseEntity.ok(ApiResponse.success(null, "部门删除成功"));
            }
            return ResponseEntity.badRequest().body(ApiResponse.error("部门不存在"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "部门删除失败"));
        }
    }

    private DepartmentResponse toResponse(Department department) {
        DepartmentResponse response = new DepartmentResponse();
        response.setId(department.getId());
        response.setName(department.getName());
        response.setParentId(department.getParentId());
        response.setManagerId(department.getManagerId());
        response.setDepartmentSpaceSize(department.getDepartmentSpaceSize());
        response.setUsedSpaceSize(department.getUsedSpaceSize());
        response.setDescription(department.getDescription());
        response.setSortOrder(department.getSortOrder());
        response.setCreateTime(department.getCreateTime());
        response.setUpdateTime(department.getUpdateTime());
        return response;
    }
}

