package com.minicloud.controller;

import com.minicloud.dto.ApiResponse;
import com.minicloud.dto.SpaceCleanupResponse;
import com.minicloud.dto.SpaceOverviewResponse;
import com.minicloud.security.UserPrincipal;
import com.minicloud.service.FileService;
import com.minicloud.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/admin/spaces")
@CrossOrigin(origins = "*", maxAge = 3600)
public class AdminSpaceController {

    private final FileService fileService;
    private final UserService userService;

    public AdminSpaceController(FileService fileService,
                                UserService userService) {
        this.fileService = fileService;
        this.userService = userService;
    }

    private boolean isSystemAdmin(Long userId) {
        return userService.checkUserPermission(userId, "SYSTEM_ADMIN");
    }

    @GetMapping("/overview")
    public ResponseEntity<ApiResponse<SpaceOverviewResponse>> getOverview(
        @AuthenticationPrincipal UserPrincipal principal
    ) {
        if (principal == null || !isSystemAdmin(principal.getId())) {
            return ResponseEntity.status(403).body(ApiResponse.error("无权限执行该操作", 403));
        }
        SpaceOverviewResponse overview = fileService.getSpaceOverview();
        return ResponseEntity.ok(ApiResponse.success(overview, "获取空间概览成功"));
    }

    @PostMapping("/cleanup")
    public ResponseEntity<ApiResponse<SpaceCleanupResponse>> cleanup(
        @AuthenticationPrincipal UserPrincipal principal
    ) {
        if (principal == null || !isSystemAdmin(principal.getId())) {
            return ResponseEntity.status(403).body(ApiResponse.error("无权限执行该操作", 403));
        }
        SpaceCleanupResponse result = fileService.cleanupSystemGarbage();
        return ResponseEntity.ok(ApiResponse.success(result, "系统垃圾清理完成"));
    }
}

