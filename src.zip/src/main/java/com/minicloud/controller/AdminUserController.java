package com.minicloud.controller;

import com.minicloud.dto.AdminUserCreateRequest;
import com.minicloud.dto.AdminUserResponse;
import com.minicloud.dto.AdminUserUpdateRequest;
import com.minicloud.dto.ApiResponse;
import com.minicloud.dto.ResetPasswordAdminRequest;
import com.minicloud.dto.UserImportResult;
import com.minicloud.dto.UserSpaceUpdateRequest;
import com.minicloud.dto.UserStatusUpdateRequest;
import com.minicloud.entity.Department;
import com.minicloud.entity.User;
import com.minicloud.security.UserPrincipal;
import com.minicloud.service.DepartmentService;
import com.minicloud.service.FileService;
import com.minicloud.service.FileShareService;
import com.minicloud.service.UserImportService;
import com.minicloud.service.UserService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/admin/users")
@CrossOrigin(origins = "*", maxAge = 3600)
public class AdminUserController {

    private final UserService userService;
    private final FileService fileService;
    private final FileShareService fileShareService;
    private final DepartmentService departmentService;
    private final UserImportService userImportService;

    public AdminUserController(UserService userService,
                               FileService fileService,
                               FileShareService fileShareService,
                               DepartmentService departmentService,
                               UserImportService userImportService) {
        this.userService = userService;
        this.fileService = fileService;
        this.fileShareService = fileShareService;
        this.departmentService = departmentService;
        this.userImportService = userImportService;
    }

    private boolean isSystemAdmin(Long userId) {
        return userService.checkUserPermission(userId, "SYSTEM_ADMIN");
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<AdminUserResponse>>> listUsers(@AuthenticationPrincipal UserPrincipal principal) {
        if (principal == null || !isSystemAdmin(principal.getId())) {
            return ResponseEntity.status(403).body(ApiResponse.error("No permission to perform this operation", 403));
        }
        List<AdminUserResponse> users = userService.listAllUsers().stream()
            .map(this::buildAdminUserResponse)
            .collect(Collectors.toList());
        return ResponseEntity.ok(ApiResponse.success(users, "User list fetched successfully"));
    }

    @PostMapping
    public ResponseEntity<ApiResponse<AdminUserResponse>> createUser(
        @Valid @RequestBody AdminUserCreateRequest request,
        @AuthenticationPrincipal UserPrincipal principal
    ) {
        if (principal == null || !isSystemAdmin(principal.getId())) {
            return ResponseEntity.status(403).body(ApiResponse.error("No permission to perform this operation", 403));
        }
        try {
            if (request.getDepartmentId() != null
                && departmentService.getById(request.getDepartmentId()) == null) {
                return ResponseEntity.badRequest().body(ApiResponse.error("Department does not exist"));
            }
            User user = new User();
            user.setUsername(request.getUsername());
            user.setRealName(request.getRealName());
            user.setPhone(request.getPhone());
            user.setEmail(request.getEmail());
            user.setGender(request.getGender());
            user.setAge(request.getAge());
            user.setPosition(request.getPosition());
            user.setEmployeeNo(request.getEmployeeNo());
            user.setDepartmentId(request.getDepartmentId());
            user.setRoleType(normalizeRoleType(request.getRoleType()));
            user.setStatus(request.getStatus());
            user.setPersonalSpaceSize(request.getPersonalSpaceSize());
            applySubordinateViewSetting(user, request.getCanViewSubordinate(),
                request.getSubordinateViewType(), request.getSubordinateViewExpire());

            User created = userService.createUser(user, request.getPassword());
            return ResponseEntity.ok(ApiResponse.success(buildAdminUserResponse(created), "User created successfully"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Failed to create user"));
        }
    }

    @PutMapping("/{userId}")
    public ResponseEntity<ApiResponse<AdminUserResponse>> updateUser(
        @PathVariable Long userId,
        @Valid @RequestBody AdminUserUpdateRequest request,
        @AuthenticationPrincipal UserPrincipal principal
    ) {
        if (principal == null || !isSystemAdmin(principal.getId())) {
            return ResponseEntity.status(403).body(ApiResponse.error("No permission to perform this operation", 403));
        }
        try {
            User existing = userService.getById(userId);
            if (existing == null) {
                return ResponseEntity.badRequest().body(ApiResponse.error("User does not exist"));
            }
            Long originalDepartmentId = existing.getDepartmentId();

            if (Boolean.TRUE.equals(request.getClearDepartment())) {
                request.setDepartmentId(null);
            } else if (request.getDepartmentId() != null) {
                Department department = departmentService.getById(request.getDepartmentId());
                if (department == null) {
                    return ResponseEntity.badRequest().body(ApiResponse.error("Department does not exist"));
                }
            }

            User update = new User();
            update.setRealName(request.getRealName());
            update.setPhone(request.getPhone());
            update.setEmail(request.getEmail());
            update.setGender(request.getGender());
            update.setAge(request.getAge());
            update.setPosition(request.getPosition());
            update.setEmployeeNo(request.getEmployeeNo());
            update.setDepartmentId(request.getDepartmentId());
            if (request.getRoleType() != null) {
                update.setRoleType(normalizeRoleType(request.getRoleType()));
            }
            update.setStatus(request.getStatus());
            update.setPersonalSpaceSize(request.getPersonalSpaceSize());
            applySubordinateViewSetting(update, request.getCanViewSubordinate(),
                request.getSubordinateViewType(), request.getSubordinateViewExpire());

            User updated = userService.adminUpdateUser(userId, update, request.getPassword(), request.getClearDepartment());
            if (Boolean.TRUE.equals(request.getClearDepartment())) {
                departmentService.removeManagerAssignments(userId);
            } else if (request.getDepartmentId() != null
                && !Objects.equals(originalDepartmentId, request.getDepartmentId())) {
                departmentService.removeManagerAssignments(userId);
            }
            return ResponseEntity.ok(ApiResponse.success(buildAdminUserResponse(updated), "User information updated successfully"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Failed to update user information"));
        }
    }

    @DeleteMapping("/{userId}")
    public ResponseEntity<ApiResponse<String>> deleteUser(
        @PathVariable Long userId,
        @AuthenticationPrincipal UserPrincipal principal
    ) {
        if (principal == null || !isSystemAdmin(principal.getId())) {
            return ResponseEntity.status(403).body(ApiResponse.error("No permission to perform this operation", 403));
        }
        if (Objects.equals(principal.getId(), userId)) {
            return ResponseEntity.badRequest().body(ApiResponse.error("Cannot delete the currently logged-in administrator account"));
        }
        User target = userService.getById(userId);
        if (target == null) {
            return ResponseEntity.badRequest().body(ApiResponse.error("User does not exist"));
        }
        try {
            fileService.deleteUserPersonalSpace(userId);
            fileShareService.removeSharesRelatedToUser(userId);
            departmentService.removeManagerAssignments(userId);
            userService.deleteUser(userId);
            return ResponseEntity.ok(ApiResponse.success(null, "User deletion completed"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Failed to delete user"));
        }
    }

    @PutMapping("/{userId}/status")
    public ResponseEntity<ApiResponse<String>> updateStatus(
        @PathVariable Long userId,
        @Valid @RequestBody UserStatusUpdateRequest request,
        @AuthenticationPrincipal UserPrincipal principal
    ) {
        if (principal == null || !isSystemAdmin(principal.getId())) {
            return ResponseEntity.status(403).body(ApiResponse.error("No permission to perform this operation", 403));
        }
        boolean success = userService.updateUserStatus(userId, request.getStatus());
        if (success) {
            return ResponseEntity.ok(ApiResponse.success(null, "User status updated successfully"));
        }
        return ResponseEntity.badRequest().body(ApiResponse.error("Failed to update user status"));
    }

    @PutMapping("/{userId}/space")
    public ResponseEntity<ApiResponse<String>> updateSpace(
        @PathVariable Long userId,
        @Valid @RequestBody UserSpaceUpdateRequest request,
        @AuthenticationPrincipal UserPrincipal principal
    ) {
        if (principal == null || !isSystemAdmin(principal.getId())) {
            return ResponseEntity.status(403).body(ApiResponse.error("No permission to perform this operation", 403));
        }
        try {
            boolean success = userService.updateUserSpaceSize(userId, request.getSpaceSize());
            if (success) {
                return ResponseEntity.ok(ApiResponse.success(null, "User space updated successfully"));
            }
            return ResponseEntity.badRequest().body(ApiResponse.error("Failed to update user space"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Failed to update user space"));
        }
    }

    @PostMapping("/{userId}/reset-password")
    public ResponseEntity<ApiResponse<String>> resetPassword(
        @PathVariable Long userId,
        @Valid @RequestBody ResetPasswordAdminRequest request,
        @AuthenticationPrincipal UserPrincipal principal
    ) {
        if (principal == null || !isSystemAdmin(principal.getId())) {
            return ResponseEntity.status(403).body(ApiResponse.error("No permission to perform this operation", 403));
        }
        boolean success = userService.adminResetPassword(userId, request.getNewPassword());
        if (success) {
            return ResponseEntity.ok(ApiResponse.success(null, "User password reset successfully"));
        }
        return ResponseEntity.badRequest().body(ApiResponse.error("Failed to reset user password"));
    }

    private AdminUserResponse buildAdminUserResponse(User user) {
        AdminUserResponse response = new AdminUserResponse();
        response.setId(user.getId());
        response.setUsername(user.getUsername());
        response.setRealName(user.getRealName());
        response.setEmail(user.getEmail());
        response.setPhone(user.getPhone());
        response.setGender(user.getGender());
        response.setAge(user.getAge());
        response.setPosition(user.getPosition());
        response.setEmployeeNo(user.getEmployeeNo());
        response.setRoleType(user.getRoleType());
        response.setStatus(user.getStatus());
        response.setDepartmentId(user.getDepartmentId());
        response.setPersonalSpaceSize(user.getPersonalSpaceSize());
        response.setUsedSpaceSize(user.getUsedSpaceSize());
        response.setCanViewSubordinate(Boolean.TRUE.equals(user.getCanViewSubordinate()));
        response.setSubordinateViewType(user.getSubordinateViewType());
        response.setSubordinateViewExpire(user.getSubordinateViewExpire());
        response.setCreateTime(user.getCreateTime());
        response.setUpdateTime(user.getUpdateTime());
        return response;
    }

    private void applySubordinateViewSetting(User user,
                                             Boolean canView,
                                             Integer type,
                                             LocalDateTime expireTime) {
        if (canView == null) {
            return;
        }
        if (Boolean.TRUE.equals(canView)) {
            user.setCanViewSubordinate(true);
            int effectiveType = (type == null || type < 1 || type > 2) ? 1 : type;
            user.setSubordinateViewType(effectiveType);
            if (effectiveType == 2) {
                user.setSubordinateViewExpire(expireTime);
            } else {
                user.setSubordinateViewExpire(null);
            }
        } else {
            user.setCanViewSubordinate(false);
            user.setSubordinateViewType(0);
            user.setSubordinateViewExpire(null);
        }
    }

    private int normalizeRoleType(Integer roleType) {
        if (roleType == null) {
            return 0;
        }
        if (roleType < 0) {
            return 0;
        }
        if (roleType > 2) {
            return 2;
        }
        return roleType;
    }
    @GetMapping("/import/template")
    public ResponseEntity<byte[]> downloadImportTemplate() {
        byte[] data = userImportService.generateTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=UserImportTemplate.xlsx");
        return ResponseEntity.ok()
            .headers(headers)
            .body(data);
    }

    @PostMapping("/import")
    public ResponseEntity<ApiResponse<UserImportResult>> importUsers(
        @RequestParam("file") MultipartFile file,
        @AuthenticationPrincipal UserPrincipal userPrincipal
    ) {
        try {
            UserImportResult result = userImportService.importUsers(file, userPrincipal.getId());
            return ResponseEntity.ok(ApiResponse.success(result, "Import finished"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Import failed"));
        }
    }}



