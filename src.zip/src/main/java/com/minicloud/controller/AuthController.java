package com.minicloud.controller;

import com.minicloud.dto.ApiResponse;
import com.minicloud.dto.ChangePasswordRequest;
import com.minicloud.dto.JwtAuthenticationResponse;
import com.minicloud.dto.LoginRequest;
import com.minicloud.dto.RegisterRequest;
import com.minicloud.dto.ResetPasswordRequest;
import com.minicloud.dto.UserInfo;
import com.minicloud.entity.User;
import com.minicloud.security.JwtTokenProvider;
import com.minicloud.security.UserPrincipal;
import com.minicloud.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*", maxAge = 3600)
public class AuthController {

    private static final Logger log = LoggerFactory.getLogger(AuthController.class);

    private final AuthenticationManager authenticationManager;
    private final UserService userService;
    private final JwtTokenProvider tokenProvider;

    public AuthController(AuthenticationManager authenticationManager,
                          UserService userService,
                          JwtTokenProvider tokenProvider) {
        this.authenticationManager = authenticationManager;
        this.userService = userService;
        this.tokenProvider = tokenProvider;
    }

    @PostMapping("/login")
    public ResponseEntity<ApiResponse<JwtAuthenticationResponse>> authenticateUser(
        @Valid @RequestBody LoginRequest loginRequest) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword())
            );

            SecurityContextHolder.getContext().setAuthentication(authentication);

            String jwt = tokenProvider.generateToken(authentication);
            User user = userService.findByUsername(loginRequest.getUsername());
            if (user == null || user.getId() == null) {
                return ResponseEntity.badRequest().body(ApiResponse.error("User does not exist"));
            }

            UserInfo userInfo = buildUserInfo(user);
            JwtAuthenticationResponse response = new JwtAuthenticationResponse(jwt, "Bearer", userInfo);
            return ResponseEntity.ok(ApiResponse.success(response, "Login successful"));
        } catch (Exception e) {
            log.warn("Login failed for user '{}'", loginRequest.getUsername(), e);
            return ResponseEntity.badRequest().body(ApiResponse.error("Incorrect username or password"));
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<ApiResponse<String>> logout() {
        SecurityContextHolder.clearContext();
        return ResponseEntity.ok(ApiResponse.success(null, "Logged out successfully"));
    }

    @PostMapping("/register")
    public ResponseEntity<ApiResponse<String>> registerUser(@Valid @RequestBody RegisterRequest registerRequest) {
        try {
            User user = new User();
            user.setUsername(registerRequest.getUsername());
            user.setPassword(registerRequest.getPassword());
            user.setRealName(registerRequest.getRealName());
            user.setPhone(registerRequest.getPhone());
            user.setEmail(registerRequest.getEmail());
            user.setGender(registerRequest.getGender());
            user.setAge(registerRequest.getAge());
            user.setPosition(registerRequest.getPosition());
            user.setEmployeeNo(registerRequest.getEmployeeNo());
            user.setSecurityQuestion1(registerRequest.getSecurityQuestion1());
            user.setSecurityAnswer1(registerRequest.getSecurityAnswer1());
            user.setSecurityQuestion2(registerRequest.getSecurityQuestion2());
            user.setSecurityAnswer2(registerRequest.getSecurityAnswer2());
            user.setSecurityQuestion3(registerRequest.getSecurityQuestion3());
            user.setSecurityAnswer3(registerRequest.getSecurityAnswer3());
            user.setStatus(0);

            userService.register(user);
            return ResponseEntity.ok(ApiResponse.success(null, "Registration submitted, awaiting administrator approval"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Registration failed"));
        }
    }

    @PostMapping("/change-password")
    public ResponseEntity<ApiResponse<String>> changePassword(@RequestBody ChangePasswordRequest request) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !(authentication.getPrincipal() instanceof UserPrincipal)) {
                return ResponseEntity.badRequest().body(ApiResponse.error("Not authenticated"));
            }

            UserPrincipal principal = (UserPrincipal) authentication.getPrincipal();
            boolean success = userService.changePassword(principal.getId(), request.getOldPassword(), request.getNewPassword());
            if (success) {
                return ResponseEntity.ok(ApiResponse.success(null, "Password updated successfully"));
            }
            return ResponseEntity.badRequest().body(ApiResponse.error("Incorrect current password"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Failed to update password"));
        }
    }

    @PostMapping("/reset-password")
    public ResponseEntity<ApiResponse<String>> resetPassword(@RequestBody ResetPasswordRequest request) {
        try {
            boolean success = userService.resetPassword(request.getUsername(), request.getSecurityAnswers(), request.getNewPassword());
            if (success) {
                return ResponseEntity.ok(ApiResponse.success(null, "Password reset successfully"));
            }
            return ResponseEntity.badRequest().body(ApiResponse.error("Incorrect security answers"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Failed to reset password"));
        }
    }

    private UserInfo buildUserInfo(User user) {
        return new UserInfo(
            user.getId(),
            user.getUsername(),
            user.getRealName(),
            user.getEmail(),
            user.getPhone(),
            user.getGender(),
            user.getAge(),
            user.getPosition(),
            user.getEmployeeNo(),
            user.getRoleType() != null ? user.getRoleType() : 0,
            user.getDepartmentId(),
            user.getPersonalSpaceSize() != null ? user.getPersonalSpaceSize() : 0L,
            user.getUsedSpaceSize() != null ? user.getUsedSpaceSize() : 0L,
            user.getStatus(),
            Boolean.TRUE.equals(user.getCanViewSubordinate())
        );
    }
}

