package com.minicloud.controller;

import com.minicloud.dto.ApprovalActionRequest;
import com.minicloud.dto.ApprovalAttachment;
import com.minicloud.dto.ApprovalCreateRequest;
import com.minicloud.dto.ApiResponse;
import com.minicloud.entity.FileApproval;
import com.minicloud.security.UserPrincipal;
import com.minicloud.service.FileApprovalService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.util.List;

/**
 * 审批流程控制器
 */
@RestController
@RequestMapping("/api/approvals")
@CrossOrigin(origins = "*", maxAge = 3600)
public class FileApprovalController {

    private final FileApprovalService fileApprovalService;

    public FileApprovalController(FileApprovalService fileApprovalService) {
        this.fileApprovalService = fileApprovalService;
    }

    /**
     * 创建审批申请
     */
    @PostMapping
    public ResponseEntity<ApiResponse<FileApproval>> createApproval(
        @Valid @RequestBody ApprovalCreateRequest request,
        @AuthenticationPrincipal UserPrincipal userPrincipal
    ) {
        try {
            FileApproval approval = fileApprovalService.createApproval(userPrincipal.getId(), request);
            return ResponseEntity.ok(ApiResponse.success(approval, "审批申请提交成功"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "审批申请提交失败"));
        }
    }

    @PostMapping("/attachments")
    public ResponseEntity<ApiResponse<List<ApprovalAttachment>>> uploadAttachments(
        @RequestParam("files") MultipartFile[] files,
        @AuthenticationPrincipal UserPrincipal userPrincipal
    ) {
        try {
            List<ApprovalAttachment> attachments = fileApprovalService.uploadAttachments(userPrincipal.getId(), files);
            return ResponseEntity.ok(ApiResponse.success(attachments, "附件上传成功"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "附件上传失败"));
        }
    }

    @GetMapping("/{approvalId}/attachments")
    public ResponseEntity<ApiResponse<List<ApprovalAttachment>>> listAttachments(
        @PathVariable Long approvalId,
        @AuthenticationPrincipal UserPrincipal userPrincipal
    ) {
        try {
            List<ApprovalAttachment> attachments = fileApprovalService.getAttachments(approvalId, userPrincipal.getId());
            return ResponseEntity.ok(ApiResponse.success(attachments, "获取附件成功"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "获取附件失败"));
        }
    }

    /**
     * 获取我发起的审批列表
     */
    @GetMapping("/applications")
    public ResponseEntity<ApiResponse<List<FileApproval>>> listMyApplications(
        @AuthenticationPrincipal UserPrincipal userPrincipal
    ) {
        try {
            List<FileApproval> approvals = fileApprovalService.listMyApplications(userPrincipal.getId());
            return ResponseEntity.ok(ApiResponse.success(approvals, "获取审批申请列表成功"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "获取审批申请列表失败"));
        }
    }

    /**
     * 获取待我审批的列表
     */
    @GetMapping("/pending")
    public ResponseEntity<ApiResponse<List<FileApproval>>> listPendingApprovals(
        @AuthenticationPrincipal UserPrincipal userPrincipal
    ) {
        try {
            List<FileApproval> approvals = fileApprovalService.listPendingApprovals(userPrincipal.getId());
            return ResponseEntity.ok(ApiResponse.success(approvals, "获取待审批列表成功"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "获取待审批列表失败"));
        }
    }

    /**
     * 获取我的审批历史
     */
    @GetMapping("/history")
    public ResponseEntity<ApiResponse<List<FileApproval>>> listApprovalHistory(
        @AuthenticationPrincipal UserPrincipal userPrincipal
    ) {
        try {
            List<FileApproval> approvals = fileApprovalService.listApprovalHistory(userPrincipal.getId());
            return ResponseEntity.ok(ApiResponse.success(approvals, "获取审批历史成功"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "获取审批历史失败"));
        }
    }

    /**
     * 审批通过
     */
    @PostMapping("/{approvalId}/approve")
    public ResponseEntity<ApiResponse<FileApproval>> approve(
        @PathVariable Long approvalId,
        @Valid @RequestBody ApprovalActionRequest request,
        @AuthenticationPrincipal UserPrincipal userPrincipal
    ) {
        try {
            FileApproval approval = fileApprovalService.approve(userPrincipal.getId(), approvalId, request);
            return ResponseEntity.ok(ApiResponse.success(approval, "审批已通过"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "审批通过失败"));
        }
    }

    /**
     * 审批驳回
     */
    @PostMapping("/{approvalId}/reject")
    public ResponseEntity<ApiResponse<FileApproval>> reject(
        @PathVariable Long approvalId,
        @Valid @RequestBody ApprovalActionRequest request,
        @AuthenticationPrincipal UserPrincipal userPrincipal
    ) {
        try {
            FileApproval approval = fileApprovalService.reject(userPrincipal.getId(), approvalId, request);
            return ResponseEntity.ok(ApiResponse.success(approval, "审批已驳回"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "审批驳回失败"));
        }
    }
}
