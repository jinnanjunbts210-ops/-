package com.minicloud.controller;



import com.baomidou.mybatisplus.core.metadata.IPage;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import com.minicloud.annotation.OperationLog;
import com.minicloud.dto.ApiResponse;

import com.minicloud.dto.CreateDirectoryRequest;

import com.minicloud.entity.FileInfo;

import com.minicloud.security.UserPrincipal;

import com.minicloud.service.FileService;



import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpHeaders;

import org.springframework.http.MediaType;

import org.springframework.http.ResponseEntity;

import org.springframework.security.core.annotation.AuthenticationPrincipal;

import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.DeleteMapping;

import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.PutMapping;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import org.springframework.web.multipart.MultipartFile;



import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;

import java.io.IOException;

import java.io.InputStream;

import java.net.URLEncoder;

import java.nio.charset.StandardCharsets;

import java.util.*;

import java.util.stream.Collectors;



@RestController

@RequestMapping("/api/files")

@CrossOrigin(origins = "*", maxAge = 3600)

public class FileController {



    private final FileService fileService;



    public FileController(FileService fileService) {

        this.fileService = fileService;

    }



    @PostMapping("/upload")
    public ResponseEntity<ApiResponse<FileInfo>> uploadFile(
        @RequestParam("file") MultipartFile file,
        @RequestParam(value = "parentId", required = false) Long parentId,
        @RequestParam(value = "spaceType", defaultValue = "0") Integer spaceType,
        @RequestParam(value = "spaceId", required = false) Long spaceId,
        @AuthenticationPrincipal UserPrincipal userPrincipal
    ) {
        try {
            FileInfo fileInfo = fileService.uploadFile(file, parentId, spaceType, spaceId, userPrincipal.getId());
            return ResponseEntity.ok(ApiResponse.success(fileInfo, "File uploaded successfully"));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "File upload failed"));
        }
    }

    @PostMapping("/upload-chunk")
    public ResponseEntity<ApiResponse<FileInfo>> uploadChunk(
        @RequestParam("chunk") MultipartFile chunk,
        @RequestParam("chunkNumber") Integer chunkNumber,
        @RequestParam("totalChunks") Integer totalChunks,
        @RequestParam("fileName") String fileName,
        @RequestParam("fileSize") Long fileSize,
        @RequestParam("md5") String md5,
        @RequestParam(value = "parentId", required = false) Long parentId,
        @RequestParam(value = "spaceType", defaultValue = "0") Integer spaceType,
        @RequestParam(value = "spaceId", required = false) Long spaceId,
        @AuthenticationPrincipal UserPrincipal userPrincipal
    ) {
        try {
            FileInfo fileInfo = fileService.uploadChunk(
                chunk, chunkNumber, totalChunks, fileName, fileSize, md5, parentId, spaceType, spaceId, userPrincipal.getId()
            );
            String message = fileInfo != null ? "File upload finished" : "Chunk upload succeeded";
            return ResponseEntity.ok(ApiResponse.success(fileInfo, message));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Chunk upload failed"));
        }
    }

    @RequestMapping(value = "/download/{fileId}", method = {RequestMethod.GET, RequestMethod.POST})
    public void downloadByPath(
        @PathVariable Long fileId,
        @AuthenticationPrincipal UserPrincipal userPrincipal,
        HttpServletResponse response
    ) {
        streamFileToResponse(fileId, userPrincipal, response);
    }

    @RequestMapping(value = "/download", method = {RequestMethod.GET, RequestMethod.POST})
    public void downloadByAny(
        @RequestParam(value = "fileId", required = false) Long fileId,
        @RequestBody(required = false) Map<String, Object> body,
        HttpServletRequest request,
        @AuthenticationPrincipal UserPrincipal userPrincipal,
        HttpServletResponse response
    ) throws IOException {
        Long resolvedId = resolveFileId(fileId, body, request);
        if (resolvedId == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "fileId is required");
            return;
        }
        streamFileToResponse(resolvedId, userPrincipal, response);
    }

    private Long resolveFileId(Long param, Map<String, Object> body, HttpServletRequest request) {
        if (param != null) return param;
        if (body != null) {
            Object v = body.get("fileId");
            if (v instanceof Number) return ((Number) v).longValue();
            if (v instanceof String) {
                try {
                    return Long.parseLong((String) v);
                } catch (NumberFormatException ignored) {
                }
            }
        }
        if (request != null) {
            String v = request.getParameter("fileId");
            if (v != null && !v.isEmpty()) {
                try {
                    return Long.parseLong(v);
                } catch (NumberFormatException ignored) {
                }
            }
        }
        return null;
    }
    private void streamFileToResponse(Long fileId,

                                      UserPrincipal userPrincipal,

                                      HttpServletResponse response) {

        if (fileId == null) {

            writeError(response, HttpServletResponse.SC_BAD_REQUEST, "Missing file ID");

            return;

        }

        if (userPrincipal == null) {

            writeError(response, HttpServletResponse.SC_UNAUTHORIZED, "Not authenticated or session expired");

            return;

        }

        try (InputStream inputStream = fileService.downloadFile(fileId, userPrincipal.getId())) {

            FileInfo fileInfo = fileService.getById(fileId);

            if (fileInfo == null) {

                throw new RuntimeException("File does not exist");

            }



            String fileName = fileInfo.getFileName() != null ? fileInfo.getFileName() : "unknown";

            String encodedFileName = URLEncoder.encode(fileName, StandardCharsets.UTF_8);

            response.setContentType(fileInfo.getMimeType() != null ? fileInfo.getMimeType() : MediaType.APPLICATION_OCTET_STREAM_VALUE);

            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + encodedFileName + "\"");

            response.setHeader(HttpHeaders.CONTENT_LENGTH, String.valueOf(fileInfo.getFileSize() != null ? fileInfo.getFileSize() : 0));



            byte[] buffer = new byte[8192];

            int len;

            while ((len = inputStream.read(buffer)) != -1) {

                response.getOutputStream().write(buffer, 0, len);

            }

            response.flushBuffer();

        } catch (Exception e) {

            writeError(response, HttpServletResponse.SC_BAD_REQUEST, e.getMessage() != null ? e.getMessage() : "File download failed");

        }

    }



    private void writeError(HttpServletResponse response, int status, String message) {

        try {

            response.setStatus(status);

            response.getWriter().write(message);

        } catch (IOException ignored) {

        }

    }



    @GetMapping("/preview/{fileId}")

    public ResponseEntity<ApiResponse<String>> getPreviewUrl(@PathVariable Long fileId,

                                                             @AuthenticationPrincipal UserPrincipal userPrincipal) {

        try {

            String previewUrl = fileService.getPreviewUrl(fileId, userPrincipal.getId());

            return ResponseEntity.ok(ApiResponse.success(previewUrl, "Preview URL retrieved successfully"));

        } catch (Exception e) {

            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Failed to retrieve preview URL"));

        }

    }



    @PostMapping("/directory")

    public ResponseEntity<ApiResponse<FileInfo>> createDirectory(

        @RequestBody CreateDirectoryRequest request,

        @AuthenticationPrincipal UserPrincipal userPrincipal

    ) {

        try {

            String directoryName = request.getName() != null ? request.getName().trim() : null;

            if (directoryName == null || directoryName.isEmpty()) {

                return ResponseEntity.badRequest().body(ApiResponse.error("Directory name cannot be empty"));

            }

            Integer spaceType = request.getSpaceType() != null ? request.getSpaceType() : 0;

            FileInfo directory = fileService.createDirectory(

                directoryName,

                request.getParentId(),

                spaceType,

                request.getSpaceId(),

                userPrincipal.getId()

            );

            return ResponseEntity.ok(ApiResponse.success(directory, "Directory created successfully"));

        } catch (Exception e) {

            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Failed to create directory"));

        }

    }



    @DeleteMapping("/{fileId}")

    public ResponseEntity<ApiResponse<String>> deleteFile(@PathVariable Long fileId,

                                                          @AuthenticationPrincipal UserPrincipal userPrincipal) {

        try {

            boolean success = fileService.deleteFile(fileId, userPrincipal.getId());

            if (success) {

                return ResponseEntity.ok(ApiResponse.success(null, "File deleted successfully"));

            }

            return ResponseEntity.badRequest().body(ApiResponse.error("Failed to delete file"));

        } catch (Exception e) {

            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Failed to delete file"));

        }

    }



    @DeleteMapping("/{fileId}/permanent")

    public ResponseEntity<ApiResponse<String>> permanentDeleteFile(@PathVariable Long fileId,

                                                                   @AuthenticationPrincipal UserPrincipal userPrincipal) {

        try {

            boolean success = fileService.permanentDeleteFile(fileId, userPrincipal.getId());

            if (success) {

                return ResponseEntity.ok(ApiResponse.success(null, "File permanently deleted successfully"));

            }

            return ResponseEntity.badRequest().body(ApiResponse.error("Failed to permanently delete file"));

        } catch (Exception e) {

            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Failed to permanently delete file"));

        }

    }



    // DELETE /api/files/delete?ids=1,2,3

    @DeleteMapping("/delete")

    public ResponseEntity<ApiResponse<String>> deleteFilesByQuery(

        @RequestParam("ids") String idsCsv,

        @AuthenticationPrincipal UserPrincipal userPrincipal

    ) {

    List<Long> ids = Arrays.stream(idsCsv.split(","))

            .map(String::trim)

            .filter(s -> !s.isEmpty())

            .map(Long::valueOf)

            .collect(Collectors.toList());

    return doBatchDelete(ids, userPrincipal.getId());

    }



   // POST /api/files/delete   body: { "ids": [1,2,3] }

    @PostMapping("/delete")

    public ResponseEntity<ApiResponse<String>> deleteFilesByBody(

        @RequestBody(required = false) Map<String, Object> body,

        @AuthenticationPrincipal UserPrincipal userPrincipal

   )  {

    List<Long> ids = new ArrayList<>();

    if (body != null && body.get("ids") instanceof Collection) {

        for (Object o : (Collection<?>) body.get("ids")) {

            ids.add(Long.valueOf(String.valueOf(o)));

        }

    }

    if (ids.isEmpty()) {

        return ResponseEntity.badRequest().body(ApiResponse.error("ids cannot be empty"));

    }

    return doBatchDelete(ids, userPrincipal.getId());

   }



    @PostMapping("/{fileId}/restore")

    public ResponseEntity<ApiResponse<String>> restoreFile(@PathVariable Long fileId,

                                                           @AuthenticationPrincipal UserPrincipal userPrincipal) {

        try {

            boolean success = fileService.restoreFile(fileId, userPrincipal.getId());

            if (success) {

                return ResponseEntity.ok(ApiResponse.success(null, "File restored successfully"));

            }

            return ResponseEntity.badRequest().body(ApiResponse.error("Failed to restore file"));

        } catch (Exception e) {

            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Failed to restore file"));

        }

    }

    private ResponseEntity<ApiResponse<String>> doBatchDelete(List<Long> ids, Long userId) {

    try {

        for (Long id : ids) {



            fileService.deleteFile(id, userId);

        }

        return ResponseEntity.ok(ApiResponse.success("Deleted successfully"));

    } catch (Exception e) {

        String msg = (e.getMessage() != null) ? e.getMessage() : "Delete failed";

        return ResponseEntity.badRequest().body(ApiResponse.error(msg));

        }

    }



    @PutMapping("/{fileId}/rename")

    public ResponseEntity<ApiResponse<String>> renameFile(@PathVariable Long fileId,

                                                          @RequestParam("newName") String newName,

                                                          @AuthenticationPrincipal UserPrincipal userPrincipal) {

        try {

            boolean success = fileService.renameFile(fileId, newName, userPrincipal.getId());

            if (success) {

                return ResponseEntity.ok(ApiResponse.success(null, "File renamed successfully"));

            }

            return ResponseEntity.badRequest().body(ApiResponse.error("Failed to rename file"));

        } catch (Exception e) {

            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Failed to rename file"));

        }

    }



    @PutMapping("/{fileId}/move")

    public ResponseEntity<ApiResponse<String>> moveFile(@PathVariable Long fileId,

                                                        @RequestParam(value = "targetParentId", required = false) Long targetParentId,

                                                        @AuthenticationPrincipal UserPrincipal userPrincipal) {

        try {

            boolean success = fileService.moveFile(fileId, targetParentId, userPrincipal.getId());

            if (success) {

                return ResponseEntity.ok(ApiResponse.success(null, "File moved successfully"));

            }

            return ResponseEntity.badRequest().body(ApiResponse.error("Failed to move file"));

        } catch (Exception e) {

            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Failed to move file"));

        }

    }



    @PostMapping("/{fileId}/copy")

    public ResponseEntity<ApiResponse<FileInfo>> copyFile(@PathVariable Long fileId,

                                                          @RequestParam(value = "targetParentId", required = false) Long targetParentId,

                                                          @AuthenticationPrincipal UserPrincipal userPrincipal) {

        try {

            FileInfo copiedFile = fileService.copyFile(fileId, targetParentId, userPrincipal.getId());

            return ResponseEntity.ok(ApiResponse.success(copiedFile, "File copied successfully"));

        } catch (Exception e) {

            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Failed to copy file"));

        }

    }

    @Autowired

    private com.minicloud.service.impl.FileServiceImpl fileServiceImpl;



    @GetMapping("/list")

    public ResponseEntity<ApiResponse<List<FileInfo>>> getFileList(

          @RequestParam(value = "parentId", required = false) Long parentId,

          @RequestParam(value = "spaceType", defaultValue = "0") Integer spaceType,

          @RequestParam(value = "spaceId", required = false) Long spaceId,

          @AuthenticationPrincipal UserPrincipal userPrincipal

    ) {

        try {

        // Fallback for enterprise space: require spaceId and query file_info directly.

            if (Integer.valueOf(2).equals(spaceType)) {

               if (spaceId == null) {

                return ResponseEntity.ok(ApiResponse.success(Collections.emptyList(), "File list retrieved successfully"));

            }

            List<FileInfo> list = fileServiceImpl.listBySpaceDirect(spaceId, 2, parentId);

            return ResponseEntity.ok(ApiResponse.success(list, "File list retrieved successfully"));

        }



        // Other types use original logic.

        List<FileInfo> files = fileService.getFileList(parentId, spaceType, spaceId, userPrincipal.getId());

        return ResponseEntity.ok(ApiResponse.success(files, "File list retrieved successfully"));

    } catch (Exception e) {

        return ResponseEntity.badRequest()

            .body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Failed to retrieve file list"));

    }

}





    @GetMapping("/search")

    public ResponseEntity<ApiResponse<IPage<FileInfo>>> searchFiles(

        @RequestParam("keyword") String keyword,

        @RequestParam(value = "spaceType", defaultValue = "0") Integer spaceType,

        @RequestParam(value = "spaceId", required = false) Long spaceId,

        @RequestParam(value = "page", defaultValue = "1") Integer page,

        @RequestParam(value = "size", defaultValue = "20") Integer size,

        @AuthenticationPrincipal UserPrincipal userPrincipal

    ) {

        try {

            Page<FileInfo> pageObj = new Page<>(page.longValue(), size.longValue());

            IPage<FileInfo> result = fileService.searchFiles(

                keyword, spaceType, spaceId, userPrincipal.getId(), pageObj);

            return ResponseEntity.ok(ApiResponse.success(result, "File search succeeded"));

        } catch (Exception e) {

            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Failed to search files"));

        }

    }



    @GetMapping("/recycle")

    public ResponseEntity<ApiResponse<List<FileInfo>>> getRecycledFiles(

        @AuthenticationPrincipal UserPrincipal userPrincipal

    ) {

        try {

            List<FileInfo> files = fileService.getRecycledFiles(userPrincipal.getId());

            return ResponseEntity.ok(ApiResponse.success(files, "Recycle bin files retrieved successfully"));

        } catch (Exception e) {

            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Failed to fetch recycle bin files"));

        }

    }



    // 1) List: GET /api/files/recycle/list (compat for frontend files.ts)

@GetMapping("/recycle/list")

public ResponseEntity<ApiResponse<List<FileInfo>>> listRecycle(

    @AuthenticationPrincipal UserPrincipal userPrincipal

) {

    try {

        List<FileInfo> files = fileService.getRecycledFiles(userPrincipal.getId());

        return ResponseEntity.ok(ApiResponse.success(files, "Recycle bin files retrieved successfully"));

    } catch (Exception e) {

        return ResponseEntity.badRequest()

            .body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Failed to fetch recycle bin files"));

    }

}



// 2) Restore: POST /api/files/recycle/restore   body: { id }

@PostMapping("/recycle/restore")

public ResponseEntity<ApiResponse<String>> restoreFromRecycle(

    @RequestBody Map<String, Long> body,

    @AuthenticationPrincipal UserPrincipal userPrincipal

) {

    Long id = body.get("id");

    try {

        boolean ok = fileService.restoreFile(id, userPrincipal.getId());

        return ok

            ? ResponseEntity.ok(ApiResponse.success(null, "File restored successfully"))

            : ResponseEntity.badRequest().body(ApiResponse.error("Failed to restore file"));

    } catch (Exception e) {

        return ResponseEntity.badRequest()

            .body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Failed to restore file"));

    }

}



// 3) Clear: POST /api/files/recycle/clear (keep DELETE /recycle/clear and add POST for frontend)

@PostMapping("/recycle/clear")

public ResponseEntity<ApiResponse<String>> clearRecycleCompat(

    @AuthenticationPrincipal UserPrincipal userPrincipal

) {

    try {

        boolean ok = fileService.clearRecycleBin(userPrincipal.getId());

        return ok

            ? ResponseEntity.ok(ApiResponse.success(null, "Recycle bin cleared successfully"))

            : ResponseEntity.badRequest().body(ApiResponse.error("Failed to clear recycle bin"));

    } catch (Exception e) {

        return ResponseEntity.badRequest()

            .body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Failed to clear recycle bin"));

    }

}



// 4) Permanent delete: POST /api/files/recycle/delete   body: { id }

@PostMapping("/recycle/delete")

public ResponseEntity<ApiResponse<String>> permanentDeleteCompat(

    @RequestBody Map<String, Long> body,

    @AuthenticationPrincipal UserPrincipal userPrincipal

) {

    Long id = body.get("id");

    try {

        boolean ok = fileService.permanentDeleteFile(id, userPrincipal.getId());

        return ok

            ? ResponseEntity.ok(ApiResponse.success(null, "File permanently deleted successfully"))

            : ResponseEntity.badRequest().body(ApiResponse.error("Failed to permanently delete file"));

    } catch (Exception e) {

        return ResponseEntity.badRequest()

            .body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Failed to permanently delete file"));

    }

}





    @GetMapping("/{fileId}/path")

    public ResponseEntity<ApiResponse<String>> getFilePath(@PathVariable Long fileId,

                                                           @AuthenticationPrincipal UserPrincipal userPrincipal) {

        try {

            String path = fileService.getFilePath(fileId);

            return ResponseEntity.ok(ApiResponse.success(path, "File path retrieved successfully"));

        } catch (Exception e) {

            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Failed to retrieve file path"));

        }

    }



}
