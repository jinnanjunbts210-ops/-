package com.minicloud.controller;

import com.minicloud.dto.ApiResponse;
import com.minicloud.dto.FilePreviewResponse;
import com.minicloud.entity.FileInfo;
import com.minicloud.security.UserPrincipal;
import com.minicloud.service.FileService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

@RestController
@RequestMapping("/api/file-preview")
@CrossOrigin(origins = "*", maxAge = 3600)
public class FilePreviewController {

    private final FileService fileService;

    public FilePreviewController(FileService fileService) {
        this.fileService = fileService;
    }

    @GetMapping("/{fileId}")
    public ResponseEntity<ApiResponse<FilePreviewResponse>> getPreview(
        @PathVariable Long fileId,
        @AuthenticationPrincipal UserPrincipal userPrincipal
    ) {
        try {
            FileInfo fileInfo = fileService.getById(fileId);
            if (fileInfo == null) {
                throw new RuntimeException("File not found");
            }
            if (Objects.equals(fileInfo.getDirectory(), 1)) {
                throw new RuntimeException("Preview is not supported for directories");
            }
            String downloadUrl = fileService.getPreviewUrl(fileId, userPrincipal.getId());
            String previewType = resolvePreviewType(fileInfo);
            String previewUrl = downloadUrl;
            if ("office".equals(previewType)) {
                previewUrl = "https://view.officeapps.live.com/op/view.aspx?src=" + URLEncoder.encode(downloadUrl, StandardCharsets.UTF_8);
            }
            FilePreviewResponse response = new FilePreviewResponse(previewType, previewUrl, downloadUrl);
            return ResponseEntity.ok(ApiResponse.success(response, "Preview link generated"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "Preview failed"));
        }
    }

    private String resolvePreviewType(FileInfo fileInfo) {
        String mime = fileInfo.getMimeType();
        String ext = fileInfo.getFileType() != null ? fileInfo.getFileType().toLowerCase() : null;
        if (mime != null) {
            if (mime.startsWith("image/")) return "image";
            if (mime.startsWith("audio/")) return "audio";
            if (mime.startsWith("video/")) return "video";
            if (mime.equals("application/pdf")) return "pdf";
        }
        if (ext != null) {
            if (ext.matches("(?i)(jpg|jpeg|png|gif|bmp|webp)")) return "image";
            if (ext.matches("(?i)(mp3|wav|flac)")) return "audio";
            if (ext.matches("(?i)(mp4|mov|avi|mkv)")) return "video";
            if (ext.matches("(?i)(pdf)")) return "pdf";
            if (ext.matches("(?i)(doc|docx|xls|xlsx|ppt|pptx)")) return "office";
        }
        return "download";
    }
}
