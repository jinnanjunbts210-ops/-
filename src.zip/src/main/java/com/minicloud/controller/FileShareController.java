package com.minicloud.controller;

import com.minicloud.dto.ApiResponse;
import com.minicloud.dto.ShareCreateRequest;
import com.minicloud.dto.ShareInfoResponse;
import com.minicloud.dto.SharePermissionRequest;
import com.minicloud.security.UserPrincipal;
import com.minicloud.service.FileShareService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/shares")
@CrossOrigin(origins = "*", maxAge = 3600)
public class FileShareController {

    private final FileShareService fileShareService;

    public FileShareController(FileShareService fileShareService) {
        this.fileShareService = fileShareService;
    }

    @PostMapping
    public ResponseEntity<ApiResponse<Object>> createShare(
        @Valid @RequestBody ShareCreateRequest request,
        @AuthenticationPrincipal UserPrincipal userPrincipal
    ) {
        try {
            Object shares = fileShareService.batchShare(
                request.getFileIds(),
                userPrincipal.getId(),
                request.getShareType(),
                request.getTargetIds(),
                request.getPermissions().toPermissionMap(),
                request.getExpireTime()
            );
            return ResponseEntity.ok(ApiResponse.success(shares, "分享创建成功"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "分享创建失败"));
        }
    }

    @PutMapping("/{shareId}")
    public ResponseEntity<ApiResponse<String>> updateShare(
        @PathVariable Long shareId,
        @Valid @RequestBody SharePermissionRequest request,
        @AuthenticationPrincipal UserPrincipal userPrincipal
    ) {
        try {
            boolean success = fileShareService.updateSharePermissions(
                shareId,
                userPrincipal.getId(),
                request.toPermissionMap()
            );
            if (success) {
                return ResponseEntity.ok(ApiResponse.success(null, "分享权限更新成功"));
            }
            return ResponseEntity.badRequest().body(ApiResponse.error("分享权限更新失败"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "分享权限更新失败"));
        }
    }

    @DeleteMapping("/{shareId}")
    public ResponseEntity<ApiResponse<String>> cancelShare(
        @PathVariable Long shareId,
        @AuthenticationPrincipal UserPrincipal userPrincipal
    ) {
        try {
            boolean success = fileShareService.cancelShare(shareId, userPrincipal.getId());
            if (success) {
                return ResponseEntity.ok(ApiResponse.success(null, "分享已取消"));
            }
            return ResponseEntity.badRequest().body(ApiResponse.error("分享不存在或已取消"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "取消分享失败"));
        }
    }

    @GetMapping("/mine")
    public ResponseEntity<ApiResponse<List<ShareInfoResponse>>> getMyShares(
        @AuthenticationPrincipal UserPrincipal userPrincipal
    ) {
        try {
            List<ShareInfoResponse> shares = fileShareService.getUserShares(userPrincipal.getId());
            return ResponseEntity.ok(ApiResponse.success(shares, "获取分享列表成功"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "获取分享列表失败"));
        }
    }

    @GetMapping("/received")
    public ResponseEntity<ApiResponse<List<ShareInfoResponse>>> getReceivedShares(
        @AuthenticationPrincipal UserPrincipal userPrincipal
    ) {
        try {
            List<ShareInfoResponse> shares = fileShareService.getSharedToUser(userPrincipal.getId());
            return ResponseEntity.ok(ApiResponse.success(shares, "获取分享内容成功"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "获取分享内容失败"));
        }
    }

    @DeleteMapping("/received")
    public ResponseEntity<ApiResponse<String>> removeReceivedShares(
        @RequestBody Map<String, List<Long>> body,
        @AuthenticationPrincipal UserPrincipal userPrincipal
    ) {
        List<Long> shareIds = body != null ? body.get("shareIds") : null;
        if (shareIds == null || shareIds.isEmpty()) {
            return ResponseEntity.badRequest().body(ApiResponse.error("shareIds 不能为空"));
        }

        try {
            boolean success = fileShareService.removeReceivedShares(shareIds, userPrincipal.getId());
            if (success) {
                return ResponseEntity.ok(ApiResponse.success(null, "分享已移除"));
            }
            return ResponseEntity.badRequest().body(ApiResponse.error("未找到可移除的分享"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "移除分享失败"));
        }
    }

    @GetMapping("/file/{fileId}")
    public ResponseEntity<ApiResponse<List<ShareInfoResponse>>> getFileShareInfo(
        @PathVariable Long fileId,
        @AuthenticationPrincipal UserPrincipal userPrincipal
    ) {
        try {
            List<ShareInfoResponse> shares = fileShareService.getFileShareInfo(fileId);
            return ResponseEntity.ok(ApiResponse.success(shares, "获取分享信息成功"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "获取分享信息失败"));
        }
    }
}

