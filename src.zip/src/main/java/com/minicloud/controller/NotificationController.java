package com.minicloud.controller;

import com.minicloud.dto.ApiResponse;
import com.minicloud.entity.UserNotification;
import com.minicloud.security.UserPrincipal;
import com.minicloud.service.UserNotificationService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/notifications")
@CrossOrigin(origins = "*", maxAge = 3600)
public class NotificationController {

    private final UserNotificationService notificationService;

    public NotificationController(UserNotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<UserNotification>>> listNotifications(
        @AuthenticationPrincipal UserPrincipal userPrincipal,
        @RequestParam(value = "unreadOnly", defaultValue = "false") boolean unreadOnly,
        @RequestParam(value = "limit", defaultValue = "0") int limit
    ) {
        List<UserNotification> notifications = notificationService.listNotifications(userPrincipal.getId(), unreadOnly, limit);
        return ResponseEntity.ok(ApiResponse.success(notifications, "获取通知成功"));
    }

    @GetMapping("/unread-count")
    public ResponseEntity<ApiResponse<Long>> unreadCount(@AuthenticationPrincipal UserPrincipal userPrincipal) {
        long count = notificationService.countUnread(userPrincipal.getId());
        return ResponseEntity.ok(ApiResponse.success(count, "获取未读数量成功"));
    }

    @PostMapping("/{id}/read")
    public ResponseEntity<ApiResponse<String>> markAsRead(
        @AuthenticationPrincipal UserPrincipal userPrincipal,
        @PathVariable("id") Long notificationId
    ) {
        notificationService.markAsRead(userPrincipal.getId(), notificationId);
        return ResponseEntity.ok(ApiResponse.success(null, "通知已标记为已读"));
    }

    @PostMapping("/read-all")
    public ResponseEntity<ApiResponse<String>> markAllAsRead(@AuthenticationPrincipal UserPrincipal userPrincipal) {
        notificationService.markAllAsRead(userPrincipal.getId());
        return ResponseEntity.ok(ApiResponse.success(null, "全部通知已标记为已读"));
    }
}
