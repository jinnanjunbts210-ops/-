package com.minicloud.controller;

import com.minicloud.dto.ApiResponse;
import com.minicloud.dto.SystemConfigRequest;
import com.minicloud.dto.SystemConfigResponse;
import com.minicloud.security.UserPrincipal;
import com.minicloud.service.SystemSettingService;
import com.minicloud.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/admin/system-config")
@CrossOrigin(origins = "*", maxAge = 3600)
public class SystemConfigController {

    private final SystemSettingService systemSettingService;
    private final UserService userService;

    public SystemConfigController(SystemSettingService systemSettingService,
                                  UserService userService) {
        this.systemSettingService = systemSettingService;
        this.userService = userService;
    }

    private boolean isSystemAdmin(Long userId) {
        return userService.checkUserPermission(userId, "SYSTEM_ADMIN");
    }

    @GetMapping
    public ResponseEntity<ApiResponse<SystemConfigResponse>> getSystemConfig(
        @AuthenticationPrincipal UserPrincipal principal
    ) {
        if (principal == null || !isSystemAdmin(principal.getId())) {
            return ResponseEntity.status(403).body(ApiResponse.error("无权限执行该操作", 403));
        }
        SystemConfigResponse response = systemSettingService.getSystemConfig();
        return ResponseEntity.ok(ApiResponse.success(response, "获取系统配置成功"));
    }

    @PutMapping
    public ResponseEntity<ApiResponse<String>> updateSystemConfig(
        @Valid @RequestBody SystemConfigRequest request,
        @AuthenticationPrincipal UserPrincipal principal
    ) {
        if (principal == null || !isSystemAdmin(principal.getId())) {
            return ResponseEntity.status(403).body(ApiResponse.error("无权限执行该操作", 403));
        }
        try {
            systemSettingService.updateSystemConfig(request);
            return ResponseEntity.ok(ApiResponse.success(null, "系统配置更新完成"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage() != null ? e.getMessage() : "系统配置更新失败"));
        }
    }
}

