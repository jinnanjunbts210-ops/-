package com.minicloud.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.minicloud.dto.ApiResponse;
import com.minicloud.entity.SystemLog;
import com.minicloud.security.UserPrincipal;
import com.minicloud.service.SystemLogService;
import com.minicloud.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/logs")
@CrossOrigin(origins = "*", maxAge = 3600)
public class SystemLogController {

    private final SystemLogService systemLogService;
    private final UserService userService;

    public SystemLogController(SystemLogService systemLogService, UserService userService) {
        this.systemLogService = systemLogService;
        this.userService = userService;
    }

    @GetMapping
    public ResponseEntity<ApiResponse<IPage<SystemLog>>> listLogs(
        @AuthenticationPrincipal UserPrincipal userPrincipal,
        @RequestParam(value = "page", defaultValue = "1") int page,
        @RequestParam(value = "size", defaultValue = "20") int size
    ) {
        var user = userService.getById(userPrincipal.getId());
        Integer roleType = user != null ? user.getRoleType() : 0;
        Long departmentId = user != null ? user.getDepartmentId() : null;
        IPage<SystemLog> logs = systemLogService.queryLogs(userPrincipal.getId(), roleType, departmentId, page, size);
        return ResponseEntity.ok(ApiResponse.success(logs, "Logs fetched"));
    }
}
