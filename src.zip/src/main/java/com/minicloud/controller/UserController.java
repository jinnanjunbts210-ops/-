package com.minicloud.controller;

import com.minicloud.dto.ApiResponse;
import com.minicloud.dto.UserInfo;
import com.minicloud.dto.UserProfileUpdateRequest;
import com.minicloud.entity.User;
import com.minicloud.security.UserPrincipal;
import com.minicloud.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/user")
@CrossOrigin(origins = "*", maxAge = 3600)
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/info")
    public ResponseEntity<ApiResponse<UserInfo>> getUserInfo(@AuthenticationPrincipal UserPrincipal principal) {
        if (principal == null) {
            return ResponseEntity.status(401).body(ApiResponse.error("未登录", 401));
        }
        User user = userService.getById(principal.getId());
        if (user == null) {
            return ResponseEntity.badRequest().body(ApiResponse.error("用户不存在"));
        }
        return ResponseEntity.ok(ApiResponse.success(buildUserInfo(user), "获取用户信息成功"));
    }

    @PutMapping("/profile")
    public ResponseEntity<ApiResponse<UserInfo>> updateProfile(
        @RequestBody UserProfileUpdateRequest request,
        @AuthenticationPrincipal UserPrincipal principal
    ) {
        if (principal == null) {
            return ResponseEntity.status(401).body(ApiResponse.error("未登录", 401));
        }
        User update = new User();
        update.setRealName(request.getRealName());
        update.setPhone(request.getPhone());
        update.setEmail(request.getEmail());
        update.setGender(request.getGender());
        update.setAge(request.getAge());
        update.setPosition(request.getPosition());
        update.setEmployeeNo(request.getEmployeeNo());

        User updated = userService.updateUserInfo(principal.getId(), update);
        return ResponseEntity.ok(ApiResponse.success(buildUserInfo(updated), "用户信息更新成功"));
    }

    private UserInfo buildUserInfo(User user) {
        return new UserInfo(
            user.getId(),
            user.getUsername(),
            user.getRealName(),
            user.getEmail(),
            user.getPhone(),
            user.getGender(),
            user.getAge(),
            user.getPosition(),
            user.getEmployeeNo(),
            user.getRoleType() != null ? user.getRoleType() : 0,
            user.getDepartmentId(),
            user.getPersonalSpaceSize() != null ? user.getPersonalSpaceSize() : 0L,
            user.getUsedSpaceSize() != null ? user.getUsedSpaceSize() : 0L,
            user.getStatus(),
            Boolean.TRUE.equals(user.getCanViewSubordinate())
        );
    }
}

