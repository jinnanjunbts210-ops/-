package com.minicloud.dto;

import java.time.LocalDateTime;

public class AdminUserResponse {

    private Long id;
    private String username;
    private String realName;
    private String email;
    private String phone;
    private Integer gender;
    private Integer age;
    private String position;
    private String employeeNo;
    private Integer roleType;
    private Integer status;
    private Long departmentId;
    private Long personalSpaceSize;
    private Long usedSpaceSize;
    private Boolean canViewSubordinate;
    private Integer subordinateViewType;
    private LocalDateTime subordinateViewExpire;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getGender() {
        return gender;
    }

    public void setGender(Integer gender) {
        this.gender = gender;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getEmployeeNo() {
        return employeeNo;
    }

    public void setEmployeeNo(String employeeNo) {
        this.employeeNo = employeeNo;
    }

    public Integer getRoleType() {
        return roleType;
    }

    public void setRoleType(Integer roleType) {
        this.roleType = roleType;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Long getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Long departmentId) {
        this.departmentId = departmentId;
    }

    public Long getPersonalSpaceSize() {
        return personalSpaceSize;
    }

    public void setPersonalSpaceSize(Long personalSpaceSize) {
        this.personalSpaceSize = personalSpaceSize;
    }

    public Long getUsedSpaceSize() {
        return usedSpaceSize;
    }

    public void setUsedSpaceSize(Long usedSpaceSize) {
        this.usedSpaceSize = usedSpaceSize;
    }

    public Boolean getCanViewSubordinate() {
        return canViewSubordinate;
    }

    public void setCanViewSubordinate(Boolean canViewSubordinate) {
        this.canViewSubordinate = canViewSubordinate;
    }

    public Integer getSubordinateViewType() {
        return subordinateViewType;
    }

    public void setSubordinateViewType(Integer subordinateViewType) {
        this.subordinateViewType = subordinateViewType;
    }

    public LocalDateTime getSubordinateViewExpire() {
        return subordinateViewExpire;
    }

    public void setSubordinateViewExpire(LocalDateTime subordinateViewExpire) {
        this.subordinateViewExpire = subordinateViewExpire;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }
}

