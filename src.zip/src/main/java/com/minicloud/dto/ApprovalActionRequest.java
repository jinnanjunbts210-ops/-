package com.minicloud.dto;

import javax.validation.constraints.NotBlank;

/**
 * 审批操作请求 DTO（同意/驳回）
 */
public class ApprovalActionRequest {

    @NotBlank(message = "审批意见不能为空")
    private String comment;

    /**
     * 可选的下一级审批人 ID（传入时表示转交下一审批人）
     */
    private Long nextApproverId;

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Long getNextApproverId() {
        return nextApproverId;
    }

    public void setNextApproverId(Long nextApproverId) {
        this.nextApproverId = nextApproverId;
    }
}

