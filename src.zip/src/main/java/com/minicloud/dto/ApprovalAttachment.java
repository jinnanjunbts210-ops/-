package com.minicloud.dto;

public class ApprovalAttachment {

    private String fileName;
    private String objectKey;
    private Long size;
    private String contentType;
    private String previewUrl;

    public ApprovalAttachment() {
    }

    public ApprovalAttachment(String fileName, String objectKey, Long size, String contentType) {
        this.fileName = fileName;
        this.objectKey = objectKey;
        this.size = size;
        this.contentType = contentType;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getObjectKey() {
        return objectKey;
    }

    public void setObjectKey(String objectKey) {
        this.objectKey = objectKey;
    }

    public Long getSize() {
        return size;
    }

    public void setSize(Long size) {
        this.size = size;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getPreviewUrl() {
        return previewUrl;
    }

    public void setPreviewUrl(String previewUrl) {
        this.previewUrl = previewUrl;
    }
}
