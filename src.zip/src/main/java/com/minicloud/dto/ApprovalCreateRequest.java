package com.minicloud.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * 审批创建请求 DTO
 */
public class ApprovalCreateRequest {

    @NotBlank(message = "审批标题不能为空")
    private String title;

    @NotBlank(message = "审批内容不能为空")
    private String content;

    @NotNull(message = "审批人不能为空")
    private Long approverId;

    private String applicantContact;

    private String attachmentFiles;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Long getApproverId() {
        return approverId;
    }

    public void setApproverId(Long approverId) {
        this.approverId = approverId;
    }

    public String getApplicantContact() {
        return applicantContact;
    }

    public void setApplicantContact(String applicantContact) {
        this.applicantContact = applicantContact;
    }

    public String getAttachmentFiles() {
        return attachmentFiles;
    }

    public void setAttachmentFiles(String attachmentFiles) {
        this.attachmentFiles = attachmentFiles;
    }
}

