package com.minicloud.dto;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class DepartmentCreateRequest {

    @NotBlank(message = "部门名称不能为空")
    @Size(max = 100, message = "部门名称长度不能超过100个字符")
    private String name;

    private Long parentId;

    private Long managerId;

    @Min(value = 1024 * 1024, message = "部门空间至少大于1MB")
    private Long departmentSpaceSize;

    @Size(max = 500, message = "部门描述长度不能超过500个字符")
    private String description;

    private Integer sortOrder;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    public Long getManagerId() {
        return managerId;
    }

    public void setManagerId(Long managerId) {
        this.managerId = managerId;
    }

    public Long getDepartmentSpaceSize() {
        return departmentSpaceSize;
    }

    public void setDepartmentSpaceSize(Long departmentSpaceSize) {
        this.departmentSpaceSize = departmentSpaceSize;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }
}

