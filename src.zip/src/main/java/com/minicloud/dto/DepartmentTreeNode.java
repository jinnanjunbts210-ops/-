package com.minicloud.dto;

import java.util.ArrayList;
import java.util.List;

public class DepartmentTreeNode {

    private Long id;
    private String name;
    private Long parentId;
    private List<DepartmentTreeNode> children = new ArrayList<>();

    public DepartmentTreeNode() {
    }

    public DepartmentTreeNode(Long id, String name, Long parentId) {
        this.id = id;
        this.name = name;
        this.parentId = parentId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    public List<DepartmentTreeNode> getChildren() {
        return children;
    }

    public void setChildren(List<DepartmentTreeNode> children) {
        this.children = children;
    }

    public void addChild(DepartmentTreeNode child) {
        this.children.add(child);
    }
}