package com.minicloud.dto;

public class FilePreviewResponse {

    private String previewType;
    private String previewUrl;
    private String downloadUrl;

    public FilePreviewResponse() {
    }

    public FilePreviewResponse(String previewType, String previewUrl, String downloadUrl) {
        this.previewType = previewType;
        this.previewUrl = previewUrl;
        this.downloadUrl = downloadUrl;
    }

    public String getPreviewType() {
        return previewType;
    }

    public void setPreviewType(String previewType) {
        this.previewType = previewType;
    }

    public String getPreviewUrl() {
        return previewUrl;
    }

    public void setPreviewUrl(String previewUrl) {
        this.previewUrl = previewUrl;
    }

    public String getDownloadUrl() {
        return downloadUrl;
    }

    public void setDownloadUrl(String downloadUrl) {
        this.downloadUrl = downloadUrl;
    }
}
