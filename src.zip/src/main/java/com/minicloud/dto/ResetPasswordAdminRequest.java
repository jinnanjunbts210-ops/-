package com.minicloud.dto;

import javax.validation.constraints.NotBlank;

public class ResetPasswordAdminRequest {

    @NotBlank(message = "新密码不能为空")
    private String newPassword;

    public String getNewPassword() {
        return newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }
}