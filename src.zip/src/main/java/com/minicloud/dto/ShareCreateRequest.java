package com.minicloud.dto;

import com.fasterxml.jackson.annotation.JsonFormat;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.List;

public class ShareCreateRequest {

    @NotEmpty
    private List<Long> fileIds;

    @NotNull
    private Integer shareType;

    @NotEmpty
    private List<Long> targetIds;

    @Valid
    private SharePermissionRequest permissions = new SharePermissionRequest();

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime expireTime;

    public List<Long> getFileIds() {
        return fileIds;
    }

    public void setFileIds(List<Long> fileIds) {
        this.fileIds = fileIds;
    }

    public Integer getShareType() {
        return shareType;
    }

    public void setShareType(Integer shareType) {
        this.shareType = shareType;
    }

    public List<Long> getTargetIds() {
        return targetIds;
    }

    public void setTargetIds(List<Long> targetIds) {
        this.targetIds = targetIds;
    }

    public SharePermissionRequest getPermissions() {
        return permissions;
    }

    public void setPermissions(SharePermissionRequest permissions) {
        this.permissions = permissions;
    }

    public LocalDateTime getExpireTime() {
        return expireTime;
    }

    public void setExpireTime(LocalDateTime expireTime) {
        this.expireTime = expireTime;
    }
    // 可选：仅供你想放开 targetIds 时使用


}

