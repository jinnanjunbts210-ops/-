package com.minicloud.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.LocalDateTime;

public class ShareInfoResponse {

    private Long id;
    private Long shareId;
    private Long fileId;
    private String name;
    private Long size;
    private Boolean directory;

    @JsonProperty("isDir")
    private Boolean isDir;

    private Integer shareType;
    private Long targetId;
    private Long sharerId;
    private String sharerUserId;
    private String sharerRealName;
    private String sharerDepartmentName;
    private LocalDateTime sharedAt;
    private Boolean canDownload;
    private Boolean canUpload;
    private Boolean canModify;
    private Boolean canViewOthers;
    private Boolean open;
    private LocalDateTime expireTime;
    private Long accessCount;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getShareId() {
        return shareId;
    }

    public void setShareId(Long shareId) {
        this.shareId = shareId;
    }

    public Long getFileId() {
        return fileId;
    }

    public void setFileId(Long fileId) {
        this.fileId = fileId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getSize() {
        return size;
    }

    public void setSize(Long size) {
        this.size = size;
    }

    public Boolean getDirectory() {
        return directory;
    }

    public void setDirectory(Boolean directory) {
        this.directory = directory;
    }

    public Boolean getIsDir() {
        return isDir;
    }

    public void setIsDir(Boolean isDir) {
        this.isDir = isDir;
    }

    public Integer getShareType() {
        return shareType;
    }

    public void setShareType(Integer shareType) {
        this.shareType = shareType;
    }

    public Long getTargetId() {
        return targetId;
    }

    public void setTargetId(Long targetId) {
        this.targetId = targetId;
    }

    public Long getSharerId() {
        return sharerId;
    }

    public void setSharerId(Long sharerId) {
        this.sharerId = sharerId;
    }

    public String getSharerUserId() {
        return sharerUserId;
    }

    public void setSharerUserId(String sharerUserId) {
        this.sharerUserId = sharerUserId;
    }

    public String getSharerRealName() {
        return sharerRealName;
    }

    public void setSharerRealName(String sharerRealName) {
        this.sharerRealName = sharerRealName;
    }

    public String getSharerDepartmentName() {
        return sharerDepartmentName;
    }

    public void setSharerDepartmentName(String sharerDepartmentName) {
        this.sharerDepartmentName = sharerDepartmentName;
    }

    public LocalDateTime getSharedAt() {
        return sharedAt;
    }

    public void setSharedAt(LocalDateTime sharedAt) {
        this.sharedAt = sharedAt;
    }

    public Boolean getCanDownload() {
        return canDownload;
    }

    public void setCanDownload(Boolean canDownload) {
        this.canDownload = canDownload;
    }

    public Boolean getCanUpload() {
        return canUpload;
    }

    public void setCanUpload(Boolean canUpload) {
        this.canUpload = canUpload;
    }

    public Boolean getCanModify() {
        return canModify;
    }

    public void setCanModify(Boolean canModify) {
        this.canModify = canModify;
    }

    public Boolean getCanViewOthers() {
        return canViewOthers;
    }

    public void setCanViewOthers(Boolean canViewOthers) {
        this.canViewOthers = canViewOthers;
    }

    public Boolean getOpen() {
        return open;
    }

    public void setOpen(Boolean open) {
        this.open = open;
    }

    public LocalDateTime getExpireTime() {
        return expireTime;
    }

    public void setExpireTime(LocalDateTime expireTime) {
        this.expireTime = expireTime;
    }

    public Long getAccessCount() {
        return accessCount;
    }

    public void setAccessCount(Long accessCount) {
        this.accessCount = accessCount;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }
}
