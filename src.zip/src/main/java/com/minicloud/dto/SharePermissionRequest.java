package com.minicloud.dto;

import java.util.HashMap;
import java.util.Map;

public class SharePermissionRequest {

    private Boolean canDownload = Boolean.TRUE;
    private Boolean canUpload = Boolean.FALSE;
    private Boolean canModify = Boolean.FALSE;
    private Boolean canViewOthers = Boolean.FALSE;
    private Boolean open = Boolean.TRUE;

    public Boolean getCanDownload() {
        return canDownload;
    }

    public void setCanDownload(Boolean canDownload) {
        this.canDownload = canDownload;
    }

    public Boolean getCanUpload() {
        return canUpload;
    }

    public void setCanUpload(Boolean canUpload) {
        this.canUpload = canUpload;
    }

    public Boolean getCanModify() {
        return canModify;
    }

    public void setCanModify(Boolean canModify) {
        this.canModify = canModify;
    }

    public Boolean getCanViewOthers() {
        return canViewOthers;
    }

    public void setCanViewOthers(Boolean canViewOthers) {
        this.canViewOthers = canViewOthers;
    }

    public Boolean getOpen() {
        return open;
    }

    public void setOpen(Boolean open) {
        this.open = open;
    }

    public Map<String, Boolean> toPermissionMap() {
        Map<String, Boolean> permissions = new HashMap<>();
        permissions.put("download", Boolean.TRUE.equals(canDownload));
        permissions.put("upload", Boolean.TRUE.equals(canUpload));
        permissions.put("modify", Boolean.TRUE.equals(canModify));
        permissions.put("viewOthers", Boolean.TRUE.equals(canViewOthers));
        permissions.put("open", Boolean.TRUE.equals(open));
        return permissions;
    }
}

