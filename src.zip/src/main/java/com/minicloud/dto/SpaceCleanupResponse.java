package com.minicloud.dto;

public class SpaceCleanupResponse {

    private int recycledFilesCleared;
    private int expiredSharesCleared;
    private int temporaryChunksCleared;

    public int getRecycledFilesCleared() {
        return recycledFilesCleared;
    }

    public void setRecycledFilesCleared(int recycledFilesCleared) {
        this.recycledFilesCleared = recycledFilesCleared;
    }

    public int getExpiredSharesCleared() {
        return expiredSharesCleared;
    }

    public void setExpiredSharesCleared(int expiredSharesCleared) {
        this.expiredSharesCleared = expiredSharesCleared;
    }

    public int getTemporaryChunksCleared() {
        return temporaryChunksCleared;
    }

    public void setTemporaryChunksCleared(int temporaryChunksCleared) {
        this.temporaryChunksCleared = temporaryChunksCleared;
    }
}

