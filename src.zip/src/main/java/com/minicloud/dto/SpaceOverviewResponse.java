package com.minicloud.dto;

public class SpaceOverviewResponse {

    private long personalSpaceUsed;
    private long departmentSpaceUsed;
    private long enterpriseSpaceUsed;
    private long sharedSpaceUsed;
    private long totalFiles;
    private long recycledFiles;

    public long getPersonalSpaceUsed() {
        return personalSpaceUsed;
    }

    public void setPersonalSpaceUsed(long personalSpaceUsed) {
        this.personalSpaceUsed = personalSpaceUsed;
    }

    public long getDepartmentSpaceUsed() {
        return departmentSpaceUsed;
    }

    public void setDepartmentSpaceUsed(long departmentSpaceUsed) {
        this.departmentSpaceUsed = departmentSpaceUsed;
    }

    public long getEnterpriseSpaceUsed() {
        return enterpriseSpaceUsed;
    }

    public void setEnterpriseSpaceUsed(long enterpriseSpaceUsed) {
        this.enterpriseSpaceUsed = enterpriseSpaceUsed;
    }

    public long getSharedSpaceUsed() {
        return sharedSpaceUsed;
    }

    public void setSharedSpaceUsed(long sharedSpaceUsed) {
        this.sharedSpaceUsed = sharedSpaceUsed;
    }

    public long getTotalFiles() {
        return totalFiles;
    }

    public void setTotalFiles(long totalFiles) {
        this.totalFiles = totalFiles;
    }

    public long getRecycledFiles() {
        return recycledFiles;
    }

    public void setRecycledFiles(long recycledFiles) {
        this.recycledFiles = recycledFiles;
    }
}

