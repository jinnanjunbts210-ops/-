package com.minicloud.dto;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

public class SystemConfigRequest {

    @NotBlank(message = "站点域名不能为空")
    @Pattern(regexp = "^[a-zA-Z0-9.-]+$", message = "站点域名格式不正确")
    private String siteDomain;

    @Min(value = 1024 * 1024, message = "默认个人空间至少大于1MB")
    private Long defaultPersonalSpaceSize;

    @Min(value = 1024 * 1024, message = "上传文件大小限制至少大于1MB")
    private Long maxUploadSize;

    public String getSiteDomain() {
        return siteDomain;
    }

    public void setSiteDomain(String siteDomain) {
        this.siteDomain = siteDomain;
    }

    public Long getDefaultPersonalSpaceSize() {
        return defaultPersonalSpaceSize;
    }

    public void setDefaultPersonalSpaceSize(Long defaultPersonalSpaceSize) {
        this.defaultPersonalSpaceSize = defaultPersonalSpaceSize;
    }

    public Long getMaxUploadSize() {
        return maxUploadSize;
    }

    public void setMaxUploadSize(Long maxUploadSize) {
        this.maxUploadSize = maxUploadSize;
    }
}

