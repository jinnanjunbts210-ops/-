package com.minicloud.dto;

public class SystemConfigResponse {

    private String siteDomain;
    private Long defaultPersonalSpaceSize;
    private Long maxUploadSize;

    public SystemConfigResponse() {
    }

    public SystemConfigResponse(String siteDomain, Long defaultPersonalSpaceSize, Long maxUploadSize) {
        this.siteDomain = siteDomain;
        this.defaultPersonalSpaceSize = defaultPersonalSpaceSize;
        this.maxUploadSize = maxUploadSize;
    }

    public String getSiteDomain() {
        return siteDomain;
    }

    public void setSiteDomain(String siteDomain) {
        this.siteDomain = siteDomain;
    }

    public Long getDefaultPersonalSpaceSize() {
        return defaultPersonalSpaceSize;
    }

    public void setDefaultPersonalSpaceSize(Long defaultPersonalSpaceSize) {
        this.defaultPersonalSpaceSize = defaultPersonalSpaceSize;
    }

    public Long getMaxUploadSize() {
        return maxUploadSize;
    }

    public void setMaxUploadSize(Long maxUploadSize) {
        this.maxUploadSize = maxUploadSize;
    }
}

