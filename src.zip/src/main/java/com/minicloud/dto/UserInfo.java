package com.minicloud.dto;

public class UserInfo {

    private final Long id;
    private final String username;
    private final String realName;
    private final String email;
    private final String phone;
    private final Integer gender;
    private final Integer age;
    private final String position;
    private final String employeeNo;
    private final int roleType;
    private final Long departmentId;
    private final long personalSpaceSize;
    private final long usedSpaceSize;
    private final Integer status;
    private final boolean canViewSubordinate;

    public UserInfo(Long id,
                    String username,
                    String realName,
                    String email,
                    String phone,
                    Integer gender,
                    Integer age,
                    String position,
                    String employeeNo,
                    int roleType,
                    Long departmentId,
                    long personalSpaceSize,
                    long usedSpaceSize,
                    Integer status,
                    boolean canViewSubordinate) {
        this.id = id;
        this.username = username;
        this.realName = realName;
        this.email = email;
        this.phone = phone;
        this.gender = gender;
        this.age = age;
        this.position = position;
        this.employeeNo = employeeNo;
        this.roleType = roleType;
        this.departmentId = departmentId;
        this.personalSpaceSize = personalSpaceSize;
        this.usedSpaceSize = usedSpaceSize;
        this.status = status;
        this.canViewSubordinate = canViewSubordinate;
    }

    public Long getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getRealName() {
        return realName;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public Integer getGender() {
        return gender;
    }

    public Integer getAge() {
        return age;
    }

    public String getPosition() {
        return position;
    }

    public String getEmployeeNo() {
        return employeeNo;
    }

    public int getRoleType() {
        return roleType;
    }

    public Long getDepartmentId() {
        return departmentId;
    }

    public long getPersonalSpaceSize() {
        return personalSpaceSize;
    }

    public long getUsedSpaceSize() {
        return usedSpaceSize;
    }

    public Integer getStatus() {
        return status;
    }

    public boolean isCanViewSubordinate() {
        return canViewSubordinate;
    }
}
