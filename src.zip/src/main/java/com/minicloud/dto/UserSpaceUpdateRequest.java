package com.minicloud.dto;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

public class UserSpaceUpdateRequest {

    @NotNull(message = "空间大小不能为空")
    @Min(value = 0, message = "空间大小必须大于等于0")
    private Long spaceSize;

    public Long getSpaceSize() {
        return spaceSize;
    }

    public void setSpaceSize(Long spaceSize) {
        this.spaceSize = spaceSize;
    }
}