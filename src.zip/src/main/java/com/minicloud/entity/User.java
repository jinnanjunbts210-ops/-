package com.minicloud.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;

import java.time.LocalDateTime;

@TableName("sys_user")
public class User {

    @TableId(type = IdType.AUTO)
    private Long id;

    @TableField("username")
    private String username;

    @TableField("password")
    private String password;

    @TableField("real_name")
    private String realName;

    @TableField("phone")
    private String phone;

    @TableField("email")
    private String email;

    @TableField("gender")
    private Integer gender;

    @TableField("age")
    private Integer age;

    @TableField("position")
    private String position;

    @TableField("employee_no")
    private String employeeNo;

    @TableField("department_id")
    private Long departmentId;

    @TableField("role_type")
    private Integer roleType = 0;

    @TableField("status")
    private Integer status = 0;

    @TableField("personal_space_size")
    private Long personalSpaceSize = 1024L * 1024 * 1024;

    @TableField("used_space_size")
    private Long usedSpaceSize = 0L;

    @TableField("can_view_subordinate")
    private Boolean canViewSubordinate = false;

    @TableField("subordinate_view_type")
    private Integer subordinateViewType = 0;

    @TableField("subordinate_view_expire")
    private LocalDateTime subordinateViewExpire;

    @TableField("security_question1")
    private String securityQuestion1;

    @TableField("security_answer1")
    private String securityAnswer1;

    @TableField("security_question2")
    private String securityQuestion2;

    @TableField("security_answer2")
    private String securityAnswer2;

    @TableField("security_question3")
    private String securityQuestion3;

    @TableField("security_answer3")
    private String securityAnswer3;

    @TableField(value = "create_time", fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField(value = "update_time", fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    @TableLogic
    @TableField("deleted")
    private Integer deleted = 0;

    public User() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getGender() {
        return gender;
    }

    public void setGender(Integer gender) {
        this.gender = gender;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getEmployeeNo() {
        return employeeNo;
    }

    public void setEmployeeNo(String employeeNo) {
        this.employeeNo = employeeNo;
    }

    public Long getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Long departmentId) {
        this.departmentId = departmentId;
    }

    public Integer getRoleType() {
        return roleType;
    }

    public void setRoleType(Integer roleType) {
        this.roleType = roleType;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Long getPersonalSpaceSize() {
        return personalSpaceSize;
    }

    public void setPersonalSpaceSize(Long personalSpaceSize) {
        this.personalSpaceSize = personalSpaceSize;
    }

    public Long getUsedSpaceSize() {
        return usedSpaceSize;
    }

    public void setUsedSpaceSize(Long usedSpaceSize) {
        this.usedSpaceSize = usedSpaceSize;
    }

    public Boolean getCanViewSubordinate() {
        return canViewSubordinate;
    }

    public void setCanViewSubordinate(Boolean canViewSubordinate) {
        this.canViewSubordinate = canViewSubordinate;
    }

    public Integer getSubordinateViewType() {
        return subordinateViewType;
    }

    public void setSubordinateViewType(Integer subordinateViewType) {
        this.subordinateViewType = subordinateViewType;
    }

    public LocalDateTime getSubordinateViewExpire() {
        return subordinateViewExpire;
    }

    public void setSubordinateViewExpire(LocalDateTime subordinateViewExpire) {
        this.subordinateViewExpire = subordinateViewExpire;
    }

    public String getSecurityQuestion1() {
        return securityQuestion1;
    }

    public void setSecurityQuestion1(String securityQuestion1) {
        this.securityQuestion1 = securityQuestion1;
    }

    public String getSecurityAnswer1() {
        return securityAnswer1;
    }

    public void setSecurityAnswer1(String securityAnswer1) {
        this.securityAnswer1 = securityAnswer1;
    }

    public String getSecurityQuestion2() {
        return securityQuestion2;
    }

    public void setSecurityQuestion2(String securityQuestion2) {
        this.securityQuestion2 = securityQuestion2;
    }

    public String getSecurityAnswer2() {
        return securityAnswer2;
    }

    public void setSecurityAnswer2(String securityAnswer2) {
        this.securityAnswer2 = securityAnswer2;
    }

    public String getSecurityQuestion3() {
        return securityQuestion3;
    }

    public void setSecurityQuestion3(String securityQuestion3) {
        this.securityQuestion3 = securityQuestion3;
    }

    public String getSecurityAnswer3() {
        return securityAnswer3;
    }

    public void setSecurityAnswer3(String securityAnswer3) {
        this.securityAnswer3 = securityAnswer3;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getDeleted() {
        return deleted;
    }

    public void setDeleted(Integer deleted) {
        this.deleted = deleted;
    }
}

