package com.minicloud.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.minicloud.entity.Department;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface DepartmentMapper extends BaseMapper<Department> {

    @Select("SELECT * FROM sys_department WHERE parent_id = #{parentId} AND deleted = 0 ORDER BY sort_order")
    List<Department> findByParentId(@Param("parentId") Long parentId);

    @Select("SELECT * FROM sys_department WHERE parent_id IS NULL AND deleted = 0 ORDER BY sort_order")
    List<Department> findRootDepartments();

    @Select("SELECT * FROM sys_department WHERE manager_id = #{managerId} AND deleted = 0")
    List<Department> findByManagerId(@Param("managerId") Long managerId);

    @Update("UPDATE sys_department SET used_space_size = #{usedSpaceSize} WHERE id = #{departmentId}")
    int updateUsedSpaceSize(@Param("departmentId") Long departmentId, @Param("usedSpaceSize") Long usedSpaceSize);
}








