package com.minicloud.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.minicloud.entity.FileApproval;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface FileApprovalMapper extends BaseMapper<FileApproval> {

    @Select("SELECT * FROM file_approval WHERE approver_id = #{approverId} AND status = 0 AND deleted = 0 ORDER BY create_time DESC")
    List<FileApproval> findPendingApprovals(@Param("approverId") Long approverId);

    @Select("SELECT * FROM file_approval WHERE applicant_id = #{applicantId} AND deleted = 0 ORDER BY create_time DESC")
    List<FileApproval> findByApplicantId(@Param("applicantId") Long applicantId);

    @Select("SELECT * FROM file_approval WHERE approver_id = #{approverId} AND status != 0 AND deleted = 0 ORDER BY approval_time DESC")
    List<FileApproval> findApprovalHistory(@Param("approverId") Long approverId);
}

