package com.minicloud.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.minicloud.entity.FileInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface FileInfoMapper extends BaseMapper<FileInfo> {

    // ====== 你原有的方法（保留不变） ======

    @Select("SELECT * FROM file_info " +
        "WHERE owner_id = #{ownerId} " +
        "AND space_type = #{spaceType} " +
        "AND is_recycled = 0 " +
        "AND deleted = 0 " +
        "AND ( (#{parentId} IS NULL AND parent_id IS NULL) OR parent_id = #{parentId} ) " +
        "AND ( (#{spaceId} IS NULL AND space_id IS NULL) OR space_id = #{spaceId} ) " +
        "ORDER BY is_directory DESC, file_name")
    List<FileInfo> findByParentId(@Param("parentId") Long parentId,
                                  @Param("ownerId") Long ownerId,
                                  @Param("spaceType") Integer spaceType,
                                  @Param("spaceId") Long spaceId);

    @Select("SELECT * FROM file_info WHERE md5_hash = #{md5Hash} AND deleted = 0 LIMIT 1")
    FileInfo findByMd5Hash(@Param("md5Hash") String md5Hash);

    @Select("SELECT * FROM file_info WHERE file_name LIKE CONCAT('%', #{keyword}, '%') AND owner_id = #{ownerId} AND space_type = #{spaceType} AND is_recycled = 0 AND deleted = 0 ORDER BY is_directory DESC, file_name")
    IPage<FileInfo> searchFiles(Page<FileInfo> page,
                                @Param("keyword") String keyword,
                                @Param("ownerId") Long ownerId,
                                @Param("spaceType") Integer spaceType);

    @Select("SELECT * FROM file_info WHERE owner_id = #{ownerId} AND is_recycled = 1 AND deleted = 0 ORDER BY recycled_time DESC")
    List<FileInfo> findRecycledFiles(@Param("ownerId") Long ownerId);

    @Select("SELECT COALESCE(SUM(file_size), 0) FROM file_info WHERE owner_id = #{ownerId} AND space_type = #{spaceType} AND is_recycled = 0 AND deleted = 0")
    Long calculateUsedSpace(@Param("ownerId") Long ownerId, @Param("spaceType") Integer spaceType);

    @Select("SELECT COALESCE(SUM(file_size), 0) FROM file_info WHERE space_type = 1 AND space_id = #{departmentId} AND is_recycled = 0 AND deleted = 0")
    Long calculateDepartmentUsedSpace(@Param("departmentId") Long departmentId);

    @Select("SELECT COALESCE(SUM(file_size), 0) FROM file_info WHERE space_type = #{spaceType} AND is_recycled = 0 AND deleted = 0")
    Long sumSpaceUsageByType(@Param("spaceType") Integer spaceType);

    @Select("SELECT COALESCE(SUM(file_size), 0) FROM file_info WHERE is_shared = 1 AND is_recycled = 0 AND deleted = 0")
    Long sumSharedSpaceUsage();

    @Select("SELECT COUNT(*) FROM file_info WHERE deleted = 0")
    Long countAllFiles();

    @Select("SELECT COUNT(*) FROM file_info WHERE deleted = 0 AND is_recycled = 1")
    Long countRecycledFiles();


    // ====== 新增的方法（由 XML 实现动态 SQL；不要加 @Select 注解） ======

    /**
     * 共享视图：列出“某共享目录”的直接子项。
     * 参数：
     *   userId      - 当前用户
     *   rootFolderId- 共享目录ID（为 null 时取根）
     *   keyword     - 可选关键字
     *   deptScope   - 用户可见的部门ID集合（含自身部门/子部门）
     */
    List<FileInfo> listByShare(@Param("userId") Long userId,
                               @Param("rootFolderId") Long rootFolderId,
                               @Param("keyword") String keyword,
                               @Param("deptScope") List<Long> deptScope);

    /**
     * 部门空间浏览。
     * 参数：
     *   deptScope   - 可见部门ID集合
     *   rootFolderId- 目录ID（null 为根）
     *   onlyOpen    - 普通成员为 true（仅开放目录可见），部门管理员为 false
     *   keyword     - 可选关键字
     */
    List<FileInfo> listDepartmentSpace(@Param("deptScope") List<Long> deptScope,
                                       @Param("rootFolderId") Long rootFolderId,
                                       @Param("onlyOpen") boolean onlyOpen,
                                       @Param("keyword") String keyword);

    /**
     * 企业空间浏览。
     */
    List<FileInfo> listEnterpriseSpace(@Param("enterpriseId") Long enterpriseId,
                                       @Param("rootFolderId") Long rootFolderId,
                                       @Param("keyword") String keyword);

    /**
     * 跨个人/部门/企业的模糊搜索（服从权限）。
     */
    List<FileInfo> searchAcrossSpaces(@Param("userId") Long userId,
                                      @Param("deptScope") List<Long> deptScope,
                                      @Param("enterpriseId") Long enterpriseId,
                                      @Param("inPersonal") boolean inPersonal,
                                      @Param("inDepartment") boolean inDepartment,
                                      @Param("inEnterprise") boolean inEnterprise,
                                      @Param("onlyOpen") boolean onlyOpen,
                                      @Param("keyword") String keyword);
    List<FileInfo> listSharedRoot(@Param("userId") Long userId,
                              @Param("deptScope") List<Long> deptScope,
                              @Param("keyword") String keyword);

                            }
                                    
