package com.minicloud.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.minicloud.entity.FileShare;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface FileShareMapper extends BaseMapper<FileShare> {

    @Select("SELECT * FROM file_share WHERE sharer_id = #{sharerId} AND deleted = 0 ORDER BY create_time DESC")
    List<FileShare> findBySharerId(@Param("sharerId") Long sharerId);

    @Select("SELECT * FROM file_share WHERE share_type = 0 AND target_id = #{userId} AND deleted = 0 AND (expire_time IS NULL OR expire_time > NOW()) ORDER BY create_time DESC")
    List<FileShare> findSharedToUser(@Param("userId") Long userId);

    @Select("SELECT * FROM file_share WHERE share_type = 1 AND target_id = #{departmentId} AND deleted = 0 AND (expire_time IS NULL OR expire_time > NOW()) ORDER BY create_time DESC")
    List<FileShare> findSharedToDepartment(@Param("departmentId") Long departmentId);

    @Select("SELECT * FROM file_share WHERE file_id = #{fileId} AND ((share_type = 0 AND target_id = #{userId}) OR (share_type = 1 AND target_id IN (SELECT department_id FROM sys_user WHERE id = #{userId}))) AND deleted = 0 AND (expire_time IS NULL OR expire_time > NOW()) LIMIT 1")
    FileShare checkFileSharePermission(@Param("fileId") Long fileId, @Param("userId") Long userId);
}

