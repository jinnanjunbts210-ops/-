package com.minicloud.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.minicloud.entity.SystemLog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface SystemLogMapper extends BaseMapper<SystemLog> {

    @Select("SELECT * FROM system_log WHERE deleted = 0 ORDER BY create_time DESC")
    IPage<SystemLog> findAll(Page<SystemLog> page);

    @Select("SELECT * FROM system_log WHERE deleted = 0 AND department_id = #{departmentId} ORDER BY create_time DESC")
    IPage<SystemLog> findByDepartment(Page<SystemLog> page, @Param("departmentId") Long departmentId);

    @Select("SELECT * FROM system_log WHERE deleted = 0 AND user_id = #{userId} ORDER BY create_time DESC")
    IPage<SystemLog> findByUser(Page<SystemLog> page, @Param("userId") Long userId);
}
