package com.minicloud.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.minicloud.entity.SystemSetting;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface SystemSettingMapper extends BaseMapper<SystemSetting> {

    @Select("SELECT * FROM sys_setting WHERE setting_key = #{key} LIMIT 1")
    SystemSetting findByKey(@Param("key") String key);
}

