package com.minicloud.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.minicloud.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface UserMapper extends BaseMapper<User> {

    @Select("SELECT * FROM sys_user WHERE username = #{username} AND deleted = 0")
    User findByUsername(@Param("username") String username);

    @Select("SELECT * FROM sys_user WHERE department_id = #{departmentId} AND deleted = 0")
    List<User> findByDepartmentId(@Param("departmentId") Long departmentId);

    @Select("SELECT * FROM sys_user WHERE department_id = #{departmentId} AND role_type >= 1 AND deleted = 0")
    List<User> findDepartmentAdmins(@Param("departmentId") Long departmentId);

    @org.apache.ibatis.annotations.Update("UPDATE sys_user SET used_space_size = #{usedSpaceSize} WHERE id = #{userId}")
    int updateUsedSpaceSize(@Param("userId") Long userId, @Param("usedSpaceSize") Long usedSpaceSize);
}
