package com.minicloud.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.minicloud.dto.DepartmentTreeNode;
import com.minicloud.entity.Department;

import java.util.List;

public interface DepartmentService extends IService<Department> {

    List<DepartmentTreeNode> getDepartmentTree();

    void refreshDepartmentManager(Long departmentId, Long managerId);

    void removeManagerAssignments(Long userId);

    Department createDepartment(Department department);

    Department updateDepartment(Long departmentId, Department department);

    boolean deleteDepartment(Long departmentId);

    void updateDepartmentUsedSpace(Long departmentId);

    boolean isSubordinate(Long parentDepartmentId, Long targetDepartmentId);
}

