package com.minicloud.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.minicloud.dto.ApprovalActionRequest;
import com.minicloud.dto.ApprovalAttachment;
import com.minicloud.dto.ApprovalCreateRequest;
import com.minicloud.entity.FileApproval;

import java.util.List;
import org.springframework.web.multipart.MultipartFile;

/**
 * 文件审批服务接口
 */
public interface FileApprovalService extends IService<FileApproval> {

    /**
     * 创建审批申请
     */
    FileApproval createApproval(Long applicantId, ApprovalCreateRequest request);

    /**
     * 获取我提交的审批列表
     */
    List<FileApproval> listMyApplications(Long applicantId);

    /**
     * 获取待我审批的列表
     */
    List<FileApproval> listPendingApprovals(Long approverId);

    /**
     * 获取我的审批历史（已处理）
     */
    List<FileApproval> listApprovalHistory(Long approverId);

    /**
     * 审批通过
     */
    FileApproval approve(Long approverId, Long approvalId, ApprovalActionRequest request);

    /**
     * 审批驳回
     */
    FileApproval reject(Long approverId, Long approvalId, ApprovalActionRequest request);

    /**
     * 上传审批附件
     */
    List<ApprovalAttachment> uploadAttachments(Long applicantId, MultipartFile[] files);

    /**
     * 获取审批附件列表
     */
    List<ApprovalAttachment> getAttachments(Long approvalId, Long requesterId);
}

