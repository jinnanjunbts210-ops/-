package com.minicloud.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.minicloud.dto.SpaceCleanupResponse;
import com.minicloud.dto.SpaceOverviewResponse;
import com.minicloud.entity.FileInfo;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.List;

public interface FileService extends IService<FileInfo> {

    FileInfo uploadFile(MultipartFile file, Long parentId, Integer spaceType, Long spaceId, Long userId);

    FileInfo uploadChunk(MultipartFile chunk, Integer chunkNumber, Integer totalChunks, String fileName,
                         Long fileSize, String md5, Long parentId, Integer spaceType, Long spaceId, Long userId);

    InputStream downloadFile(Long fileId, Long userId);

    String getPreviewUrl(Long fileId, Long userId);

    FileInfo createDirectory(String directoryName, Long parentId, Integer spaceType, Long spaceId, Long userId);

    boolean deleteFile(Long fileId, Long userId);

    boolean permanentDeleteFile(Long fileId, Long userId);

    boolean restoreFile(Long fileId, Long userId);

    boolean renameFile(Long fileId, String newName, Long userId);

    boolean moveFile(Long fileId, Long targetParentId, Long userId);

    FileInfo copyFile(Long fileId, Long targetParentId, Long userId);

    List<FileInfo> getFileList(Long parentId, Integer spaceType, Long spaceId, Long userId);

    IPage<FileInfo> searchFiles(String keyword, Integer spaceType, Long spaceId, Long userId, Page<FileInfo> page);

    List<FileInfo> getRecycledFiles(Long userId);

    boolean clearRecycleBin(Long userId);

    boolean checkFilePermission(Long fileId, Long userId, String permission);

    String getFilePath(Long fileId);

    Long calculateDirectorySize(Long directoryId);

    void deleteUserPersonalSpace(Long userId);

    SpaceOverviewResponse getSpaceOverview();

    SpaceCleanupResponse cleanupSystemGarbage();
}



