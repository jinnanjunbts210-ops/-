package com.minicloud.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.minicloud.dto.ShareInfoResponse;
import com.minicloud.entity.FileShare;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

public interface FileShareService extends IService<FileShare> {

    FileShare createShare(Long fileId, Long sharerId, Integer shareType, Long targetId,
                          Map<String, Boolean> permissions, LocalDateTime expireTime);

    boolean updateSharePermissions(Long shareId, Long sharerId, Map<String, Boolean> permissions);

    boolean cancelShare(Long shareId, Long sharerId);

    List<ShareInfoResponse> getUserShares(Long userId);

    List<ShareInfoResponse> getSharedToUser(Long userId);

    List<FileShare> getSharedToDepartment(Long departmentId);

    boolean checkSharePermission(Long fileId, Long userId, String permission);

    FileShare findEffectiveShare(Long fileId, Long userId);

    List<ShareInfoResponse> getFileShareInfo(Long fileId);

    List<FileShare> batchShare(List<Long> fileIds, Long sharerId, Integer shareType, List<Long> targetIds,
                               Map<String, Boolean> permissions, LocalDateTime expireTime);

    boolean checkShareExpired(Long shareId);

    int cleanExpiredShares();

    void removeSharesRelatedToUser(Long userId);

    boolean removeReceivedShares(List<Long> shareIds, Long userId);
}
