package com.minicloud.service;

import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.Map;

public interface MinioService {

    String uploadFile(MultipartFile file, String objectName);

    String uploadFile(InputStream inputStream, String objectName, String contentType, Long size);

    InputStream downloadFile(String objectName);

    boolean deleteFile(String objectName);

    String getPresignedUrl(String objectName, int expiry);

    boolean fileExists(String objectName);

    Map<String, Object> getFileInfo(String objectName);

    boolean copyFile(String sourceObjectName, String targetObjectName);

    String generateUniqueFileName(String originalFileName);
}

