package com.minicloud.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.minicloud.entity.SystemLog;

public interface SystemLogService extends IService<SystemLog> {

    void log(SystemLog log);

    IPage<SystemLog> queryLogs(Long userId, Integer roleType, Long departmentId, int page, int size);
}
