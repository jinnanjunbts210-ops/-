package com.minicloud.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.minicloud.dto.SystemConfigRequest;
import com.minicloud.dto.SystemConfigResponse;
import com.minicloud.entity.SystemSetting;

public interface SystemSettingService extends IService<SystemSetting> {

    String KEY_SITE_DOMAIN = "site.domain";
    String KEY_DEFAULT_PERSONAL_SPACE = "space.personal.default";
    String KEY_MAX_UPLOAD_SIZE = "upload.max.size";

    String getValue(String key, String defaultValue);

    Long getLongValue(String key, Long defaultValue);

    void setValue(String key, String value, String description);

    SystemConfigResponse getSystemConfig();

    void updateSystemConfig(SystemConfigRequest request);
}



