package com.minicloud.service;

import com.minicloud.dto.UserImportResult;
import org.springframework.web.multipart.MultipartFile;

public interface UserImportService {

    byte[] generateTemplate();

    UserImportResult importUsers(MultipartFile file, Long operatorId);
}
