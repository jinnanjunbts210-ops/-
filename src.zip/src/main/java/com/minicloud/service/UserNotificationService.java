package com.minicloud.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.minicloud.entity.UserNotification;

import java.util.List;

public interface UserNotificationService extends IService<UserNotification> {

    UserNotification notifyUser(Long userId, String title, String message, String link);

    List<UserNotification> listNotifications(Long userId, boolean unreadOnly, int limit);

    void markAsRead(Long userId, Long notificationId);

    void markAllAsRead(Long userId);

    long countUnread(Long userId);
}
