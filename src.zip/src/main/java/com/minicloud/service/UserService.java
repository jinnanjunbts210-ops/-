package com.minicloud.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.minicloud.entity.User;

import java.util.List;

public interface UserService extends IService<User> {

    User findByUsername(String username);

    User register(User user);

    boolean changePassword(Long userId, String oldPassword, String newPassword);

    boolean resetPassword(String username, List<String> answers, String newPassword);

    User updateUserInfo(Long userId, User user);

    boolean updateUserStatus(Long userId, Integer status);

    boolean updateUserSpaceSize(Long userId, Long spaceSize);

    Long updateUsedSpaceSize(Long userId);

    boolean checkUserPermission(Long userId, String permission);

    List<User> listAllUsers();

    boolean adminResetPassword(Long userId, String newPassword);

    User createUser(User user, String rawPassword);

    User adminUpdateUser(Long userId, User user, String newPassword, Boolean clearDepartment);

    boolean deleteUser(Long userId);
}
