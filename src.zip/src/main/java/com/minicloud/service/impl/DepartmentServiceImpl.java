package com.minicloud.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.minicloud.dto.DepartmentTreeNode;
import com.minicloud.entity.Department;
import com.minicloud.entity.User;
import com.minicloud.mapper.DepartmentMapper;
import com.minicloud.mapper.FileInfoMapper;
import com.minicloud.service.DepartmentService;
import com.minicloud.service.UserService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Service
@Transactional
public class DepartmentServiceImpl extends ServiceImpl<DepartmentMapper, Department> implements DepartmentService {

    private final DepartmentMapper departmentMapper;
    private final FileInfoMapper fileInfoMapper;
    private final UserService userService;

    public DepartmentServiceImpl(DepartmentMapper departmentMapper,
                                 FileInfoMapper fileInfoMapper,
                                 UserService userService) {
        this.departmentMapper = departmentMapper;
        this.fileInfoMapper = fileInfoMapper;
        this.userService = userService;
    }

    @Override
    public List<DepartmentTreeNode> getDepartmentTree() {
        QueryWrapper<Department> wrapper = new QueryWrapper<>();
        wrapper.eq("deleted", 0);
        List<Department> departments = departmentMapper.selectList(wrapper);
        Map<Long, DepartmentTreeNode> nodeMap = new HashMap<>();
        List<DepartmentTreeNode> roots = new ArrayList<>();

        for (Department department : departments) {
            DepartmentTreeNode node = new DepartmentTreeNode(
                department.getId(),
                department.getName(),
                department.getParentId()
            );
            nodeMap.put(node.getId(), node);
        }

        for (Department department : departments) {
            DepartmentTreeNode node = nodeMap.get(department.getId());
            Long parentId = department.getParentId();
            if (parentId == null) {
                roots.add(node);
            } else {
                DepartmentTreeNode parent = nodeMap.get(parentId);
                if (parent != null) {
                    parent.addChild(node);
                } else {
                    roots.add(node);
                }
            }
        }
        return roots;
    }

    @Override
    public void refreshDepartmentManager(Long departmentId, Long managerId) {
        if (departmentId == null) {
            return;
        }
        Department department = departmentMapper.selectById(departmentId);
        if (department == null) {
            return;
        }
        if (!Objects.equals(department.getManagerId(), managerId)) {
            department.setManagerId(managerId);
            departmentMapper.updateById(department);
        }
        bindManagerToDepartment(departmentId, managerId);
    }

    @Override
    public void removeManagerAssignments(Long userId) {
        if (userId == null) {
            return;
        }
        this.lambdaUpdate()
            .eq(Department::getManagerId, userId)
            .set(Department::getManagerId, null)
            .update();
    }

    @Override
    public Department createDepartment(Department department) {
        if (department == null) {
            throw new IllegalArgumentException("Department information cannot be null");
        }
        save(department);
        if (department.getManagerId() != null) {
            refreshDepartmentManager(department.getId(), department.getManagerId());
        }
        return department;
    }

    @Override
    public Department updateDepartment(Long departmentId, Department department) {
        Department existing = getById(departmentId);
        if (existing == null) {
            throw new RuntimeException("Department does not exist");
        }
        Long originalManagerId = existing.getManagerId();

        if (department.getName() != null) {
            existing.setName(department.getName());
        }
        if (department.getParentId() != null) {
            existing.setParentId(department.getParentId());
        }
        if (department.getDepartmentSpaceSize() != null) {
            existing.setDepartmentSpaceSize(department.getDepartmentSpaceSize());
        }
        if (department.getDescription() != null) {
            existing.setDescription(department.getDescription());
        }
        if (department.getSortOrder() != null) {
            existing.setSortOrder(department.getSortOrder());
        }
        existing.setManagerId(department.getManagerId());

        updateById(existing);

        Long newManagerId = department.getManagerId();
        if (!Objects.equals(originalManagerId, newManagerId)) {
            if (newManagerId != null) {
                refreshDepartmentManager(existing.getId(), newManagerId);
            } else if (originalManagerId != null) {
                removeManagerAssignments(originalManagerId);
            }
        }
        return existing;
    }

    @Override
    public boolean deleteDepartment(Long departmentId) {
        Department department = getById(departmentId);
        if (department == null) {
            return false;
        }
        List<Department> children = departmentMapper.findByParentId(departmentId);
        if (!children.isEmpty()) {
            throw new RuntimeException("Remove child departments first");
        }
        long memberCount = userService.lambdaQuery()
            .eq(User::getDepartmentId, departmentId)
            .eq(User::getDeleted, 0)
            .count();
        if (memberCount > 0) {
            throw new RuntimeException("Reassign department members before deletion");
        }
        removeManagerAssignments(department.getManagerId());
        return removeById(departmentId);
    }

    @Override
    public void updateDepartmentUsedSpace(Long departmentId) {
        if (departmentId == null) {
            return;
        }
        Long usedSpace = fileInfoMapper.calculateDepartmentUsedSpace(departmentId);
        departmentMapper.updateUsedSpaceSize(departmentId, usedSpace != null ? usedSpace : 0L);
    }

    @Override
    public boolean isSubordinate(Long parentDepartmentId, Long targetDepartmentId) {
        if (parentDepartmentId == null || targetDepartmentId == null) {
            return false;
        }
        if (Objects.equals(parentDepartmentId, targetDepartmentId)) {
            return false;
        }

        QueryWrapper<Department> wrapper = new QueryWrapper<>();
        wrapper.eq("deleted", 0);
        List<Department> departments = departmentMapper.selectList(wrapper);
        Map<Long, Department> departmentMap = new HashMap<>();
        for (Department department : departments) {
            departmentMap.put(department.getId(), department);
        }

        Department current = departmentMap.get(targetDepartmentId);
        while (current != null && current.getParentId() != null) {
            if (Objects.equals(current.getParentId(), parentDepartmentId)) {
                return true;
            }
            current = departmentMap.get(current.getParentId());
        }
        return false;
    }

    private void bindManagerToDepartment(Long departmentId, Long managerId) {
        if (departmentId == null || managerId == null) {
            return;
        }
        User manager = userService.getById(managerId);
        if (manager == null) {
            throw new RuntimeException("Department manager does not exist");
        }
        User update = new User();
        update.setDepartmentId(departmentId);
        if (manager.getRoleType() == null || manager.getRoleType() < 1) {
            update.setRoleType(1);
        }
        userService.adminUpdateUser(managerId, update, null, false);
    }
}
