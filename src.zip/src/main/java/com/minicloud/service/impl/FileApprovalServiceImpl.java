package com.minicloud.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.minicloud.annotation.OperationLog;
import com.minicloud.dto.ApprovalActionRequest;
import com.minicloud.dto.ApprovalAttachment;
import com.minicloud.dto.ApprovalCreateRequest;
import com.minicloud.entity.Department;
import com.minicloud.entity.FileApproval;
import com.minicloud.entity.User;
import com.minicloud.mapper.DepartmentMapper;
import com.minicloud.mapper.FileApprovalMapper;
import com.minicloud.service.FileApprovalService;
import com.minicloud.service.MinioService;
import com.minicloud.service.UserNotificationService;
import com.minicloud.service.UserService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Service
@Transactional
public class FileApprovalServiceImpl extends ServiceImpl<FileApprovalMapper, FileApproval>
    implements FileApprovalService {

    private final FileApprovalMapper fileApprovalMapper;
    private final UserService userService;
    private final DepartmentMapper departmentMapper;
    private final MinioService minioService;
    private final UserNotificationService notificationService;
    private final ObjectMapper objectMapper;

    public FileApprovalServiceImpl(FileApprovalMapper fileApprovalMapper,
                                   UserService userService,
                                   DepartmentMapper departmentMapper,
                                   MinioService minioService,
                                   UserNotificationService notificationService,
                                   ObjectMapper objectMapper) {
        this.fileApprovalMapper = fileApprovalMapper;
        this.userService = userService;
        this.departmentMapper = departmentMapper;
        this.minioService = minioService;
        this.notificationService = notificationService;
        this.objectMapper = objectMapper;
    }

    @Override
    @OperationLog("Create approval request")
    public FileApproval createApproval(Long applicantId, ApprovalCreateRequest request) {
        User applicant = userService.getById(applicantId);
        if (applicant == null) {
            throw new RuntimeException("Applicant does not exist");
        }

        User approver = userService.getById(request.getApproverId());
        if (approver == null) {
            throw new RuntimeException("Approver does not exist");
        }

        String departmentName = null;
        if (applicant.getDepartmentId() != null) {
            Department department = departmentMapper.selectById(applicant.getDepartmentId());
            if (department != null) {
                departmentName = department.getName();
            }
        }

        FileApproval approval = new FileApproval();
        approval.setTitle(request.getTitle());
        approval.setContent(request.getContent());
        approval.setApplicantId(applicantId);
        approval.setApplicantName(applicant.getRealName() != null ? applicant.getRealName() : applicant.getUsername());
        approval.setApplicantDepartment(departmentName);
        approval.setApplicantContact(request.getApplicantContact());
        approval.setApproverId(request.getApproverId());
        approval.setAttachmentFiles(request.getAttachmentFiles());
        approval.setStatus(0);

        save(approval);

        notificationService.notifyUser(
            request.getApproverId(),
            "New approval request",
            String.format("From %s: approval request \"%s\"", approval.getApplicantName(), approval.getTitle()),
            "/approvals?tab=pending"
        );

        return approval;
    }

    @Override
    public List<FileApproval> listMyApplications(Long applicantId) {
        return fileApprovalMapper.findByApplicantId(applicantId);
    }

    @Override
    public List<FileApproval> listPendingApprovals(Long approverId) {
        return fileApprovalMapper.findPendingApprovals(approverId);
    }

    @Override
    public List<FileApproval> listApprovalHistory(Long approverId) {
        return fileApprovalMapper.findApprovalHistory(approverId);
    }

    @Override
    @OperationLog("Approve request")
    public FileApproval approve(Long approverId, Long approvalId, ApprovalActionRequest request) {
        FileApproval approval = getById(approvalId);
        if (approval == null) {
            throw new RuntimeException("Approval record does not exist");
        }
        if (!Objects.equals(approval.getApproverId(), approverId)) {
            throw new RuntimeException("No permission to approve this record");
        }
        if (!Integer.valueOf(0).equals(approval.getStatus())) {
            throw new RuntimeException("Approval already processed");
        }

        approval.setApprovalComment(request.getComment());
        approval.setApprovalTime(LocalDateTime.now());

        Long nextApproverId = request.getNextApproverId();
        if (nextApproverId != null && !Objects.equals(nextApproverId, approverId)) {
            User nextApprover = userService.getById(nextApproverId);
            if (nextApprover == null) {
                throw new RuntimeException("Next approver does not exist");
            }
            approval.setApproverId(nextApproverId);
            approval.setStatus(0);
            approval.setNextApproverId(null);

            notificationService.notifyUser(
                nextApproverId,
                "New approval task",
                String.format("Approval request \"%s\" has been forwarded to you.", approval.getTitle()),
                "/approvals?tab=pending"
            );
            notificationService.notifyUser(
                approval.getApplicantId(),
                "Approval forwarded",
                String.format("Approval request \"%s\" has been forwarded to the next approver.", approval.getTitle()),
                "/approvals?tab=applications"
            );
        } else {
            approval.setStatus(1);
            approval.setNextApproverId(null);

            notificationService.notifyUser(
                approval.getApplicantId(),
                "Approval approved",
                String.format("Approval request \"%s\" has been approved.", approval.getTitle()),
                "/approvals?tab=applications"
            );
        }

        updateById(approval);
        return approval;
    }

    @Override
    @OperationLog("Reject request")
    public FileApproval reject(Long approverId, Long approvalId, ApprovalActionRequest request) {
        FileApproval approval = getById(approvalId);
        if (approval == null) {
            throw new RuntimeException("Approval record does not exist");
        }
        if (!Objects.equals(approval.getApproverId(), approverId)) {
            throw new RuntimeException("No permission to approve this record");
        }
        if (!Integer.valueOf(0).equals(approval.getStatus())) {
            throw new RuntimeException("Approval already processed");
        }

        approval.setApprovalComment(request.getComment());
        approval.setStatus(2);
        approval.setApprovalTime(LocalDateTime.now());
        approval.setNextApproverId(null);

        updateById(approval);

        notificationService.notifyUser(
            approval.getApplicantId(),
            "Approval rejected",
            String.format("Approval request \"%s\" was rejected: %s", approval.getTitle(), request.getComment() != null ? request.getComment() : ""),
            "/approvals?tab=applications"
        );

        return approval;
    }

    @Override
    public List<ApprovalAttachment> uploadAttachments(Long applicantId, MultipartFile[] files) {
        if (files == null || files.length == 0) {
            return Collections.emptyList();
        }
        List<ApprovalAttachment> attachments = new ArrayList<>();
        for (MultipartFile file : files) {
            if (file == null || file.isEmpty()) {
                continue;
            }
            String originalName = file.getOriginalFilename();
            String uniqueName = UUID.randomUUID().toString().replace("-", "");
            String objectKey = "approvals/" + applicantId + "/" + uniqueName;
            if (originalName != null && originalName.contains(".")) {
                objectKey += originalName.substring(originalName.lastIndexOf("."));
            }
            String storedKey = minioService.uploadFile(file, objectKey);
            ApprovalAttachment attachment = new ApprovalAttachment(
                originalName != null ? originalName : storedKey,
                storedKey,
                file.getSize(),
                file.getContentType()
            );
            attachment.setPreviewUrl(minioService.getPresignedUrl(storedKey, 3600));
            attachments.add(attachment);
        }
        return attachments;
    }

    @Override
    public List<ApprovalAttachment> getAttachments(Long approvalId, Long requesterId) {
        FileApproval approval = getById(approvalId);
        if (approval == null) {
            throw new RuntimeException("Approval record does not exist");
        }
        if (!Objects.equals(approval.getApplicantId(), requesterId) && !Objects.equals(approval.getApproverId(), requesterId)) {
            throw new RuntimeException("No permission to view attachments");
        }
        List<ApprovalAttachment> attachments = deserializeAttachments(approval.getAttachmentFiles());
        for (ApprovalAttachment attachment : attachments) {
            if (attachment.getObjectKey() != null) {
                String url = minioService.getPresignedUrl(attachment.getObjectKey(), 3600);
                attachment.setPreviewUrl(url);
            }
        }
        return attachments;
    }

    private List<ApprovalAttachment> deserializeAttachments(String json) {
        if (json == null || json.isBlank()) {
            return Collections.emptyList();
        }
        try {
            return objectMapper.readValue(json, new TypeReference<List<ApprovalAttachment>>() {});
        } catch (Exception e) {
            return Collections.emptyList();
        }
    }
}
