package com.minicloud.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.minicloud.annotation.OperationLog;
import com.minicloud.dto.SpaceCleanupResponse;
import com.minicloud.dto.SpaceOverviewResponse;
import com.minicloud.entity.FileInfo;
import com.minicloud.entity.FileShare;
import com.minicloud.entity.Department;
import com.minicloud.entity.User;
import com.minicloud.mapper.FileInfoMapper;
import com.minicloud.service.DepartmentService;
import com.minicloud.service.FileService;
import com.minicloud.service.FileShareService;
import com.minicloud.service.SystemSettingService;
import com.minicloud.service.MinioService;
import com.minicloud.service.UserService;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.FilenameUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Service
@Transactional
public class FileServiceImpl extends ServiceImpl<FileInfoMapper, FileInfo> implements FileService {

    private static final String CHUNK_CACHE_PREFIX = "file_chunk:";
    private static final long CHUNK_CACHE_EXPIRE = 24L;

    private final FileInfoMapper fileInfoMapper;
    private final MinioService minioService;
    private final UserService userService;
    private final FileShareService fileShareService;
    private final DepartmentService departmentService;
    private final SystemSettingService systemSettingService;
    private final RedisTemplate<String, Object> redisTemplate;
    // Align with `space_type` column values.
    private static final int SPACE_PERSONAL = 0;
    private static final int SPACE_DEPARTMENT = 1;
    private static final int SPACE_ENTERPRISE = 2;
    private static final int SPACE_SHARED = 3;


    public FileServiceImpl(FileInfoMapper fileInfoMapper,
                           MinioService minioService,
                           UserService userService,
                           FileShareService fileShareService,
                           DepartmentService departmentService,
                           SystemSettingService systemSettingService,
                           RedisTemplate<String, Object> redisTemplate) {
        this.fileInfoMapper = fileInfoMapper;
        this.minioService = minioService;
        this.userService = userService;
        this.fileShareService = fileShareService;
        this.departmentService = departmentService;
        this.systemSettingService = systemSettingService;
        this.redisTemplate = redisTemplate;
    }

    @Override
    @OperationLog("Upload file")
    public FileInfo uploadFile(MultipartFile file, Long parentId, Integer spaceType, Long spaceId, Long userId) {
        if (parentId != null) {
            if (!checkFilePermission(parentId, userId, "upload")) {
                throw new RuntimeException("No upload permission");
            }
        } else if (spaceType != null && spaceType == 3) {
            throw new RuntimeException("Shared space root does not support uploads");
        }

        ensureUploadAllowed(userId, spaceType, spaceId, file.getSize());

        String originalName = file.getOriginalFilename() != null ? file.getOriginalFilename() : "unknown";
        checkFileNameDuplicate(originalName, parentId, spaceType, spaceId, userId);

        String md5Hash;
        try {
            md5Hash = DigestUtils.md5Hex(file.getInputStream());
        } catch (IOException e) {
            throw new RuntimeException("Failed to read file", e);
        }

        FileInfo existingFile = fileInfoMapper.findByMd5Hash(md5Hash);
        String filePath;
        if (existingFile != null) {
            filePath = existingFile.getFilePath();
        } else {
            filePath = minioService.uploadFile(file, minioService.generateUniqueFileName(originalName));
        }

        FileInfo fileInfo = new FileInfo();
        fileInfo.setFileName(originalName);
        fileInfo.setFilePath(filePath);
        fileInfo.setFileSize(file.getSize());
        fileInfo.setFileType(FilenameUtils.getExtension(originalName));
        fileInfo.setMimeType(file.getContentType());
        fileInfo.setMd5Hash(md5Hash);
        fileInfo.setOwnerId(userId);
        fileInfo.setParentId(parentId);
        fileInfo.setSpaceType(spaceType);
        fileInfo.setSpaceId(spaceId);
        fileInfo.setDirectory(0);

        save(fileInfo);
        userService.updateUsedSpaceSize(userId);
        updateDepartmentUsageIfNeeded(spaceType, spaceId);
        applyPermissions(fileInfo, userId);
        return fileInfo;
    }

    @Override
    @OperationLog("Upload chunk")
    public FileInfo uploadChunk(MultipartFile chunk, Integer chunkNumber, Integer totalChunks, String fileName,
                                Long fileSize, String md5, Long parentId, Integer spaceType, Long spaceId,
                                Long userId) {
        if (parentId != null) {
            if (!checkFilePermission(parentId, userId, "upload")) {
                throw new RuntimeException("No upload permission");
            }
        } else if (spaceType != null && spaceType == 3) {
            throw new RuntimeException("Shared space root does not support uploads");
        }

        ensureUploadAllowed(userId, spaceType, spaceId, fileSize != null ? fileSize : chunk.getSize());

        String chunkKey = CHUNK_CACHE_PREFIX + md5 + ":" + chunkNumber;
        try {
            redisTemplate.opsForValue().set(chunkKey, chunk.getBytes(), CHUNK_CACHE_EXPIRE, TimeUnit.HOURS);
        } catch (IOException e) {
            throw new RuntimeException("Failed to read chunk", e);
        }

        boolean allUploaded = true;
        for (int i = 1; i <= totalChunks; i++) {
            if (Boolean.FALSE.equals(redisTemplate.hasKey(CHUNK_CACHE_PREFIX + md5 + ":" + i))) {
                allUploaded = false;
                break;
            }
        }

        if (allUploaded) {
            return mergeChunks(fileName, fileSize, md5, totalChunks, parentId, spaceType, spaceId, userId);
        }

        return null;
    }

    private FileInfo mergeChunks(String fileName, Long fileSize, String md5, Integer totalChunks,
                                 Long parentId, Integer spaceType, Long spaceId, Long userId) {
        checkFileNameDuplicate(fileName, parentId, spaceType, spaceId, userId);

        FileInfo existingFile = fileInfoMapper.findByMd5Hash(md5);
        String filePath;

        if (existingFile != null) {
            filePath = existingFile.getFilePath();
        } else {
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            try {
                for (int i = 1; i <= totalChunks; i++) {
                    String chunkKey = CHUNK_CACHE_PREFIX + md5 + ":" + i;
                    Object value = redisTemplate.opsForValue().get(chunkKey);
                    if (!(value instanceof byte[])) {
                        throw new RuntimeException("Chunk data missing");
                    }
                    outputStream.write((byte[]) value);
                }
            } catch (IOException e) {
                throw new RuntimeException("Failed to merge chunks", e);
            }

            String objectName = minioService.generateUniqueFileName(fileName);
            byte[] data = outputStream.toByteArray();
            filePath = minioService.uploadFile(new ByteArrayInputStream(data), objectName,
                "application/octet-stream", fileSize);
        }

        for (int i = 1; i <= totalChunks; i++) {
            redisTemplate.delete(CHUNK_CACHE_PREFIX + md5 + ":" + i);
        }

        FileInfo fileInfo = new FileInfo();
        fileInfo.setFileName(fileName);
        fileInfo.setFilePath(filePath);
        fileInfo.setFileSize(fileSize);
        fileInfo.setFileType(FilenameUtils.getExtension(fileName));
        fileInfo.setMimeType("application/octet-stream");
        fileInfo.setMd5Hash(md5);
        fileInfo.setOwnerId(userId);
        fileInfo.setParentId(parentId);
        fileInfo.setSpaceType(spaceType);
        fileInfo.setSpaceId(spaceId);
        fileInfo.setDirectory(0);

        save(fileInfo);
        userService.updateUsedSpaceSize(userId);
        updateDepartmentUsageIfNeeded(fileInfo.getSpaceType(), fileInfo.getSpaceId());
        applyPermissions(fileInfo, userId);
        return fileInfo;
    }

    @Override
    public InputStream downloadFile(Long fileId, Long userId) {
        FileInfo fileInfo = getById(fileId);
        if (fileInfo == null) {
            throw new RuntimeException("File does not exist");
        }

        if (!checkFilePermission(fileId, userId, "download")) {
            throw new RuntimeException("No download permission");
        }

        Long downloadCount = fileInfo.getDownloadCount() != null ? fileInfo.getDownloadCount() : 0L;
        fileInfo.setDownloadCount(downloadCount + 1);
        updateById(fileInfo);

        return minioService.downloadFile(fileInfo.getFilePath());
    }

    @Override
    public String getPreviewUrl(Long fileId, Long userId) {
        FileInfo fileInfo = getById(fileId);
        if (fileInfo == null) {
            throw new RuntimeException("File does not exist");
        }

        if (!checkFilePermission(fileId, userId, "preview")) {
            throw new RuntimeException("No preview permission");
        }

        return minioService.getPresignedUrl(fileInfo.getFilePath(), 3600);
    }

    @Override
    @OperationLog("Create directory")
    public FileInfo createDirectory(String directoryName, Long parentId, Integer spaceType, Long spaceId, Long userId) {
        if (parentId != null) {
            if (!checkFilePermission(parentId, userId, "upload")) {
                throw new RuntimeException("No permission to create a directory in the target location");
            }
        } else if (spaceType != null && spaceType == 3) {
            throw new RuntimeException("Shared space root does not support creating directories");
        }

        checkFileNameDuplicate(directoryName, parentId, spaceType, spaceId, userId);

        FileInfo directory = new FileInfo();
        directory.setFileName(directoryName);
        directory.setFilePath("");
        directory.setFileSize(0L);
        directory.setFileType("directory");
        directory.setMimeType("directory");
        directory.setOwnerId(userId);
        directory.setParentId(parentId);
        directory.setSpaceType(spaceType);
        directory.setSpaceId(spaceId);
        directory.setDirectory(1);

        save(directory);
        applyPermissions(directory, userId);
        
        // Force directory to true when returning
        FileInfo result = getById(directory.getId());
        result.setDirectory(1);
        return result;
    }

    @Override
    @OperationLog("Delete file")
    public boolean deleteFile(Long fileId, Long userId) {
        FileInfo fileInfo = getById(fileId);
        if (fileInfo == null) {
            return false;
        }

        if (!checkFilePermission(fileId, userId, "delete")) {
            return false;
        }

        fileInfo.setRecycled(Boolean.TRUE);
        fileInfo.setRecycledTime(LocalDateTime.now());
        boolean result = updateById(fileInfo);

        if (java.util.Objects.equals(fileInfo.getDirectory(), 1)) {
            deleteChildrenRecursively(fileId, userId);
        }

        userService.updateUsedSpaceSize(userId);
        updateDepartmentUsageIfNeeded(fileInfo.getSpaceType(), fileInfo.getSpaceId());
        return result;
    }

    @Override
    @OperationLog("Permanent delete file")
    public boolean permanentDeleteFile(Long fileId, Long userId) {
        FileInfo fileInfo = getById(fileId);
        if (fileInfo == null) {
            return false;
        }

        if (!checkFilePermission(fileId, userId, "delete")) {
            return false;
        }

        if (java.util.Objects.equals(fileInfo.getDirectory(), 1)) {
            permanentDeleteChildrenRecursively(fileId, userId);
        } else {
            minioService.deleteFile(fileInfo.getFilePath());
        }

        boolean result = removeById(fileId);
        userService.updateUsedSpaceSize(userId);
        updateDepartmentUsageIfNeeded(fileInfo.getSpaceType(), fileInfo.getSpaceId());
        return result;
    }

    @Override
    @OperationLog("Restore file")
    public boolean restoreFile(Long fileId, Long userId) {
        FileInfo fileInfo = getById(fileId);
        if (fileInfo == null) {
            return false;
        }

        if (!Objects.equals(fileInfo.getOwnerId(), userId)) {
            return false;
        }

        fileInfo.setRecycled(Boolean.FALSE);
        fileInfo.setRecycledTime(null);
        boolean result = updateById(fileInfo);

        if (java.util.Objects.equals(fileInfo.getDirectory(), 1)) {
            restoreChildrenRecursively(fileId, userId);
        }

        userService.updateUsedSpaceSize(userId);
        updateDepartmentUsageIfNeeded(fileInfo.getSpaceType(), fileInfo.getSpaceId());
        return result;
    }

    @Override
    @OperationLog("Rename file")
    public boolean renameFile(Long fileId, String newName, Long userId) {
        FileInfo fileInfo = getById(fileId);
        if (fileInfo == null) {
            return false;
        }

        if (!checkFilePermission(fileId, userId, "modify")) {
            return false;
        }

        checkFileNameDuplicate(newName, fileInfo.getParentId(), fileInfo.getSpaceType(), fileInfo.getSpaceId(), userId);
        fileInfo.setFileName(newName);
        return updateById(fileInfo);
    }

    @Override
    @OperationLog("Move file")
    public boolean moveFile(Long fileId, Long targetParentId, Long userId) {
        FileInfo fileInfo = getById(fileId);
        if (fileInfo == null) {
            return false;
        }

        if (!checkFilePermission(fileId, userId, "modify")) {
            return false;
        }

        if (targetParentId != null && !checkFilePermission(targetParentId, userId, "upload")) {
            return false;
        }

        checkFileNameDuplicate(fileInfo.getFileName(), targetParentId, fileInfo.getSpaceType(), fileInfo.getSpaceId(), userId);
        fileInfo.setParentId(targetParentId);
        return updateById(fileInfo);
    }

    @Override
    @OperationLog("Copy file")
    public FileInfo copyFile(Long fileId, Long targetParentId, Long userId) {
        FileInfo sourceFile = getById(fileId);
        if (sourceFile == null) {
            throw new RuntimeException("Source file not found");
        }

        if (!checkFilePermission(fileId, userId, "download")) {
            throw new RuntimeException("No copy permission");
        }

        if (targetParentId != null && !checkFilePermission(targetParentId, userId, "upload")) {
            throw new RuntimeException("No upload permission for target directory");
        }

        String newFileName = generateCopyFileName(
            sourceFile.getFileName(), targetParentId, sourceFile.getSpaceType(), sourceFile.getSpaceId(), userId
        );

        FileInfo copiedFile = new FileInfo();
        copiedFile.setFileName(newFileName);
        copiedFile.setFilePath(sourceFile.getFilePath());
        copiedFile.setFileSize(sourceFile.getFileSize());
        copiedFile.setFileType(sourceFile.getFileType());
        copiedFile.setMimeType(sourceFile.getMimeType());
        copiedFile.setMd5Hash(sourceFile.getMd5Hash());
        copiedFile.setOwnerId(userId);
        copiedFile.setParentId(targetParentId);
        copiedFile.setSpaceType(sourceFile.getSpaceType());
        copiedFile.setSpaceId(sourceFile.getSpaceId());
        copiedFile.setDirectory(Objects.equals(sourceFile.getDirectory(), 1) ? 1 : 0);
        copiedFile.setShared(Boolean.FALSE);
        copiedFile.setDownloadCount(0L);
        copiedFile.setRecycled(Boolean.FALSE);
        copiedFile.setRecycledTime(null);

        save(copiedFile);

        if (java.util.Objects.equals(sourceFile.getDirectory(), 1) && copiedFile.getId() != null) {
            copyChildrenRecursively(fileId, copiedFile.getId(), userId);
        }

        userService.updateUsedSpaceSize(userId);
        updateDepartmentUsageIfNeeded(copiedFile.getSpaceType(), copiedFile.getSpaceId());
        applyPermissions(copiedFile, userId);
        return copiedFile;
    }

    @Override
    public List<FileInfo> getFileList(Long parentId, Integer spaceType, Long spaceId, Long userId) {
        if (spaceType == null) {
            return new ArrayList<>();
        }

        List<FileInfo> result;
        switch (spaceType) {
            case 0:
                result = fileInfoMapper.findByParentId(parentId, userId, spaceType, spaceId);
                break;
            case 3:
                result = getSharedFileList(parentId, spaceId, userId);
                break;
            default:
                result = getSpaceFileList(parentId, spaceType, spaceId, userId);
                break;
        }
        enrichPermissions(result, userId);
        return result;
    }

    @Override
    public IPage<FileInfo> searchFiles(String keyword, Integer spaceType, Long spaceId, Long userId, Page<FileInfo> page) {
        IPage<FileInfo> result = fileInfoMapper.searchFiles(page, keyword, userId, spaceType);
        enrichPermissions(result.getRecords(), userId);
        return result;
    }

    @Override
    public List<FileInfo> getRecycledFiles(Long userId) {
        List<FileInfo> files = fileInfoMapper.findRecycledFiles(userId);
        enrichPermissions(files, userId);
        return files;
    }

    @Override
    @OperationLog("Clear recycle bin")
    public boolean clearRecycleBin(Long userId) {
        List<FileInfo> recycledFiles = getRecycledFiles(userId);
        recycledFiles.forEach(file -> permanentDeleteFile(file.getId(), userId));
        return true;
    }

    @Override
    public boolean checkFilePermission(Long fileId, Long userId, String permission) {
        FileInfo fileInfo = getById(fileId);
        if (fileInfo == null) {
            return false;
        }

        if (Objects.equals(fileInfo.getOwnerId(), userId)) {
            return true;
        }

        Integer type = fileInfo.getSpaceType();
        if (type == null) {
            return false;
        }

        switch (type) {
            case 0:
                return false;
            case 1:
                return checkDepartmentSpacePermission(fileInfo, userId, permission);
            case 2:
                return checkEnterpriseSpacePermission(fileInfo, userId, permission);
            case 3:
                return fileShareService.checkSharePermission(fileId, userId, permission);
            default:
                return false;
        }
    }

    @Override
    public String getFilePath(Long fileId) {
        FileInfo fileInfo = getById(fileId);
        if (fileInfo == null) {
            return "";
        }

        List<String> pathParts = new ArrayList<>();
        FileInfo current = fileInfo;
        while (current != null) {
            pathParts.add(0, current.getFileName());
            Long parentId = current.getParentId();
            current = parentId != null ? getById(parentId) : null;
        }

        return String.join("/", pathParts);
    }

    @Override
    public Long calculateDirectorySize(Long directoryId) {
        FileInfo directory = getById(directoryId);
        if (directory == null) {
            return 0L;
        }
        if (!java.util.Objects.equals(directory.getDirectory(), 1)) {
            return directory.getFileSize() != null ? directory.getFileSize() : 0L;
        }

        List<FileInfo> children = getFileList(directoryId, directory.getSpaceType(), directory.getSpaceId(), directory.getOwnerId());
        long total = 0L;
        for (FileInfo child : children) {
            if (java.util.Objects.equals(child.getDirectory(), 1)) {
                total += calculateDirectorySize(child.getId());
            } else {
                total += child.getFileSize() != null ? child.getFileSize() : 0L;
            }
        }
        return total;
    }

    @Override
    public void deleteUserPersonalSpace(Long userId) {
        if (userId == null) {
            return;
        }
        QueryWrapper<FileInfo> wrapper = new QueryWrapper<>();
        wrapper.eq("owner_id", userId)
            .eq("space_type", 0);
        List<FileInfo> files = list(wrapper);
        if (files != null) {
            for (FileInfo file : files) {
                FileInfo latest = getById(file.getId());
                if (latest != null) {
                    deleteFileWithoutPermission(latest, null);
                }
            }
        }
        fileShareService.remove(new QueryWrapper<FileShare>().eq("sharer_id", userId));
        fileShareService.remove(new QueryWrapper<FileShare>().eq("share_type", 0).eq("target_id", userId));
        userService.updateUsedSpaceSize(userId);
    }

    @Override
    public SpaceOverviewResponse getSpaceOverview() {
        SpaceOverviewResponse response = new SpaceOverviewResponse();
        response.setPersonalSpaceUsed(safeLong(fileInfoMapper.sumSpaceUsageByType(0)));
        response.setDepartmentSpaceUsed(safeLong(fileInfoMapper.sumSpaceUsageByType(1)));
        response.setEnterpriseSpaceUsed(safeLong(fileInfoMapper.sumSpaceUsageByType(2)));
        response.setSharedSpaceUsed(safeLong(fileInfoMapper.sumSharedSpaceUsage()));
        response.setTotalFiles(safeLong(fileInfoMapper.countAllFiles()));
        response.setRecycledFiles(safeLong(fileInfoMapper.countRecycledFiles()));
        return response;
    }

    @Override
    @OperationLog("Cleanup system garbage")
    public SpaceCleanupResponse cleanupSystemGarbage() {
        SpaceCleanupResponse response = new SpaceCleanupResponse();
        int recycledCleared = 0;
        QueryWrapper<FileInfo> recycledWrapper = new QueryWrapper<>();
        recycledWrapper.eq("is_recycled", true).eq("deleted", 0);
        List<FileInfo> recycledFiles = list(recycledWrapper);
        Set<Long> affectedUsers = new HashSet<>();
        Set<Long> affectedDepartments = new HashSet<>();
        if (recycledFiles != null) {
            for (FileInfo file : recycledFiles) {
                FileInfo latest = getById(file.getId());
                if (latest == null) {
                    continue;
                }
                deleteFileWithoutPermission(latest, affectedDepartments);
                recycledCleared++;
                if (latest.getOwnerId() != null) {
                    affectedUsers.add(latest.getOwnerId());
                }
            }
        }
        for (Long uid : affectedUsers) {
            userService.updateUsedSpaceSize(uid);
        }
        for (Long deptId : affectedDepartments) {
            departmentService.updateDepartmentUsedSpace(deptId);
        }
        response.setRecycledFilesCleared(recycledCleared);

        int clearedShares = fileShareService.cleanExpiredShares();
        response.setExpiredSharesCleared(clearedShares);

        int clearedChunks = 0;
        try {
            Set<String> keys = redisTemplate.keys(CHUNK_CACHE_PREFIX + "*");
            if (keys != null && !keys.isEmpty()) {
                clearedChunks = keys.size();
                redisTemplate.delete(keys);
            }
        } catch (Exception ignored) {
            // ignore cache cleanup errors
        }
        response.setTemporaryChunksCleared(clearedChunks);
        return response;
    }

    private void checkFileNameDuplicate(String fileName, Long parentId, Integer spaceType, Long spaceId, Long userId) {
        QueryWrapper<FileInfo> wrapper = new QueryWrapper<>();
        wrapper.eq("file_name", fileName)
            .eq("space_type", spaceType)
            .eq("is_recycled", false)
            .eq("deleted", 0);

        if (parentId == null) {
            wrapper.isNull("parent_id");
        } else {
            wrapper.eq("parent_id", parentId);
        }

        if (spaceId == null) {
            wrapper.isNull("space_id");
        } else {
            wrapper.eq("space_id", spaceId);
        }

        if (spaceType != null && spaceType == 0) {
            wrapper.eq("owner_id", userId);
        }

        if (count(wrapper) > 0) {
            throw new RuntimeException("File name already exists");
        }
    }

    private String generateCopyFileName(String originalName, Long parentId, Integer spaceType, Long spaceId, Long userId) {
        String baseName = FilenameUtils.getBaseName(originalName);
        String extension = FilenameUtils.getExtension(originalName);

        int counter = 1;
        String suffix = extension.isEmpty() ? "" : "." + extension;
        String newName = baseName + "_copy" + suffix;

        while (true) {
            try {
                checkFileNameDuplicate(newName, parentId, spaceType, spaceId, userId);
                break;
            } catch (RuntimeException ex) {
                counter++;
                newName = baseName + "_copy" + counter + suffix;
            }
        }
        return newName;
    }

    private void deleteChildrenRecursively(Long parentId, Long userId) {
        List<FileInfo> children = listChildren(parentId, false);
        for (FileInfo child : children) {
            deleteFile(child.getId(), userId);
        }
    }

    private void deleteFileWithoutPermission(FileInfo fileInfo) {
        deleteFileWithoutPermission(fileInfo, null);
    }

    private void deleteFileWithoutPermission(FileInfo fileInfo, Set<Long> affectedDepartments) {
        if (fileInfo == null) {
            return;
        }
        if (java.util.Objects.equals(fileInfo.getDirectory(), 1)) {
            QueryWrapper<FileInfo> childWrapper = new QueryWrapper<>();
            childWrapper.eq("parent_id", fileInfo.getId());
            List<FileInfo> children = list(childWrapper);
            for (FileInfo child : children) {
                deleteFileWithoutPermission(child, affectedDepartments);
            }
        } else {
            minioService.deleteFile(fileInfo.getFilePath());
        }
        fileShareService.remove(new QueryWrapper<FileShare>().eq("file_id", fileInfo.getId()));
        removeById(fileInfo.getId());
        if (fileInfo.getSpaceType() != null && fileInfo.getSpaceType() == 1 && fileInfo.getSpaceId() != null) {
            if (affectedDepartments != null) {
                affectedDepartments.add(fileInfo.getSpaceId());
            } else {
                departmentService.updateDepartmentUsedSpace(fileInfo.getSpaceId());
            }
        }
    }

    private void permanentDeleteChildrenRecursively(Long parentId, Long userId) {
        List<FileInfo> children = listChildren(parentId, true);
        for (FileInfo child : children) {
            permanentDeleteFile(child.getId(), userId);
        }
    }

    private void restoreChildrenRecursively(Long parentId, Long userId) {
        QueryWrapper<FileInfo> wrapper = new QueryWrapper<>();
        wrapper.eq("parent_id", parentId)
            .eq("is_recycled", true)
            .eq("deleted", 0);

        List<FileInfo> children = list(wrapper);
        for (FileInfo child : children) {
            restoreFile(child.getId(), userId);
        }
    }

    private void copyChildrenRecursively(Long sourceParentId, Long targetParentId, Long userId) {
        List<FileInfo> children = listChildren(sourceParentId, false);
        for (FileInfo child : children) {
            copyFile(child.getId(), targetParentId, userId);
        }
    }

    private List<FileInfo> listChildren(Long parentId, boolean includeRecycled) {
        if (parentId == null) {
            return new ArrayList<>();
        }
        QueryWrapper<FileInfo> wrapper = new QueryWrapper<>();
        wrapper.eq("parent_id", parentId)
            .eq("deleted", 0);
        if (!includeRecycled) {
            wrapper.eq("is_recycled", false);
        }
        return list(wrapper);
    }

    private void enrichPermissions(List<FileInfo> files, Long userId) {
        if (files == null) {
            return;
        }
        for (FileInfo file : files) {
            applyPermissions(file, userId);
        }
    }

    private void applyPermissions(FileInfo file, Long userId) {
        if (file == null || file.getId() == null) {
            return;
        }
        boolean directoryFlag = java.util.Objects.equals(file.getDirectory(), 1);
        file.setCanDownload(checkFilePermission(file.getId(), userId, "download"));
        safeSetCanPreview(file, checkFilePermission(file.getId(), userId, "preview"));
        file.setCanModify(checkFilePermission(file.getId(), userId, "modify"));
        file.setCanDelete(checkFilePermission(file.getId(), userId, "delete"));
        file.setCanUpload(directoryFlag && checkFilePermission(file.getId(), userId, "upload"));
    }

    private void ensureUploadAllowed(Long userId, Integer spaceType, Long spaceId, long fileSize) {
        long maxUpload = systemSettingService.getLongValue(SystemSettingService.KEY_MAX_UPLOAD_SIZE, -1L);
        if (maxUpload > 0 && fileSize > maxUpload) {
            throw new RuntimeException("File size exceeds the configured upload limit");
        }
        if (spaceType == null || spaceType == 0) {
            User owner = userService.getById(userId);
            if (owner == null) {
                throw new RuntimeException("User does not exist");
            }
            long personalQuota = owner.getPersonalSpaceSize() != null ? owner.getPersonalSpaceSize()
                : systemSettingService.getLongValue(SystemSettingService.KEY_DEFAULT_PERSONAL_SPACE, 1024L * 1024 * 1024);
            Long used = fileInfoMapper.calculateUsedSpace(userId, 0);
            long usedValue = used != null ? used : 0L;
            if (personalQuota > 0 && usedValue + fileSize > personalQuota) {
                throw new RuntimeException("Insufficient personal space");
            }
        } else if (spaceType == 1) {
            if (spaceId == null) {
                throw new RuntimeException("Department information is missing");
            }
            Department department = departmentService.getById(spaceId);
            if (department == null) {
                throw new RuntimeException("Department does not exist");
            }
            Long used = fileInfoMapper.calculateDepartmentUsedSpace(spaceId);
            long usedValue = used != null ? used : 0L;
            long quota = department.getDepartmentSpaceSize() != null ? department.getDepartmentSpaceSize() : 0L;
            if (quota > 0 && usedValue + fileSize > quota) {
                throw new RuntimeException("Insufficient department space");
            }
        }
    }

    private void updateDepartmentUsageIfNeeded(Integer spaceType, Long spaceId) {
        if (spaceType != null && spaceType == 1 && spaceId != null) {
            departmentService.updateDepartmentUsedSpace(spaceId);
        }
    }

    private long safeLong(Long value) {
        return value != null ? value : 0L;
    }

    private List<FileInfo> getSharedFileList(Long parentId, Long spaceId, Long userId) {

        // Shared view browsing helper.
        if (parentId == null) {
            return new java.util.ArrayList<>();
        }
        if (!fileShareService.checkSharePermission(parentId, userId, "preview")) {
            return new java.util.ArrayList<>();
        }
        QueryWrapper<FileInfo> wrapper = new QueryWrapper<>();
        wrapper.eq("deleted", 0)
               .eq("is_recycled", 0)
               .eq("parent_id", parentId)
               .orderByDesc("is_directory")
               .orderByAsc("file_name");
        java.util.List<FileInfo> files = list(wrapper);
        enrichPermissions(files, userId);
        return files;
    }

    // Helper DTO for browsing different spaces.
    private static class SpaceBrowseQuery {
        private Integer spaceType;
        private Long spaceId;
        private Long rootFolderId;
        private String keyword;

        public Integer getSpaceType() { return spaceType; }
        public void setSpaceType(Integer spaceType) { this.spaceType = spaceType; }
        public Long getSpaceId() { return spaceId; }
        public void setSpaceId(Long spaceId) { this.spaceId = spaceId; }
        public Long getRootFolderId() { return rootFolderId; }
        public void setRootFolderId(Long rootFolderId) { this.rootFolderId = rootFolderId; }
        public String getKeyword() { return keyword; }
        public void setKeyword(String keyword) { this.keyword = keyword; }
    }

    private List<Long> resolveDeptScope(Long userId, Long deptId) {
        if (deptId == null) {
            return java.util.Collections.emptyList();
        }
        return java.util.Collections.singletonList(deptId);
    }

    private boolean isDeptAdmin(Long userId, Long deptId) {
        return false;
    }

    // service
    private List<FileInfo> listFiles(Long userId, SpaceBrowseQuery q) {
        Integer t = (q.getSpaceType() == null) ? SPACE_PERSONAL : q.getSpaceType();
        switch (t) {
            case SPACE_PERSONAL:
            // Personal space: reuse the existing mapperMapper
                return fileInfoMapper.findByParentId(
                    q.getRootFolderId(),
                    userId,
                    SPACE_PERSONAL,
                    q.getSpaceId() /* usually null */);

            case SPACE_SHARED: {
                // Shared space: filter by department visibility
                List<Long> deptScope = resolveDeptScope(userId, q.getSpaceId());
                return fileInfoMapper.listByShare(
                    userId,
                    q.getRootFolderId(),
                    q.getKeyword(),
                    deptScope
                );
            }

        case SPACE_DEPARTMENT: {
            List<Long> deptScope = resolveDeptScope(userId, q.getSpaceId());
            boolean onlyOpen = !isDeptAdmin(userId, q.getSpaceId()); // Non-admin members only see open items
            return fileInfoMapper.listDepartmentSpace(
                    deptScope,
                    q.getRootFolderId(),
                    onlyOpen,
                    q.getKeyword()
            );
        }

        case SPACE_ENTERPRISE: {
            Long enterpriseId = q.getSpaceId();
            return fileInfoMapper.listEnterpriseSpace(
                    enterpriseId,
                    q.getRootFolderId(),
                    q.getKeyword()
            );
        }

        default:
            return java.util.Collections.emptyList();
        }
    }

    private List<FileInfo> getSpaceFileList(Long parentId, Integer spaceType, Long spaceId, Long userId) {

        // Unified handling for department and enterprise spaces.
        if (spaceType == null || spaceId == null) {
            return new java.util.ArrayList<>();
        }
        // Only department (1) and enterprise (2) spaces are handled here.
        if (spaceType != 1 && spaceType != 2) {
            return new java.util.ArrayList<>();
        }
        java.util.List<FileInfo> files;
        if (spaceType == 1) {
            // Department space: optionally expand subordinate departments.
            java.util.Set<Long> deptScope = new java.util.HashSet<>();
            deptScope.add(spaceId);
            // Attempt reflection to use helper methods that list sub-departments.
            try {
                java.lang.reflect.Method m = null;
                for (String name : new String[]{"listSubDepartmentIds", "getSubDeptIds", "listChildrenIds"}) {
                    try {
                        m = departmentService.getClass().getMethod(name, Long.class);
                        break;
                    } catch (NoSuchMethodException ignore) {}
                }
                boolean canViewSubs = false;
                try {
                    java.lang.reflect.Method auth = userService.getClass().getMethod("canViewSubDepartments", Long.class);
                    Object r = auth.invoke(userService, userId);
                    if (r instanceof Boolean) canViewSubs = (Boolean) r;
                } catch (Exception ignore) {}
                if (m != null && canViewSubs) {
                    Object r = m.invoke(departmentService, spaceId);
                    if (r instanceof java.util.Collection) {
                        for (Object o : (java.util.Collection<?>) r) {
                            if (o != null) deptScope.add(Long.valueOf(String.valueOf(o)));
                        }
                    }
                }
            } catch (Exception ignore) {}
            // Build query conditions
            QueryWrapper<FileInfo> qw = new QueryWrapper<>();
            qw.eq("deleted", 0).eq("is_recycled", 0)
              .eq("space_type", 1)
              .in("space_id", deptScope);
            if (parentId == null) {
                qw.isNull("parent_id");
            } else {
                qw.eq("parent_id", parentId);
            }
            qw.orderByDesc("is_directory").orderByAsc("file_name");
            files = list(qw);
            // Filter for records with at least preview permission.
            java.util.Iterator<FileInfo> it = files.iterator();
            while (it.hasNext()) {
                FileInfo f = it.next();
                if (!checkFilePermission(f.getId(), userId, "preview")) {
                    it.remove();
                }
            }
        } else {
            // Enterprise space: query by enterprise spaceId and parentId.
            files = listBySpaceDirect(spaceId, 2, parentId);
            java.util.Iterator<FileInfo> it = files.iterator();
            while (it.hasNext()) {
                FileInfo f = it.next();
                if (!checkFilePermission(f.getId(), userId, "preview")) {
                    it.remove();
                }
            }
        }
        // Apply permissions
        enrichPermissions(files, userId);
        return files;
}

    private boolean checkDepartmentSpacePermission(FileInfo fileInfo, Long userId, String permission) {

        if (fileInfo == null || userId == null) return false;
        Long deptId = fileInfo.getSpaceId();
        // Department administrators have full access
        boolean isDeptAdmin = false;
        try {
            for (String name : new String[]{"isDepartmentAdmin", "isDeptAdmin", "isAdmin"}) {
                try {
                    java.lang.reflect.Method m = departmentService.getClass().getMethod(name, Long.class, Long.class);
                    Object r = m.invoke(departmentService, userId, deptId);
                    if (r instanceof Boolean && (Boolean) r) { isDeptAdmin = true; break; }
                } catch (NoSuchMethodException ignore) {}
            }
        } catch (Exception ignore) {}
        if (isDeptAdmin) return true;
        // Regular members can only preview; other actions remain restricted.
        boolean isMember = false;
        try {
            for (String name : new String[]{"isMember", "isUserInDepartment", "userInDept"}) {
                try {
                    java.lang.reflect.Method m = departmentService.getClass().getMethod(name, Long.class, Long.class);
                    Object r = m.invoke(departmentService, userId, deptId);
                    if (r instanceof Boolean) { isMember = (Boolean) r; break; }
                } catch (NoSuchMethodException ignore) {}
            }
        } catch (Exception ignore) {}
        if (!isMember) return false;
        String p = permission == null ? "" : permission.toLowerCase();
        if ("preview".equals(p) || "download".equals(p)) return true;
        return false;
}

    private boolean checkEnterpriseSpacePermission(FileInfo fileInfo, Long userId, String permission) {

        if (fileInfo == null || userId == null) return false;
        // Enterprise administrators have full access
        boolean isEnterpriseAdmin = false;
        try {
            for (String name : new String[]{"isEnterpriseAdmin", "isOrgAdmin", "isAdmin"}) {
                try {
                    java.lang.reflect.Method m = userService.getClass().getMethod(name, Long.class);
                    Object r = m.invoke(userService, userId);
                    if (r instanceof Boolean && (Boolean) r) { isEnterpriseAdmin = true; break; }
                } catch (NoSuchMethodException ignore) {}
            }
        } catch (Exception ignore) {}
        if (isEnterpriseAdmin) return true;
                // Regular employees have limited preview access.
        String p = permission == null ? "" : permission.toLowerCase();
        if ("preview".equals(p) || "download".equals(p)) return true;
        return false;
}
     private void safeSetCanPreview(com.minicloud.entity.FileInfo file, boolean value) {
        try {
            try { com.minicloud.entity.FileInfo.class.getMethod("setCanPreview", boolean.class).invoke(file, value); return; } catch (NoSuchMethodException ignored) {}
            try { com.minicloud.entity.FileInfo.class.getMethod("setCanPreview", java.lang.Boolean.class).invoke(file, java.lang.Boolean.valueOf(value)); return; } catch (NoSuchMethodException ignored) {}
            try { com.minicloud.entity.FileInfo.class.getMethod("setCanPreview", java.lang.Integer.class).invoke(file, java.lang.Integer.valueOf(value ? 1 : 0)); return; } catch (NoSuchMethodException ignored) {}
            try { com.minicloud.entity.FileInfo.class.getMethod("setPreview", boolean.class).invoke(file, value); return; } catch (NoSuchMethodException ignored) {}
            try { com.minicloud.entity.FileInfo.class.getMethod("setPreview", java.lang.Boolean.class).invoke(file, java.lang.Boolean.valueOf(value)); return; } catch (NoSuchMethodException ignored) {}
            try { com.minicloud.entity.FileInfo.class.getMethod("setPreview", java.lang.Integer.class).invoke(file, java.lang.Integer.valueOf(value ? 1 : 0)); return; } catch (NoSuchMethodException ignored) {}
        } catch (Exception e) {
                            // Ignore when preview flag is not present in the schema.
        }
    }
        // Query based on space metadata.
    public List<FileInfo> listBySpaceDirect(Long spaceId, Integer spaceType, Long parentId) {
        QueryWrapper<FileInfo> qw = new QueryWrapper<>();
        qw.eq("deleted", 0)
            .eq("is_recycled", 0)
            .eq("space_type", spaceType)
            .eq("space_id", spaceId);

    if (parentId == null) {
        qw.isNull("parent_id");
    } else {
        qw.eq("parent_id", parentId);
    }

            // Order directories first before files, then by name.
        qw.orderByDesc("is_directory").orderByAsc("file_name");
    return list(qw);
   }

}
