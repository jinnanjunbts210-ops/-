package com.minicloud.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.minicloud.annotation.OperationLog;
import com.minicloud.dto.ShareInfoResponse;
import com.minicloud.entity.Department;
import com.minicloud.entity.FileInfo;
import com.minicloud.entity.FileShare;
import com.minicloud.entity.User;
import com.minicloud.mapper.DepartmentMapper;
import com.minicloud.mapper.FileInfoMapper;
import com.minicloud.mapper.FileShareMapper;
import com.minicloud.service.FileShareService;
import com.minicloud.service.UserService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
@Transactional
public class FileShareServiceImpl extends ServiceImpl<FileShareMapper, FileShare> implements FileShareService {

    private final FileShareMapper fileShareMapper;
    private final FileInfoMapper fileInfoMapper;
    private final DepartmentMapper departmentMapper;
    private final UserService userService;

    public FileShareServiceImpl(FileShareMapper fileShareMapper,
                                FileInfoMapper fileInfoMapper,
                                DepartmentMapper departmentMapper,
                                UserService userService) {
        this.fileShareMapper = fileShareMapper;
        this.fileInfoMapper = fileInfoMapper;
        this.departmentMapper = departmentMapper;
        this.userService = userService;
    }

    @Override
    @OperationLog("Create share")
    public FileShare createShare(Long fileId, Long sharerId, Integer shareType, Long targetId,
                                 Map<String, Boolean> permissions, LocalDateTime expireTime) {
        FileInfo fileInfo = fileInfoMapper.selectById(fileId);
        if (fileInfo == null) {
            throw new RuntimeException("Shared file does not exist");
        }

        if (!Objects.equals(fileInfo.getOwnerId(), sharerId)) {
            throw new RuntimeException("No permission to share");
        }

        if (shareType == 0) {
            User targetUser = userService.getById(targetId);
            if (targetUser == null) {
                throw new RuntimeException("Target user does not exist");
            }
        } else if (shareType == 1) {
            if (departmentMapper.selectById(targetId) == null) {
                throw new RuntimeException("Target department does not exist");
            }
        } else {
            throw new RuntimeException("Unsupported share type");
        }

        FileShare share = new FileShare();
        share.setFileId(fileId);
        share.setSharerId(sharerId);
        share.setShareType(shareType);
        share.setTargetId(targetId);
        share.setCanDownload(Boolean.TRUE.equals(permissions.getOrDefault("download", Boolean.TRUE)));
        share.setCanUpload(Boolean.TRUE.equals(permissions.getOrDefault("upload", Boolean.FALSE)));
        share.setCanModify(Boolean.TRUE.equals(permissions.getOrDefault("modify", Boolean.FALSE)));
        share.setCanViewOthers(Boolean.TRUE.equals(permissions.getOrDefault("viewOthers", Boolean.FALSE)));
        share.setOpen(Boolean.TRUE.equals(permissions.getOrDefault("open", Boolean.TRUE)));
        share.setExpireTime(expireTime);

        save(share);

        if (!Boolean.TRUE.equals(fileInfo.getShared())) {
            fileInfo.setShared(Boolean.TRUE);
            fileInfoMapper.updateById(fileInfo);
        }

        return share;
    }

    @Override
    @OperationLog("Update share permissions")
    public boolean updateSharePermissions(Long shareId, Long sharerId, Map<String, Boolean> permissions) {
        FileShare share = getById(shareId);
        if (share == null) {
            throw new RuntimeException("Share record does not exist");
        }

        if (!Objects.equals(share.getSharerId(), sharerId)) {
            throw new RuntimeException("No permission to update share");
        }

        share.setCanDownload(Boolean.TRUE.equals(permissions.getOrDefault("download", share.getCanDownload())));
        share.setCanUpload(Boolean.TRUE.equals(permissions.getOrDefault("upload", share.getCanUpload())));
        share.setCanModify(Boolean.TRUE.equals(permissions.getOrDefault("modify", share.getCanModify())));
        share.setCanViewOthers(Boolean.TRUE.equals(permissions.getOrDefault("viewOthers", share.getCanViewOthers())));
        share.setOpen(Boolean.TRUE.equals(permissions.getOrDefault("open", share.getOpen())));

        return updateById(share);
    }

    @Override
    @OperationLog("Cancel share")
    public boolean cancelShare(Long shareId, Long sharerId) {
        FileShare share = getById(shareId);
        if (share == null) {
            return false;
        }

        if (!Objects.equals(share.getSharerId(), sharerId)) {
            throw new RuntimeException("No permission to cancel share");
        }

        boolean success = removeById(shareId);

        QueryWrapper<FileShare> wrapper = new QueryWrapper<>();
        wrapper.eq("file_id", share.getFileId())
            .eq("deleted", 0);

        if (count(wrapper) == 0) {
            FileInfo fileInfo = fileInfoMapper.selectById(share.getFileId());
            if (fileInfo != null && Boolean.TRUE.equals(fileInfo.getShared())) {
                fileInfo.setShared(Boolean.FALSE);
                fileInfoMapper.updateById(fileInfo);
            }
        }

        return success;
    }

    @Override
    public List<ShareInfoResponse> getUserShares(Long userId) {
        return fileShareMapper.findBySharerId(userId).stream()
            .map(this::toShareInfoResponse)
            .filter(Objects::nonNull)
            .collect(Collectors.toList());
    }

    @Override
    public List<ShareInfoResponse> getSharedToUser(Long userId) {
        User user = userService.getById(userId);
        if (user == null) {
            return new ArrayList<>();
        }

        List<FileShare> shares = new ArrayList<>(fileShareMapper.findSharedToUser(userId));
        if (user.getDepartmentId() != null) {
            shares.addAll(fileShareMapper.findSharedToDepartment(user.getDepartmentId()));
        }

        return shares.stream()
            .filter(share -> !isExpired(share))
            .map(this::toShareInfoResponse)
            .filter(Objects::nonNull)
            .collect(Collectors.toList());
    }

    @Override
    public List<FileShare> getSharedToDepartment(Long departmentId) {
        return fileShareMapper.findSharedToDepartment(departmentId).stream()
            .filter(share -> !isExpired(share))
            .collect(Collectors.toList());
    }

    @Override
    public boolean checkSharePermission(Long fileId, Long userId, String permission) {
        FileShare share = findEffectiveShare(fileId, userId);
        if (share == null) {
            return false;
        }

        switch (permission) {
            case "download":
            case "preview":
                return Boolean.TRUE.equals(share.getCanDownload());
            case "upload":
                return Boolean.TRUE.equals(share.getCanUpload());
            case "modify":
            case "delete":
                return Boolean.TRUE.equals(share.getCanModify());
            case "viewOthers":
                return Boolean.TRUE.equals(share.getCanViewOthers());
            case "open":
                return Boolean.TRUE.equals(share.getOpen());
            default:
                return false;
        }
    }

    @Override
    public FileShare findEffectiveShare(Long fileId, Long userId) {
        FileInfo current = fileInfoMapper.selectById(fileId);
        while (current != null) {
            FileShare share = fileShareMapper.checkFileSharePermission(current.getId(), userId);
            if (share != null && !isExpired(share)) {
                return share;
            }
            Long parentId = current.getParentId();
            current = parentId != null ? fileInfoMapper.selectById(parentId) : null;
        }
        return null;
    }

    @Override
    public List<ShareInfoResponse> getFileShareInfo(Long fileId) {
        QueryWrapper<FileShare> wrapper = new QueryWrapper<>();
        wrapper.eq("file_id", fileId)
            .eq("deleted", 0);
        return list(wrapper).stream()
            .map(this::toShareInfoResponse)
            .filter(Objects::nonNull)
            .collect(Collectors.toList());
    }

    @Override
    public List<FileShare> batchShare(List<Long> fileIds, Long sharerId, Integer shareType, List<Long> targetIds,
                                      Map<String, Boolean> permissions, LocalDateTime expireTime) {
        List<FileShare> result = new ArrayList<>();
        for (Long fileId : fileIds) {
            for (Long targetId : targetIds) {
                result.add(createShare(fileId, sharerId, shareType, targetId, permissions, expireTime));
            }
        }
        return result;
    }

    @Override
    public boolean checkShareExpired(Long shareId) {
        FileShare share = getById(shareId);
        if (share == null) {
            return true;
        }
        return isExpired(share);
    }

    @Override
    public int cleanExpiredShares() {
        QueryWrapper<FileShare> wrapper = new QueryWrapper<>();
        wrapper.isNotNull("expire_time")
            .lt("expire_time", LocalDateTime.now())
            .eq("deleted", 0);

        List<FileShare> expired = list(wrapper);
        expired.forEach(share -> removeById(share.getId()));
        return expired.size();
    }

    @Override
    public void removeSharesRelatedToUser(Long userId) {
        if (userId == null) {
            return;
        }

        QueryWrapper<FileShare> sharerWrapper = new QueryWrapper<>();
        sharerWrapper.eq("sharer_id", userId);
        remove(sharerWrapper);

        QueryWrapper<FileShare> targetWrapper = new QueryWrapper<>();
        targetWrapper.eq("share_type", 0).eq("target_id", userId);
        remove(targetWrapper);
    }

    private ShareInfoResponse toShareInfoResponse(FileShare share) {
        if (share == null) {
            return null;
        }
        FileInfo fileInfo = fileInfoMapper.selectById(share.getFileId());
        if (fileInfo == null) {
            return null;
        }

        ShareInfoResponse dto = new ShareInfoResponse();
        dto.setId(share.getId());
        dto.setShareId(share.getId());
        dto.setFileId(fileInfo.getId());
        dto.setName(fileInfo.getFileName() != null ? fileInfo.getFileName() : "");
        dto.setSize(fileInfo.getFileSize() != null ? fileInfo.getFileSize() : 0L);
        boolean isDir = fileInfo.getDirectory() != null && fileInfo.getDirectory() == 1;
        dto.setDirectory(isDir);
        dto.setIsDir(isDir);
        dto.setShareType(share.getShareType());
        dto.setTargetId(share.getTargetId());
        dto.setSharerId(share.getSharerId());
        dto.setSharedAt(share.getCreateTime());
        dto.setCanDownload(Boolean.TRUE.equals(share.getCanDownload()));
        dto.setCanUpload(Boolean.TRUE.equals(share.getCanUpload()));
        dto.setCanModify(Boolean.TRUE.equals(share.getCanModify()));
        dto.setCanViewOthers(Boolean.TRUE.equals(share.getCanViewOthers()));
        dto.setOpen(Boolean.TRUE.equals(share.getOpen()));
        dto.setExpireTime(share.getExpireTime());
        dto.setAccessCount(share.getAccessCount());
        dto.setCreateTime(share.getCreateTime());
        dto.setUpdateTime(share.getUpdateTime());

        User sharer = userService.getById(share.getSharerId());
        if (sharer != null) {
            dto.setSharerUserId(String.valueOf(sharer.getId()));
            dto.setSharerRealName(sharer.getRealName());
            if (sharer.getDepartmentId() != null) {
                Department department = departmentMapper.selectById(sharer.getDepartmentId());
                if (department != null) {
                    dto.setSharerDepartmentName(department.getName());
                }
            }
        }

        return dto;
    }

    @Override
    @OperationLog("Remove received shares")
    public boolean removeReceivedShares(List<Long> shareIds, Long userId) {
        if (shareIds == null || shareIds.isEmpty() || userId == null) {
            return false;
        }

        User currentUser = userService.getById(userId);
        if (currentUser == null) {
            return false;
        }
        Long departmentId = currentUser.getDepartmentId();

        boolean removed = false;
        for (Long shareId : shareIds) {
            if (shareId == null) {
                continue;
            }
            FileShare share = getById(shareId);
            if (share == null) {
                continue;
            }

            Integer shareType = share.getShareType();
            Long targetId = share.getTargetId();
            boolean allowRemove = false;

            if (shareType != null) {
                if (shareType == 0 && Objects.equals(targetId, userId)) {
                    allowRemove = true;
                } else if (shareType == 1 && departmentId != null && Objects.equals(targetId, departmentId)) {
                    allowRemove = true;
                }
            }

            if (allowRemove) {
                removed = removeById(shareId) || removed;
            }
        }
        return removed;
    }

    private boolean isExpired(FileShare share) {
        LocalDateTime expireTime = share.getExpireTime();
        return expireTime != null && expireTime.isBefore(LocalDateTime.now());
    }
}

