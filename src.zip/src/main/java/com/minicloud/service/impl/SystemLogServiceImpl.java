package com.minicloud.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.minicloud.entity.SystemLog;
import com.minicloud.mapper.SystemLogMapper;
import com.minicloud.service.SystemLogService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class SystemLogServiceImpl extends ServiceImpl<SystemLogMapper, SystemLog> implements SystemLogService {

    private static final Logger LOGGER = LoggerFactory.getLogger(SystemLogServiceImpl.class);

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void log(SystemLog log) {
        if (log == null) {
            return;
        }
        try {
            save(log);
        } catch (DataAccessException ex) {
            LOGGER.warn("Skip persisting system log due to database error: {}", ex.getMessage());
        } catch (RuntimeException ex) {
            LOGGER.warn("Skip persisting system log due to unexpected error: {}", ex.getMessage());
        }
    }

    @Override
    public IPage<SystemLog> queryLogs(Long userId, Integer roleType, Long departmentId, int page, int size) {
        Page<SystemLog> p = Page.of(page, size);
        if (roleType != null && roleType >= 2) {
            return baseMapper.findAll(p);
        }
        if (roleType != null && roleType == 1 && departmentId != null) {
            return baseMapper.findByDepartment(p, departmentId);
        }
        return baseMapper.findByUser(p, userId);
    }
}
