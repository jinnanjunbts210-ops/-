package com.minicloud.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.minicloud.dto.SystemConfigRequest;
import com.minicloud.dto.SystemConfigResponse;
import com.minicloud.entity.SystemSetting;
import com.minicloud.mapper.SystemSettingMapper;
import com.minicloud.service.SystemSettingService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class SystemSettingServiceImpl extends ServiceImpl<SystemSettingMapper, SystemSetting> implements SystemSettingService {

    private final SystemSettingMapper systemSettingMapper;

    public SystemSettingServiceImpl(SystemSettingMapper systemSettingMapper) {
        this.systemSettingMapper = systemSettingMapper;
    }

    @Override
    public String getValue(String key, String defaultValue) {
        SystemSetting setting = systemSettingMapper.findByKey(key);
        return setting != null ? setting.getSettingValue() : defaultValue;
    }

    @Override
    public Long getLongValue(String key, Long defaultValue) {
        String value = getValue(key, null);
        if (value == null) {
            return defaultValue;
        }
        try {
            return Long.parseLong(value);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    @Override
    public void setValue(String key, String value, String description) {
        SystemSetting existing = systemSettingMapper.findByKey(key);
        if (existing == null) {
            SystemSetting setting = new SystemSetting();
            setting.setSettingKey(key);
            setting.setSettingValue(value);
            setting.setDescription(description);
            save(setting);
        } else {
            existing.setSettingValue(value);
            if (description != null) {
                existing.setDescription(description);
            }
            updateById(existing);
        }
    }

    @Override
    public SystemConfigResponse getSystemConfig() {
        String siteDomain = getValue(SystemSettingService.KEY_SITE_DOMAIN, "");
        Long defaultSpace = getLongValue(SystemSettingService.KEY_DEFAULT_PERSONAL_SPACE, 1024L * 1024 * 1024);
        Long maxUploadSize = getLongValue(SystemSettingService.KEY_MAX_UPLOAD_SIZE, 1024L * 1024 * 1024);
        return new SystemConfigResponse(siteDomain, defaultSpace, maxUploadSize);
    }

    @Override
    public void updateSystemConfig(SystemConfigRequest request) {
        if (request.getSiteDomain() != null) {
            setValue(SystemSettingService.KEY_SITE_DOMAIN, request.getSiteDomain(), "Site domain");
        }
        if (request.getDefaultPersonalSpaceSize() != null) {
            setValue(SystemSettingService.KEY_DEFAULT_PERSONAL_SPACE, request.getDefaultPersonalSpaceSize().toString(), "Default personal space size");
        }
        if (request.getMaxUploadSize() != null) {
            setValue(SystemSettingService.KEY_MAX_UPLOAD_SIZE, request.getMaxUploadSize().toString(), "Maximum upload size");
        }
    }
}


