package com.minicloud.service.impl;

import com.minicloud.dto.UserImportResult;
import com.minicloud.entity.Department;
import com.minicloud.entity.User;
import com.minicloud.service.DepartmentService;
import com.minicloud.service.UserImportService;
import com.minicloud.service.UserService;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Iterator;

@Service
@Transactional
public class UserImportServiceImpl implements UserImportService {

    private static final String[] TEMPLATE_HEADERS = {
        "username",
        "realName",
        "email",
        "phone",
        "roleType",
        "departmentId",
        "personalSpaceMB"
    };

    private final UserService userService;
    private final DepartmentService departmentService;

    public UserImportServiceImpl(UserService userService, DepartmentService departmentService) {
        this.userService = userService;
        this.departmentService = departmentService;
    }

    @Override
    public byte[] generateTemplate() {
        try (XSSFWorkbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("users");
            Row header = sheet.createRow(0);
            for (int i = 0; i < TEMPLATE_HEADERS.length; i++) {
                header.createCell(i).setCellValue(TEMPLATE_HEADERS[i]);
            }
            workbook.write(out);
            return out.toByteArray();
        } catch (Exception e) {
            throw new RuntimeException("Failed to generate template", e);
        }
    }

    @Override
    public UserImportResult importUsers(MultipartFile file, Long operatorId) {
        UserImportResult result = new UserImportResult();
        if (file == null || file.isEmpty()) {
            result.addError("File is empty");
            return result;
        }
        try (InputStream in = file.getInputStream(); Workbook workbook = WorkbookFactory.create(in)) {
            Sheet sheet = workbook.getSheetAt(0);
            Iterator<Row> iterator = sheet.iterator();
            if (iterator.hasNext()) {
                iterator.next();
            }
            while (iterator.hasNext()) {
                Row row = iterator.next();
                String username = getCellString(row.getCell(0));
                if (username == null || username.isBlank()) {
                    result.setSkipCount(result.getSkipCount() + 1);
                    continue;
                }
                if (userService.findByUsername(username) != null) {
                    result.addError("User " + username + " already exists");
                    result.setSkipCount(result.getSkipCount() + 1);
                    continue;
                }
                User user = new User();
                user.setUsername(username.trim());
                user.setRealName(getCellString(row.getCell(1)));
                user.setEmail(getCellString(row.getCell(2)));
                user.setPhone(getCellString(row.getCell(3)));
                Integer roleType = getCellInteger(row.getCell(4));
                user.setRoleType(roleType != null ? roleType : 0);
                Long departmentId = getCellLong(row.getCell(5));
                if (departmentId != null) {
                    Department dept = departmentService.getById(departmentId);
                    if (dept == null) {
                        result.addError("Department " + departmentId + " not found for user " + username);
                        result.setSkipCount(result.getSkipCount() + 1);
                        continue;
                    }
                    user.setDepartmentId(departmentId);
                }
                Long spaceMb = getCellLong(row.getCell(6));
                if (spaceMb != null && spaceMb > 0) {
                    user.setPersonalSpaceSize(spaceMb * 1024 * 1024);
                }
                user.setStatus(1);
                userService.createUser(user, "123456");
                result.setSuccessCount(result.getSuccessCount() + 1);
            }
        } catch (Exception e) {
            result.addError("Import failed: " + e.getMessage());
        }
        return result;
    }

    private String getCellString(Cell cell) {
        if (cell == null) return null;
        CellType type = cell.getCellType();
        if (type == CellType.NUMERIC) {
            return String.valueOf((long) cell.getNumericCellValue());
        }
        if (type == CellType.STRING) {
            String value = cell.getStringCellValue();
            return value != null ? value.trim() : null;
        }
        return null;
    }

    private Integer getCellInteger(Cell cell) {
        if (cell == null) return null;
        switch (cell.getCellType()) {
            case NUMERIC:
                return (int) cell.getNumericCellValue();
            case STRING:
                try {
                    return Integer.parseInt(cell.getStringCellValue().trim());
                } catch (NumberFormatException ignored) {
                    return null;
                }
            default:
                return null;
        }
    }

    private Long getCellLong(Cell cell) {
        if (cell == null) return null;
        switch (cell.getCellType()) {
            case NUMERIC:
                return (long) cell.getNumericCellValue();
            case STRING:
                try {
                    return Long.parseLong(cell.getStringCellValue().trim());
                } catch (NumberFormatException ignored) {
                    return null;
                }
            default:
                return null;
        }
    }
}

