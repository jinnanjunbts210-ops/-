package com.minicloud.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.minicloud.entity.UserNotification;
import com.minicloud.mapper.UserNotificationMapper;
import com.minicloud.service.UserNotificationService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class UserNotificationServiceImpl extends ServiceImpl<UserNotificationMapper, UserNotification>
    implements UserNotificationService {

    @Override
    public UserNotification notifyUser(Long userId, String title, String message, String link) {
        if (userId == null) {
            return null;
        }
        UserNotification notification = new UserNotification();
        notification.setUserId(userId);
        notification.setTitle(title);
        notification.setMessage(message);
        notification.setLink(link);
        save(notification);
        return notification;
    }

    @Override
    public List<UserNotification> listNotifications(Long userId, boolean unreadOnly, int limit) {
        LambdaQueryWrapper<UserNotification> wrapper = new LambdaQueryWrapper<UserNotification>()
            .eq(UserNotification::getUserId, userId)
            .eq(unreadOnly, UserNotification::getReadFlag, false)
            .orderByDesc(UserNotification::getCreateTime);
        if (limit > 0) {
            wrapper.last("LIMIT " + limit);
        }
        return list(wrapper);
    }

    @Override
    public void markAsRead(Long userId, Long notificationId) {
        if (notificationId == null) {
            return;
        }
        UserNotification notification = getById(notificationId);
        if (notification == null || !notification.getUserId().equals(userId)) {
            return;
        }
        if (Boolean.TRUE.equals(notification.getReadFlag())) {
            return;
        }
        notification.setReadFlag(true);
        notification.setReadTime(LocalDateTime.now());
        updateById(notification);
    }

    @Override
    public void markAllAsRead(Long userId) {
        LambdaQueryWrapper<UserNotification> wrapper = new LambdaQueryWrapper<UserNotification>()
            .eq(UserNotification::getUserId, userId)
            .eq(UserNotification::getReadFlag, false);
        List<UserNotification> notifications = list(wrapper);
        for (UserNotification notification : notifications) {
            notification.setReadFlag(true);
            notification.setReadTime(LocalDateTime.now());
        }
        if (!notifications.isEmpty()) {
            updateBatchById(notifications);
        }
    }

    @Override
    public long countUnread(Long userId) {
        return count(new LambdaQueryWrapper<UserNotification>()
            .eq(UserNotification::getUserId, userId)
            .eq(UserNotification::getReadFlag, false));
    }
}
