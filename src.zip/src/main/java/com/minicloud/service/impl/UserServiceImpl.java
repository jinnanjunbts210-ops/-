package com.minicloud.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.minicloud.entity.User;
import com.minicloud.mapper.FileInfoMapper;
import com.minicloud.mapper.UserMapper;
import com.minicloud.service.SystemSettingService;
import com.minicloud.service.UserService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    private final UserMapper userMapper;
    private final FileInfoMapper fileInfoMapper;
    private final PasswordEncoder passwordEncoder;
    private final SystemSettingService systemSettingService;

    public UserServiceImpl(UserMapper userMapper, FileInfoMapper fileInfoMapper, PasswordEncoder passwordEncoder, SystemSettingService systemSettingService) {
        this.userMapper = userMapper;
        this.fileInfoMapper = fileInfoMapper;
        this.passwordEncoder = passwordEncoder;
        this.systemSettingService = systemSettingService;
    }

    @Override
    public User findByUsername(String username) {
        return userMapper.findByUsername(username);
    }

    @Override
    public User register(User user) {
        if (findByUsername(user.getUsername()) != null) {
            throw new RuntimeException("鐢ㄦ埛鍚嶅凡瀛樺湪");
        }
        if (user.getPersonalSpaceSize() == null || user.getPersonalSpaceSize() <= 0) {
            long defaultSpace = systemSettingService.getLongValue(SystemSettingService.KEY_DEFAULT_PERSONAL_SPACE, 1024L * 1024 * 1024);
            user.setPersonalSpaceSize(defaultSpace);
        }
        if (user.getStatus() == null) {
            user.setStatus(0);
        }
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        userMapper.insert(user);
        return user;
    }

    @Override
    public boolean changePassword(Long userId, String oldPassword, String newPassword) {
        User user = getById(userId);
        if (user == null) {
            return false;
        }
        if (!passwordEncoder.matches(oldPassword, user.getPassword())) {
            return false;
        }
        user.setPassword(passwordEncoder.encode(newPassword));
        return updateById(user);
    }

    @Override
    public boolean resetPassword(String username, List<String> answers, String newPassword) {
        User user = findByUsername(username);
        if (user == null) {
            return false;
        }

        List<String> correctAnswers = new ArrayList<>();
        if (user.getSecurityAnswer1() != null) {
            correctAnswers.add(user.getSecurityAnswer1());
        }
        if (user.getSecurityAnswer2() != null) {
            correctAnswers.add(user.getSecurityAnswer2());
        }
        if (user.getSecurityAnswer3() != null) {
            correctAnswers.add(user.getSecurityAnswer3());
        }
        if (answers.size() != correctAnswers.size()) {
            return false;
        }
        for (int i = 0; i < answers.size(); i++) {
            String provided = answers.get(i);
            String correct = correctAnswers.get(i);
            if (provided == null || !provided.equalsIgnoreCase(correct)) {
                return false;
            }
        }

        user.setPassword(passwordEncoder.encode(newPassword));
        return updateById(user);
    }

    @Override
    public User updateUserInfo(Long userId, User user) {
        User existing = getById(userId);
        if (existing == null) {
            throw new RuntimeException("User does not exist");
        }
        if (user.getRealName() != null) {
            existing.setRealName(user.getRealName());
        }
        if (user.getPhone() != null) {
            existing.setPhone(user.getPhone());
        }
        if (user.getEmail() != null) {
            existing.setEmail(user.getEmail());
        }
        if (user.getGender() != null) {
            existing.setGender(user.getGender());
        }
        if (user.getAge() != null) {
            existing.setAge(user.getAge());
        }
        if (user.getPosition() != null) {
            existing.setPosition(user.getPosition());
        }
        if (user.getEmployeeNo() != null) {
            existing.setEmployeeNo(user.getEmployeeNo());
        }
        updateById(existing);
        return existing;
    }

    @Override
    public boolean updateUserStatus(Long userId, Integer status) {
        User user = getById(userId);
        if (user == null) {
            return false;
        }
        user.setStatus(status);
        return updateById(user);
    }

    @Override
    public boolean updateUserSpaceSize(Long userId, Long spaceSize) {
        User user = getById(userId);
        if (user == null) {
            return false;
        }
        long used = user.getUsedSpaceSize() != null ? user.getUsedSpaceSize() : 0L;
        if (spaceSize < used) {
            throw new RuntimeException("Space size cannot be smaller than the used space");
        }
        user.setPersonalSpaceSize(spaceSize);
        return updateById(user);
    }

    @Override
    public Long updateUsedSpaceSize(Long userId) {
        Long usedSize = fileInfoMapper.calculateUsedSpace(userId, 0);
        userMapper.updateUsedSpaceSize(userId, usedSize);
        return usedSize;
    }

    @Override
    public boolean checkUserPermission(Long userId, String permission) {
        User user = getById(userId);
        if (user == null) {
            return false;
        }
        Integer role = user.getRoleType();
        switch (permission) {
            case "DEPARTMENT_ADMIN":
                return role != null && role >= 1;
            case "SYSTEM_ADMIN":
                return role != null && role >= 2;
            case "VIEW_SUBORDINATE":
                return Boolean.TRUE.equals(user.getCanViewSubordinate());
            default:
                return true;
        }
    }

    @Override
    public List<User> listAllUsers() {
        return list();
    }

    @Override
    public boolean adminResetPassword(Long userId, String newPassword) {
        User user = getById(userId);
        if (user == null) {
            return false;
        }
        user.setPassword(passwordEncoder.encode(newPassword));
        return updateById(user);
    }

    @Override
    public User createUser(User user, String rawPassword) {
        if (user == null) {
            throw new IllegalArgumentException("User information cannot be null");
        }
        if (rawPassword == null || rawPassword.isBlank()) {
            throw new IllegalArgumentException("Initial password cannot be blank");
        }
        if (findByUsername(user.getUsername()) != null) {
            throw new RuntimeException("Username already exists");
        }
        if (user.getPersonalSpaceSize() == null || user.getPersonalSpaceSize() <= 0) {
            long defaultSpace = systemSettingService.getLongValue(SystemSettingService.KEY_DEFAULT_PERSONAL_SPACE, 1024L * 1024 * 1024);
            user.setPersonalSpaceSize(defaultSpace);
        }
        if (user.getStatus() == null) {
            user.setStatus(0);
        }
        user.setPassword(passwordEncoder.encode(rawPassword));
        save(user);
        return user;
    }

    @Override
    public User adminUpdateUser(Long userId, User user, String newPassword, Boolean clearDepartment) {
        User existing = getById(userId);
        if (existing == null) {
            throw new RuntimeException("User does not exist");
        }
        if (user.getUsername() != null && !user.getUsername().equals(existing.getUsername())) {
            if (findByUsername(user.getUsername()) != null) {
                throw new RuntimeException("Username already exists");
            }
            existing.setUsername(user.getUsername());
        }
        if (user.getRealName() != null) {
            existing.setRealName(user.getRealName());
        }
        if (user.getPhone() != null) {
            existing.setPhone(user.getPhone());
        }
        if (user.getEmail() != null) {
            existing.setEmail(user.getEmail());
        }
        if (user.getGender() != null) {
            existing.setGender(user.getGender());
        }
        if (user.getAge() != null) {
            existing.setAge(user.getAge());
        }
        if (user.getPosition() != null) {
            existing.setPosition(user.getPosition());
        }
        if (user.getEmployeeNo() != null) {
            existing.setEmployeeNo(user.getEmployeeNo());
        }
        if (Boolean.TRUE.equals(clearDepartment)) {
            existing.setDepartmentId(null);
        } else if (user.getDepartmentId() != null) {
            existing.setDepartmentId(user.getDepartmentId());
        }
        if (user.getRoleType() != null) {
            existing.setRoleType(user.getRoleType());
        }
        if (user.getStatus() != null) {
            existing.setStatus(user.getStatus());
        }
        if (user.getPersonalSpaceSize() != null) {
            existing.setPersonalSpaceSize(user.getPersonalSpaceSize());
        }
        if (user.getCanViewSubordinate() != null) {
            existing.setCanViewSubordinate(user.getCanViewSubordinate());
        }
        if (user.getSubordinateViewType() != null) {
            existing.setSubordinateViewType(user.getSubordinateViewType());
        }
        if (user.getSubordinateViewExpire() != null) {
            existing.setSubordinateViewExpire(user.getSubordinateViewExpire());
        }
        if (newPassword != null && !newPassword.isBlank()) {
            existing.setPassword(passwordEncoder.encode(newPassword));
        }
        updateById(existing);
        return existing;
    }

    @Override
    public boolean deleteUser(Long userId) {
        User user = getById(userId);
        if (user == null) {
            return false;
        }
        return removeById(userId);
    }
}




