-- 企业迷你云盘数据库初始化脚本

-- 用户表
CREATE TABLE `sys_user` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(100) NOT NULL COMMENT '密码',
  `real_name` varchar(50) DEFAULT NULL COMMENT '真实姓名',
  `phone` varchar(20) DEFAULT NULL COMMENT '手机号',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `gender` tinyint DEFAULT NULL COMMENT '性别：0-女，1-男',
  `age` int DEFAULT NULL COMMENT '年龄',
  `position` varchar(50) DEFAULT NULL COMMENT '职务',
  `employee_no` varchar(50) DEFAULT NULL COMMENT '员工编号',
  `department_id` bigint DEFAULT NULL COMMENT '部门ID',
  `role_type` tinyint NOT NULL DEFAULT '0' COMMENT '角色类型：0-普通用户，1-部门管理员，2-企业管理员',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态：0-冻结，1-激活',
  `personal_space_size` bigint NOT NULL DEFAULT '1073741824' COMMENT '个人空间大小（字节）',
  `used_space_size` bigint NOT NULL DEFAULT '0' COMMENT '已使用空间大小（字节）',
  `can_view_subordinate` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否可以查看下属部门',
  `subordinate_view_type` tinyint NOT NULL DEFAULT '0' COMMENT '下属查看权限类型：0-无权限，1-永久，2-临时',
  `subordinate_view_expire` datetime DEFAULT NULL COMMENT '临时权限过期时间',
  `security_question1` varchar(200) DEFAULT NULL COMMENT '安全问题1',
  `security_answer1` varchar(200) DEFAULT NULL COMMENT '安全答案1',
  `security_question2` varchar(200) DEFAULT NULL COMMENT '安全问题2',
  `security_answer2` varchar(200) DEFAULT NULL COMMENT '安全答案2',
  `security_question3` varchar(200) DEFAULT NULL COMMENT '安全问题3',
  `security_answer3` varchar(200) DEFAULT NULL COMMENT '安全答案3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT '删除标记：0-未删除，1-已删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  KEY `idx_department_id` (`department_id`),
  KEY `idx_role_type` (`role_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- 部门表
CREATE TABLE `sys_department` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '部门ID',
  `name` varchar(100) NOT NULL COMMENT '部门名称',
  `parent_id` bigint DEFAULT NULL COMMENT '父部门ID',
  `manager_id` bigint DEFAULT NULL COMMENT '部门管理员ID',
  `department_space_size` bigint NOT NULL DEFAULT '5368709120' COMMENT '部门空间大小（字节）',
  `used_space_size` bigint NOT NULL DEFAULT '0' COMMENT '已使用空间大小（字节）',
  `description` varchar(500) DEFAULT NULL COMMENT '部门描述',
  `sort_order` int NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT '删除标记：0-未删除，1-已删除',
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_manager_id` (`manager_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='部门表';

-- 文件信息表
CREATE TABLE `file_info` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `file_name` varchar(255) NOT NULL COMMENT '文件名',
  `file_path` varchar(500) NOT NULL COMMENT 'MinIO中的文件路径',
  `file_size` bigint NOT NULL DEFAULT '0' COMMENT '文件大小（字节）',
  `file_type` varchar(50) DEFAULT NULL COMMENT '文件类型/扩展名',
  `mime_type` varchar(100) DEFAULT NULL COMMENT 'MIME类型',
  `md5_hash` varchar(32) DEFAULT NULL COMMENT '文件MD5值',
  `owner_id` bigint NOT NULL COMMENT '文件所有者ID',
  `parent_id` bigint DEFAULT NULL COMMENT '父目录ID',
  `space_type` tinyint NOT NULL COMMENT '空间类型：0-个人空间，1-部门空间，2-企业空间，3-他人空间',
  `space_id` bigint DEFAULT NULL COMMENT '空间ID（部门ID或企业ID）',
  `is_directory` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否为目录',
  `is_shared` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已分享',
  `download_count` bigint NOT NULL DEFAULT '0' COMMENT '下载次数',
  `is_recycled` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否在回收站',
  `recycled_time` datetime DEFAULT NULL COMMENT '删除时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT '删除标记：0-未删除，1-已删除',
  PRIMARY KEY (`id`),
  KEY `idx_owner_id` (`owner_id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_space_type_id` (`space_type`, `space_id`),
  KEY `idx_md5_hash` (`md5_hash`),
  KEY `idx_is_recycled` (`is_recycled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='文件信息表';

-- 文件分享表
CREATE TABLE `file_share` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '分享ID',
  `file_id` bigint NOT NULL COMMENT '被分享的文件/目录ID',
  `sharer_id` bigint NOT NULL COMMENT '分享者ID',
  `share_type` tinyint NOT NULL COMMENT '分享类型：0-分享给个人，1-分享给部门',
  `target_id` bigint NOT NULL COMMENT '目标ID（用户ID或部门ID）',
  `can_download` tinyint(1) NOT NULL DEFAULT '1' COMMENT '下载权限',
  `can_upload` tinyint(1) NOT NULL DEFAULT '0' COMMENT '上传权限',
  `can_modify` tinyint(1) NOT NULL DEFAULT '0' COMMENT '修改权限',
  `can_view_others` tinyint(1) NOT NULL DEFAULT '0' COMMENT '互看权限',
  `is_open` tinyint(1) NOT NULL DEFAULT '1' COMMENT '开放权限（针对部门空间）',
  `expire_time` datetime DEFAULT NULL COMMENT '分享过期时间',
  `access_count` bigint NOT NULL DEFAULT '0' COMMENT '访问次数',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT '删除标记：0-未删除，1-已删除',
  PRIMARY KEY (`id`),
  KEY `idx_file_id` (`file_id`),
  KEY `idx_sharer_id` (`sharer_id`),
  KEY `idx_target` (`share_type`, `target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='文件分享表';

-- 文件审批表
CREATE TABLE `file_approval` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '审批ID',
  `title` varchar(200) NOT NULL COMMENT '审批标题',
  `content` text NOT NULL COMMENT '审批内容',
  `applicant_id` bigint NOT NULL COMMENT '申请人ID',
  `applicant_name` varchar(50) NOT NULL COMMENT '申请人姓名',
  `applicant_department` varchar(100) NOT NULL COMMENT '申请人部门',
  `applicant_contact` varchar(100) DEFAULT NULL COMMENT '申请人联系方式',
  `approver_id` bigint NOT NULL COMMENT '当前审批人ID',
  `next_approver_id` bigint DEFAULT NULL COMMENT '下一审批人ID',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态：0-待审批，1-已同意，2-已拒绝，3-已撤回',
  `approval_comment` text DEFAULT NULL COMMENT '审批意见',
  `attachment_files` text DEFAULT NULL COMMENT '附件文件ID列表（JSON格式）',
  `approval_time` datetime DEFAULT NULL COMMENT '审批时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT '删除标记：0-未删除，1-已删除',
  PRIMARY KEY (`id`),
  KEY `idx_applicant_id` (`applicant_id`),
  KEY `idx_approver_id` (`approver_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='文件审批表';

-- 系统日志表
CREATE TABLE `system_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '日志ID',
  `user_id` bigint DEFAULT NULL COMMENT '操作用户ID',
  `username` varchar(50) DEFAULT NULL COMMENT '操作用户名',
  `operation` varchar(100) NOT NULL COMMENT '操作类型',
  `method` varchar(10) DEFAULT NULL COMMENT '请求方法',
  `params` text DEFAULT NULL COMMENT '请求参数',
  `ip_address` varchar(50) DEFAULT NULL COMMENT 'IP地址',
  `user_agent` varchar(500) DEFAULT NULL COMMENT '用户代理',
  `execution_time` bigint DEFAULT NULL COMMENT '执行时间（毫秒）',
  `result` varchar(100) DEFAULT NULL COMMENT '操作结果',
  `error_message` text DEFAULT NULL COMMENT '错误信息',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_operation` (`operation`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统日志表';

-- 插入默认管理员用户
INSERT INTO `sys_user` (`username`, `password`, `real_name`, `role_type`, `status`) VALUES 
('admin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVEFDa', '系统管理员', 2, 1);

-- 插入默认部门
INSERT INTO `sys_department` (`name`, `parent_id`, `manager_id`, `description`) VALUES 
('总公司', NULL, 1, '企业总部');

