-- 提升三类空间列表性能：space_type + space_id + parent_id
CREATE INDEX IF NOT EXISTS idx_space_scope_parent
  ON file_info (space_type, space_id, parent_id, is_directory);

-- 共享目录下列子项更快（可选）
CREATE INDEX IF NOT EXISTS idx_parent_dir
  ON file_info (parent_id, is_directory);
