CREATE TABLE IF NOT EXISTS user_notification (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT,
    link VARCHAR(255),
    read_flag TINYINT(1) DEFAULT 0,
    read_time DATETIME NULL,
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    deleted TINYINT(1) DEFAULT 0,
    INDEX idx_user_notification_user (user_id),
    INDEX idx_user_notification_read (user_id, read_flag)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
