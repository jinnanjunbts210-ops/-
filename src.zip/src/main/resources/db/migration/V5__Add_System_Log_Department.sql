ALTER TABLE system_log
    ADD COLUMN IF NOT EXISTS department_id BIGINT NULL,
    ADD COLUMN IF NOT EXISTS deleted TINYINT(1) DEFAULT 0;

CREATE INDEX IF NOT EXISTS idx_system_log_department ON system_log (department_id);
CREATE INDEX IF NOT EXISTS idx_system_log_user ON system_log (user_id);
