package com.minicloud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.minicloud.service.MinioService;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest(properties = {
    "spring.autoconfigure.exclude="
        + "org.springframework.boot.autoconfigure.data.redis.RedisAutoConfiguration,"
        + "org.springframework.boot.autoconfigure.data.redis.RedisRepositoriesAutoConfiguration"
})
@ActiveProfiles("test")
class CloudDiskApplicationTests {

    @MockBean
    private MinioService minioService;

    @MockBean
    @SuppressWarnings("unchecked")
    private RedisTemplate<String, Object> redisTemplate;

    @Test
    void contextLoads() {
    }
}
